// 게임 상태 관리자 모듈
// 게임의 모든 상태를 자동 저장하고 복원하는 기능을 담당

class GameStateManager {
    constructor() {
        this.saveInterval = 5000; // 5초마다 자동 저장
        this.storageKey = 'hankookin_game_state';
        this.maxSaveHistory = 10; // 최대 저장 히스토리 개수
        this.isInitialized = false;
        
        // 자동 저장 타이머
        this.autoSaveTimer = null;
        
        console.log('🎮 Game State Manager: 초기화 완료');
    }

    // 게임 상태 저장
    saveGameState(gameData) {
        try {
            // 수익률 데이터 검증 및 정규화
            let buyProfitRate = gameData.buyProfitRate || 0;
            let sellProfitRate = gameData.sellProfitRate || 0;
            
            // 비정상적인 수익률 값 검증 및 수정
            if (buyProfitRate < -10 || buyProfitRate > 15) {
                console.warn(`⚠️ 비정상적인 매수 수익률 감지: ${buyProfitRate.toFixed(2)}%, 0으로 재설정`);
                buyProfitRate = 0;
            }
            
            if (sellProfitRate < -100 || sellProfitRate > 1000) {
                console.warn(`⚠️ 비정상적인 매도 수익률 감지: ${sellProfitRate.toFixed(2)}%, 0으로 재설정`);
                sellProfitRate = 0;
            }
            
            // 매수가가 0인데 수익률이 있는 경우 수정
            if ((gameData.buyPrice || 0) <= 0) {
                if (buyProfitRate !== 0) {
                    console.warn(`⚠️ 매수가가 0인데 매수 수익률이 ${buyProfitRate.toFixed(2)}%로 설정됨, 0으로 재설정`);
                    buyProfitRate = 0;
                }
                if (sellProfitRate !== 0) {
                    console.warn(`⚠️ 매수가가 0인데 매도 수익률이 ${sellProfitRate.toFixed(2)}%로 설정됨, 0으로 재설정`);
                    sellProfitRate = 0;
                }
            }
            
            const state = {
                timestamp: Date.now(),
                gameData: {
                    nbCoins: gameData.nbCoins || 0,
                    nbMinerals: gameData.nbMinerals || 0.0,
                    buyPrice: gameData.buyPrice || 0,
                    buyProfitRate: buyProfitRate,
                    sellProfitRate: sellProfitRate,
                    lastBuyAction: gameData.lastBuyAction || false,
                    lastSellAction: gameData.lastSellAction || false
                },
                aiModels: this.convertAiModelsForStorage(gameData.aiModels || []),
                uiElements: this.captureUIState(),
                trainerState: this.captureTrainerState(),
                timestamp: Date.now()
            };

            // 로컬 스토리지에 저장
            localStorage.setItem(this.storageKey, JSON.stringify(state));
            
            // 저장 히스토리 관리
            this.manageSaveHistory();
            
            if (window.logManager) {
                window.logManager.addLog(`💾 게임 상태 자동 저장 완료 (${new Date().toLocaleTimeString()}) - 매수수익률: ${buyProfitRate.toFixed(2)}%, 매도수익률: ${sellProfitRate.toFixed(2)}%`);
            }
            
            console.log('💾 Game State Manager: 게임 상태 저장 완료');
            return true;
        } catch (error) {
            console.error('❌ Game State Manager: 저장 오류:', error);
            if (window.logManager) {
                window.logManager.addLog(`❌ 게임 상태 저장 실패: ${error.message}`);
            }
            return false;
        }
    }

    // 게임 상태 복원
    loadGameState() {
        try {
            const savedState = localStorage.getItem(this.storageKey);
            if (!savedState) {
                console.log('💾 Game State Manager: 저장된 게임 상태 없음');
                return null;
            }

            const state = JSON.parse(savedState);
            
            // 저장된 시간 확인 (24시간 이내)
            const savedTime = new Date(state.timestamp);
            const currentTime = new Date();
            const hoursDiff = (currentTime - savedTime) / (1000 * 60 * 60);
            
            if (hoursDiff > 24) {
                console.log('💾 Game State Manager: 저장된 상태가 24시간을 초과하여 무시됨');
                localStorage.removeItem(this.storageKey);
                return null;
            }

            if (window.logManager) {
                window.logManager.addLog(`🔄 게임 상태 복원 시작 (저장 시간: ${savedTime.toLocaleString()})`);
            }
            
            console.log('💾 Game State Manager: 게임 상태 복원 완료');
            return state;
        } catch (error) {
            console.error('❌ Game State Manager: 복원 오류:', error);
            if (window.logManager) {
                window.logManager.addLog(`❌ 게임 상태 복원 실패: ${error.message}`);
            }
            return null;
        }
    }

    // AI 모델들을 저장용 형태로 변환
    convertAiModelsForStorage(aiModels) {
        if (!aiModels || !Array.isArray(aiModels)) {
            return [];
        }

        return aiModels.map(model => ({
            name: model.name ? model.name.text : '',
            role: model.role ? model.role.text : '',
            targetAction: model.targetAction || '',
            targetX: model.targetX || 0,
            targetY: model.targetY || 0,
            isExplorer: model.isExplorer || false,
            isTrainer: model.isTrainer || false,
            discoveredCoords: model.discoveredCoords || [],
            memoryIndex: model.memoryIndex || 0,
            explorationTimer: model.explorationTimer || 0,
            arrivalLogged: model.arrivalLogged || false,
            needsNewDecision: model.needsNewDecision || false
        }));
    }

    // AI 모델들을 복원용 형태로 변환
    convertAiModelsFromStorage(savedModels, scene) {
        if (!savedModels || !Array.isArray(savedModels) || !scene) {
            return [];
        }

        // scene.config가 없으면 기본값 사용
        const config = scene.config || { width: 1086, height: 500 };

        const modelColors = [0xff8800, 0x00ff88, 0x8800ff, 0xff0088, 0xffff00];
        const modelNames = ['Explorer-1', 'Explorer-2', 'Explorer-3', 'Explorer-4', 'Trainer'];
        const modelRoles = ['탐색', '탐색', '탐색', '탐색', '트레이너'];

        return savedModels.map((savedModel, index) => {
            const circleRadius = index === 4 ? 20 : 10;
            const fontSize = index === 4 ? '8px' : '6px';
            const roleFontSize = index === 4 ? '6px' : '5px';

            // 기본 위치 설정 (저장된 위치가 있으면 사용, 없으면 기본값)
            const defaultX = index === 0 ? config.width / 2 : 
                           index === 1 ? config.width / 4 :
                           index === 2 ? config.width * 3/4 :
                           index === 3 ? config.width / 4 :
                           config.width * 3/4;
            
            const defaultY = index === 0 ? config.height / 2 :
                           index === 1 ? config.height / 4 :
                           index === 2 ? config.height / 4 :
                           index === 3 ? config.height * 3/4 :
                           config.height * 3/4;

            // 저장된 위치가 있으면 사용, 없으면 기본값 사용
            const currentX = savedModel.targetX !== undefined ? savedModel.targetX : defaultX;
            const currentY = savedModel.targetY !== undefined ? savedModel.targetY : defaultY;
            
            const model = {
                circle: scene.add.circle(currentX, currentY, circleRadius, modelColors[index]),
                name: scene.add.text(currentX, currentY - (index === 4 ? 6 : 4), modelNames[index], {
                    fontSize: fontSize,
                    fill: '#ffffff',
                    fontStyle: 'bold'
                }).setOrigin(0.5),
                role: scene.add.text(currentX, currentY + (index === 4 ? 6 : 4), modelRoles[index], {
                    fontSize: roleFontSize,
                    fill: '#ffffff'
                }).setOrigin(0.5),
                targetX: savedModel.targetX || defaultX,
                targetY: savedModel.targetY || defaultY,
                targetAction: savedModel.targetAction || (index === 4 ? '신호 대기' : ''),
                isExplorer: savedModel.isExplorer !== undefined ? savedModel.isExplorer : index < 4,
                isTrainer: savedModel.isTrainer !== undefined ? savedModel.isTrainer : index === 4,
                discoveredCoords: savedModel.discoveredCoords || [],
                memoryIndex: savedModel.memoryIndex || 0,
                explorationTimer: savedModel.explorationTimer || 0,
                arrivalLogged: savedModel.arrivalLogged || false,
                needsNewDecision: savedModel.needsNewDecision || false
            };

            model.circle.setOrigin(0.5, 0.5);
            return model;
        });
    }

    // UI 상태 캡처
    captureUIState() {
        const uiState = {};
        
        // 학습 상태
        if (window.learningStatus) {
            uiState.learningStatus = window.learningStatus.text;
        }
        
        // 트레이너 대화창
        if (window.trainerDialog) {
            uiState.trainerDialog = window.trainerDialog.text;
        }
        
        // 트레이너 위치 정보
        if (window.trainerPositionInfo) {
            uiState.trainerPositionInfo = window.trainerPositionInfo.text;
        }
        
        // N/B 코인 표시
        if (window.nbCoinDisplay) {
            uiState.nbCoinDisplay = window.nbCoinDisplay.text;
        }
        
        // N/B 미네랄 표시
        if (window.nbMineralDisplay) {
            uiState.nbMineralDisplay = window.nbMineralDisplay.text;
        }
        
        // 매수 수익률 표시
        if (window.buyProfitRateDisplay) {
            uiState.buyProfitRateDisplay = window.buyProfitRateDisplay.text;
        }
        
        // 매도 수익률 표시
        if (window.sellProfitRateDisplay) {
            uiState.sellProfitRateDisplay = window.sellProfitRateDisplay.text;
        }
        
        return uiState;
    }

    // UI 상태 복원
    restoreUIState(uiState) {
        if (!uiState) return;
        
        // 학습 상태 복원
        if (window.learningStatus && uiState.learningStatus) {
            window.learningStatus.setText(uiState.learningStatus);
        }
        
        // 트레이너 대화창 복원
        if (window.trainerDialog && uiState.trainerDialog) {
            window.trainerDialog.setText(uiState.trainerDialog);
        }
        
        // 트레이너 위치 정보 복원
        if (window.trainerPositionInfo && uiState.trainerPositionInfo) {
            window.trainerPositionInfo.setText(uiState.trainerPositionInfo);
        }
        
        // N/B 코인 표시 복원
        if (window.nbCoinDisplay && uiState.nbCoinDisplay) {
            window.nbCoinDisplay.setText(uiState.nbCoinDisplay);
        }
        
        // N/B 미네랄 표시 복원
        if (window.nbMineralDisplay && uiState.nbMineralDisplay) {
            window.nbMineralDisplay.setText(uiState.nbMineralDisplay);
        }
        
        // 매수 수익률 표시 복원
        if (window.buyProfitRateDisplay && uiState.buyProfitRateDisplay) {
            window.buyProfitRateDisplay.setText(uiState.buyProfitRateDisplay);
        }
        
        // 매도 수익률 표시 복원
        if (window.sellProfitRateDisplay && uiState.sellProfitRateDisplay) {
            window.sellProfitRateDisplay.setText(uiState.sellProfitRateDisplay);
        }
    }

    // 트레이너 상태 캡처
    captureTrainerState() {
        const trainerState = {};
        
        // 트레이너 의사결정 핸들러 상태
        if (window.trainerDecisionHandler) {
            trainerState.waitCheckTimer = window.trainerDecisionHandler.waitCheckTimer || 0;
            trainerState.waitStartTime = window.trainerDecisionHandler.waitStartTime || null;
            trainerState.countdownStarted = window.trainerDecisionHandler.countdownStarted || false;
            trainerState.btcExplorationMode = window.trainerDecisionHandler.btcExplorationMode || false;
            trainerState.arrivalLogged = window.trainerDecisionHandler.arrivalLogged || false;
        }
        
        // 트레이너 이동 컨트롤러 상태
        if (window.trainerMovementController) {
            trainerState.movementSpeed = window.trainerMovementController.movementSpeed || 0.03;
            trainerState.arrivalThreshold = window.trainerMovementController.arrivalThreshold || 2;
            trainerState.minMovementDistance = window.trainerMovementController.minMovementDistance || 0.5;
        }
        
        return trainerState;
    }

    // 트레이너 상태 복원
    restoreTrainerState(trainerState) {
        if (!trainerState) return;
        
        // 트레이너 의사결정 핸들러 상태 복원
        if (window.trainerDecisionHandler) {
            window.trainerDecisionHandler.waitCheckTimer = trainerState.waitCheckTimer || 0;
            window.trainerDecisionHandler.waitStartTime = trainerState.waitStartTime || null;
            window.trainerDecisionHandler.countdownStarted = trainerState.countdownStarted || false;
            window.trainerDecisionHandler.btcExplorationMode = trainerState.btcExplorationMode || false;
            window.trainerDecisionHandler.arrivalLogged = trainerState.arrivalLogged || false;
        }
        
        // 트레이너 이동 컨트롤러 상태 복원
        if (window.trainerMovementController) {
            window.trainerMovementController.movementSpeed = trainerState.movementSpeed || 0.03;
            window.trainerMovementController.arrivalThreshold = trainerState.arrivalThreshold || 2;
            window.trainerMovementController.minMovementDistance = trainerState.minMovementDistance || 0.5;
        }
    }

    // 저장 히스토리 관리
    manageSaveHistory() {
        const historyKey = `${this.storageKey}_history`;
        let history = JSON.parse(localStorage.getItem(historyKey) || '[]');
        
        // 현재 상태를 히스토리에 추가
        history.push({
            timestamp: Date.now(),
            key: this.storageKey
        });
        
        // 최대 개수 제한
        if (history.length > this.maxSaveHistory) {
            history = history.slice(-this.maxSaveHistory);
        }
        
        localStorage.setItem(historyKey, JSON.stringify(history));
    }

    // 자동 저장 시작
    startAutoSave() {
        if (this.autoSaveTimer) {
            clearInterval(this.autoSaveTimer);
        }
        
        this.autoSaveTimer = setInterval(() => {
            if (window.gameInitializer && window.gameInitializer.gameData) {
                const gameData = {
                    ...window.gameInitializer.gameData,
                    aiModels: window.gameInitializer.aiModels || []
                };
                this.saveGameState(gameData);
            }
        }, this.saveInterval);
        
        console.log('💾 Game State Manager: 자동 저장 시작 (5초 간격)');
    }

    // 자동 저장 중지
    stopAutoSave() {
        if (this.autoSaveTimer) {
            clearInterval(this.autoSaveTimer);
            this.autoSaveTimer = null;
        }
        console.log('💾 Game State Manager: 자동 저장 중지');
    }

    // 게임 상태 초기화
    initializeGameState() {
        if (this.isInitialized) return;
        
        // 저장된 상태 복원 시도
        const savedState = this.loadGameState();
        if (savedState) {
            // 게임 데이터 복원
            if (window.gameInitializer && savedState.gameData) {
                window.gameInitializer.gameData = { ...savedState.gameData };
            }
            
            // UI 상태 복원
            this.restoreUIState(savedState.uiElements);
            
            // 트레이너 상태 복원
            this.restoreTrainerState(savedState.trainerState);
            
            if (window.logManager) {
                window.logManager.addLog(`🔄 게임 상태 복원 완료 - 이전 세션에서 복구됨`);
            }
        }
        
        // 자동 저장 시작
        this.startAutoSave();
        
        this.isInitialized = true;
        console.log('💾 Game State Manager: 게임 상태 초기화 완료');
    }

    // 게임 상태 완전 삭제
    clearGameState() {
        localStorage.removeItem(this.storageKey);
        localStorage.removeItem(`${this.storageKey}_history`);
        
        if (window.logManager) {
            window.logManager.addLog(`🗑️ 게임 상태 완전 삭제됨`);
        }
        
        console.log('💾 Game State Manager: 게임 상태 삭제 완료');
    }

    // 저장된 상태 정보 조회
    getSaveInfo() {
        const savedState = localStorage.getItem(this.storageKey);
        if (!savedState) {
            return { exists: false };
        }
        
        try {
            const state = JSON.parse(savedState);
            return {
                exists: true,
                timestamp: new Date(state.timestamp),
                gameData: state.gameData,
                aiModelsCount: state.aiModels ? state.aiModels.length : 0
            };
        } catch (error) {
            return { exists: false, error: error.message };
        }
    }
}

// 전역 인스턴스 생성
window.gameStateManager = new GameStateManager();

// 페이지 로드 시 자동 초기화
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        if (window.gameStateManager) {
            window.gameStateManager.initializeGameState();
        }
    }, 2000); // 2초 후 초기화 (다른 모듈들이 로드될 시간 확보)
});

// 페이지 언로드 시 자동 저장
window.addEventListener('beforeunload', () => {
    if (window.gameStateManager && window.gameInitializer && window.gameInitializer.gameData) {
        const gameData = {
            ...window.gameInitializer.gameData,
            aiModels: window.gameInitializer.aiModels || []
        };
        window.gameStateManager.saveGameState(gameData);
    }
});
