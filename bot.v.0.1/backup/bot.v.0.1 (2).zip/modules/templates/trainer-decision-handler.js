// 트레이너 의사결정 핸들러 모듈
// 트레이너의 의사결정, 목표 설정, 상태 관리를 담당

class TrainerDecisionHandler {
    constructor() {
        this.waitCheckTimer = 0;
        this.waitStartTime = null;
        this.countdownStarted = false;
        this.btcExplorationMode = false;
        this.arrivalLogged = false;
        
        // 수익률 계산 로그 누적 저장용
        this.buyProfitLogs = [];
        this.sellProfitLogs = [];
        
        // 수익률 계산 로그 파일 초기화
        this.initProfitRateLogs();
    }
    
    // 수익률 계산 로그 파일 초기화
    initProfitRateLogs() {
        const today = new Date().toISOString().split('T')[0];
        this.buyProfitLogFile = `log/trainer/buy-profit-rate-logs-${today}.txt`;
        this.sellProfitLogFile = `log/trainer/sell-profit-rate-logs-${today}.txt`;
        
        console.log(`📊 수익률 계산 로그 파일 초기화: ${this.buyProfitLogFile}, ${this.sellProfitLogFile}`);
        
        // 로그 매니저에 수익률 계산 로그 파일 정보 저장
        if (window.logManager) {
            window.logManager.addLog(`📊 수익률 계산 로그 파일 생성: ${this.buyProfitLogFile}, ${this.sellProfitLogFile}`);
        }
    }
    
    // 수익률 계산 로그 작성 (파일 저장)
    writeProfitRateLog(filename, content) {
        const timestamp = `[${new Date().toLocaleTimeString()}] `;
        const logEntry = timestamp + content + '\n';
        
        // 브라우저에서는 console.log로 출력
        console.log(`📊 ${filename}: ${timestamp}${content}`);
        
        // 전역 로그 매니저에도 기록
        if (window.logManager) {
            window.logManager.addLog(`📊 ${filename}: ${content}`);
        }
        
        // 로그 누적 저장
        if (filename.includes('buy-profit-rate')) {
            this.buyProfitLogs.push(logEntry);
            // 매수 로그 파일 자동 저장
            this.saveLogToFile(this.buyProfitLogFile, this.buyProfitLogs);
        } else if (filename.includes('sell-profit-rate')) {
            this.sellProfitLogs.push(logEntry);
            // 매도 로그 파일 자동 저장
            this.saveLogToFile(this.sellProfitLogFile, this.sellProfitLogs);
        }
    }
    
    // 로그 파일 자동 저장 (파이썬 환경에서 실제 파일 시스템에 저장)
    saveLogToFile(filename, logs) {
        const content = logs.join('');
        
        // 파이썬 환경에서 실제 파일 시스템에 저장
        try {
            // 파이썬 서버에 파일 저장 요청
            fetch('/save-log-file', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    filename: filename,
                    content: content,
                    logCount: logs.length
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    console.log(`💾 ${filename} 자동 저장 완료 (${logs.length}개 로그) - 실제 파일: ${data.filepath}`);
                    
                    // 로그 매니저에도 저장 정보 기록
                    if (window.logManager) {
                        window.logManager.addLog(`💾 수익률 로그 저장: ${filename} (${logs.length}개 로그) - 실제 파일: ${data.filepath}`);
                    }
                } else {
                    console.error(`❌ 파일 저장 실패: ${data.error}`);
                    // 폴백: localStorage에 저장
                    this.saveToLocalStorage(filename, content, logs.length);
                }
            })
            .catch(error => {
                console.error(`❌ 파일 저장 요청 실패: ${error.message}`);
                // 폴백: localStorage에 저장
                this.saveToLocalStorage(filename, content, logs.length);
            });
        } catch (error) {
            console.error(`❌ 파일 저장 실패: ${error.message}`);
            // 폴백: localStorage에 저장
            this.saveToLocalStorage(filename, content, logs.length);
        }
    }
    
    // localStorage에 저장 (폴백)
    saveToLocalStorage(filename, content, logCount) {
        const storageKey = `profit_log_${filename.replace(/[^a-zA-Z0-9]/g, '_')}`;
        localStorage.setItem(storageKey, content);
        console.log(`💾 ${filename} localStorage 저장 완료 (${logCount}개 로그) - localStorage: ${storageKey}`);
    }

    // 트레이너 의사결정 처리
    handleTrainerDecision(model, config, currentMajority, nbCoins, buyProfitRate, sellProfitRate, startX, topY, spacing) {
        const modelX = model.circle.x;
        const modelY = model.circle.y;
        
        // 현재 위치와 목표 정보 로그
        if (window.logManager) {
            const currentPos = `(${Math.round(modelX)}, ${Math.round(modelY)})`;
            const targetPos = `(${Math.round(model.targetX)}, ${Math.round(model.targetY)})`;
            const distanceToTarget = Math.sqrt((model.targetX - modelX) ** 2 + (model.targetY - modelY) ** 2);
            window.logManager.addLog(`🎯 트레이너 의사결정: 현재위치 ${currentPos} | 목표위치 ${targetPos} | 목표까지거리 ${Math.round(distanceToTarget)}px`);
        }
        
        // 새로운 의사결정이 필요한 경우 처리
        if (model.needsNewDecision) {
            if (window.logManager) {
                window.logManager.addLog(`🔄 새로운 의사결정 필요 - 현재 액션: ${model.targetAction}`);
            }
            
            // 현재 구역 확인
            const currentZone = this.getCurrentZone(modelX, modelY, startX, topY, spacing, config);
            
            // 새로운 랜덤 액션 선택
            const actions = ['매수', '매도', 'BTC 시장 탐색', 'N/B 길드 방문', '신호 대기'];
            const randomAction = actions[Math.floor(Math.random() * actions.length)];
            
            if (window.logManager) {
                window.logManager.addLog(`🎲 새로운 의사결정: ${randomAction} 선택`);
            }
            
            // 랜덤 액션에 따른 목표 설정
            if (window.trainerMovementController) {
                if (randomAction === '매수') {
                    window.trainerMovementController.moveToBuyArea(model, startX, topY);
                } else if (randomAction === '매도') {
                    window.trainerMovementController.moveToSellArea(model, startX, topY, spacing);
                } else if (randomAction === 'BTC 시장 탐색') {
                    window.trainerMovementController.moveToBTCMarket(model, config);
                } else if (randomAction === 'N/B 길드 방문') {
                    window.trainerMovementController.moveToNBGuild(model);
                } else {
                    window.trainerMovementController.moveToSignalCenter(model, config);
                }
            }
            
            // 상태 초기화
            model.needsNewDecision = false;
            model.arrivalLogged = false;
            this.countdownStarted = false;
            this.btcExplorationMode = false;
            
            // 색상 변경
            if (window.trainerVisualEffects) {
                window.trainerVisualEffects.changeTrainerColor(model, randomAction);
            }
            
            // 트레이너 대화창 업데이트
            if (window.trainerDialog) {
                const currentTime = new Date().toLocaleTimeString();
                const dialogText = `🎲 트레이너: 새로운 의사결정 → ${randomAction} | 시간: ${currentTime}`;
                window.trainerDialog.setText(dialogText);
                
                // 화면 출력 내용을 로그에 저장
                if (window.logManager) {
                    window.logManager.addLog(`📺 화면출력(트레이너대화창): ${dialogText}`);
                }
            }
            
            return randomAction;
        }
        
        // 현재 구역에서 의사 결정 매칭 확인
        const currentZone = this.getCurrentZone(modelX, modelY, startX, topY, spacing, config);
        const zoneDecision = this.getZoneDecision(currentZone, currentMajority, nbCoins, buyProfitRate, sellProfitRate, startX, topY, spacing, config);
        
        let targetAction = model.targetAction || '신호 대기';
        
        // 의사결정 처리
        if (!zoneDecision && !this.countdownStarted && !this.btcExplorationMode) {
            targetAction = this.handleNoDecision(model, config, targetAction, currentZone);
        } else if (zoneDecision && !this.countdownStarted) {
            targetAction = this.handleZoneDecision(model, zoneDecision, currentZone, currentMajority);
        } else if (this.countdownStarted) {
            targetAction = this.handleCountdown(model, config);
        }
        
        // 신호 대기 상태 처리
        if (targetAction === '신호 대기') {
            this.handleSignalWaiting(model, config);
        }
        
        // BTC 시장 탐색 모드 처리
        if (targetAction === 'BTC 시장 탐색') {
            this.handleBTCMarketExploration(model, config);
        }
        
        return targetAction;
    }

    // 현재 구역 확인
    getCurrentZone(modelX, modelY, startX, topY, spacing, config) {
        // 매수 영역
        if (Math.abs(modelX - startX) < 50 && Math.abs(modelY - topY) < 50) {
            return '매수영역';
        }
        // 매도 영역
        else if (Math.abs(modelX - (startX + spacing)) < 50 && Math.abs(modelY - topY) < 50) {
            return '매도영역';
        }
        // 대기 영역
        else if (Math.abs(modelX - (startX + spacing * 2)) < 50 && Math.abs(modelY - topY) < 50) {
            return '대기영역';
        }
        // N/B 길드
        else if (Math.abs(modelX - 100) < 60 && Math.abs(modelY - 100) < 60) {
            return 'N/B길드';
        }
        // BTC 시장 탐색 구역
        else if (Math.abs(modelX - (config.width - 100)) < 60 && Math.abs(modelY - (config.height - 100)) < 60) {
            return 'BTC시장탐색구역';
        }
        // 신호 대기 센터
        else if (Math.abs(modelX - config.width / 2) < 60 && Math.abs(modelY - config.height / 2) < 60) {
            return '신호대기센터';
        }
        
        return '기타영역';
    }

    // 구역별 의사결정
    getZoneDecision(currentZone, currentMajority, nbCoins, buyProfitRate, sellProfitRate, startX, topY, spacing, config) {
        // 디버깅: 의사결정 입력값 로그
        if (window.logManager) {
            window.logManager.addLog(`🔍 의사결정 입력값: 구역=${currentZone}, 신호=${currentMajority}, 코인=${nbCoins}, 매수수익률=${buyProfitRate?.toFixed(2) || 'N/A'}%, 매도수익률=${sellProfitRate?.toFixed(2) || 'N/A'}%`);
        }
        
        // 의사결정 로직 (기존 decision-system 모듈과 연동)
        if (window.decisionSystem && typeof window.decisionSystem.getZoneDecision === 'function') {
            const decision = window.decisionSystem.getZoneDecision(currentZone, currentMajority, nbCoins, buyProfitRate, sellProfitRate, startX, topY, spacing, config);
            
            if (decision) {
                if (window.logManager) {
                    window.logManager.addLog(`✅ 의사결정 성공: ${decision.action} → (${decision.targetX}, ${decision.targetY})`);
                }
                return decision;
            } else {
                if (window.logManager) {
                    window.logManager.addLog(`❌ 의사결정 없음: 현재 구역(${currentZone})에서 조건 불만족`);
                }
            }
        } else {
            if (window.logManager) {
                window.logManager.addLog(`⚠️ decisionSystem 모듈을 찾을 수 없음`);
            }
        }
        
        // 폴백: 간단한 의사결정 로직
        return this.getFallbackDecision(currentZone, currentMajority, nbCoins, buyProfitRate, sellProfitRate, startX, topY, spacing, config);
    }

    // 폴백 의사결정 로직
    getFallbackDecision(currentZone, currentMajority, nbCoins, buyProfitRate, sellProfitRate, startX, topY, spacing, config) {
        // 1. 매도 우선 (N/B 코인이 있고 매도 수익률이 있는 경우)
        if (nbCoins > 0 && sellProfitRate !== 0) {
            if (window.logManager) {
                window.logManager.addLog(`📉 폴백 매도 의사결정: 코인 ${nbCoins}개, 매도수익률 ${sellProfitRate.toFixed(2)}%`);
            }
            return {
                action: '매도',
                targetX: startX + spacing,
                targetY: topY
            };
        }
        
        // 2. 매수 (BLUE 신호이고 매수 수익률이 있는 경우)
        if (currentMajority === 'BLUE' && buyProfitRate !== 0) {
            if (window.logManager) {
                window.logManager.addLog(`📈 폴백 매수 의사결정: BLUE 신호, 매수수익률 ${buyProfitRate.toFixed(2)}%`);
            }
            return {
                action: '매수',
                targetX: startX,
                targetY: topY
            };
        }
        
        // 3. N/B 길드 방문 (코인이 있고 매도 수익률이 계산되지 않은 경우)
        if (nbCoins > 0 && sellProfitRate === 0) {
            if (window.logManager) {
                window.logManager.addLog(`🏛️ 폴백 N/B 길드 방문: 코인 ${nbCoins}개, 매도수익률 계산 필요`);
            }
            return {
                action: 'N/B 길드 방문',
                targetX: 100,
                targetY: 100
            };
        }
        
        // 4. BTC 시장 탐색 (BLUE 신호이고 매수 수익률이 계산되지 않은 경우)
        if (currentMajority === 'BLUE' && buyProfitRate === 0) {
            if (window.logManager) {
                window.logManager.addLog(`🔍 폴백 BTC 시장 탐색: BLUE 신호, 매수수익률 계산 필요`);
            }
            return {
                action: 'BTC 시장 탐색',
                targetX: config.width - 100,
                targetY: config.height - 100
            };
        }
        
        // 5. 신호 대기 (기타 경우)
        if (window.logManager) {
            window.logManager.addLog(`⏳ 폴백 신호 대기: 현재 조건으로는 대기 필요`);
        }
        return {
            action: '신호 대기',
            targetX: config.width / 2,
            targetY: config.height / 2
        };
    }

    // 의사결정이 없을 때 처리
    handleNoDecision(model, config, targetAction, currentZone) {
        // 현재 위치에서 의사결정이 없으면 다른 구역으로 이동
        const actions = ['매수', '매도', 'BTC 시장 탐색', 'N/B 길드 방문', '신호 대기'];
        const randomAction = actions[Math.floor(Math.random() * actions.length)];
        targetAction = randomAction;
        model.targetAction = targetAction;
        
        if (window.logManager) {
            window.logManager.addLog(`🎲 의사결정 없음 → 랜덤 액션: ${randomAction}`);
        }
        
        // 랜덤 액션에 따른 목표 설정
        if (window.trainerMovementController) {
            if (randomAction === '매수') {
                window.trainerMovementController.moveToBuyArea(model, 100, 100);
            } else if (randomAction === '매도') {
                window.trainerMovementController.moveToSellArea(model, 100, 100, 200);
            } else if (randomAction === 'BTC 시장 탐색') {
                window.trainerMovementController.moveToBTCMarket(model, config);
            } else if (randomAction === 'N/B 길드 방문') {
                window.trainerMovementController.moveToNBGuild(model);
            } else {
                window.trainerMovementController.moveToSignalCenter(model, config);
            }
        } else {
            // 폴백: 직접 목표 위치 설정
            if (randomAction === '매수') {
                model.targetX = 100;
                model.targetY = 100;
            } else if (randomAction === '매도') {
                model.targetX = 300;
                model.targetY = 100;
            } else if (randomAction === 'BTC 시장 탐색') {
                model.targetX = config.width - 100;
                model.targetY = config.height - 100;
            } else if (randomAction === 'N/B 길드 방문') {
                model.targetX = 100;
                model.targetY = 100;
            } else {
                model.targetX = config.width / 2;
                model.targetY = config.height / 2;
            }
        }
        
        // 색상 변경
        if (window.trainerVisualEffects) {
            window.trainerVisualEffects.changeTrainerColor(model, targetAction);
        }
        
        if (window.logManager) {
            window.logManager.addLog(`🔵 트레이너: 현재 구역(${currentZone})에서 의사 결정 없음 → 랜덤 액션: ${targetAction}`);
        }
        
        // 트레이너 대화창 업데이트
        if (window.trainerDialog) {
            const currentTime = new Date().toLocaleTimeString();
            const dialogText = `🎲 트레이너: 랜덤 액션 선택 → ${targetAction} | 시간: ${currentTime}`;
            window.trainerDialog.setText(dialogText);
            
            // 화면 출력 내용을 로그에 저장
            if (window.logManager) {
                window.logManager.addLog(`📺 화면출력(트레이너대화창): ${dialogText}`);
            }
        }
        
        return targetAction;
    }

    // 구역 의사결정 처리
    handleZoneDecision(model, zoneDecision, currentZone, currentMajority) {
        const targetAction = zoneDecision.action;
        model.targetAction = targetAction;
        model.targetX = zoneDecision.targetX;
        model.targetY = zoneDecision.targetY;
        
        // 디버깅: 목표 위치 설정 확인
        if (window.logManager) {
            window.logManager.addLog(`🎯 의사결정: ${targetAction} → 목표 위치 (${Math.round(model.targetX)}, ${Math.round(model.targetY)})`);
        }
        
        // 색상 변경
        if (window.trainerVisualEffects) {
            window.trainerVisualEffects.changeTrainerColor(model, targetAction);
        }
        
        // 트레이너 의사결정 로그
        if (window.trainerActivityLogger) {
            window.trainerActivityLogger.logDecision(targetAction, `구역: ${currentZone}, 신호: ${currentMajority}`);
        }
        
        // 트레이너 대화창 업데이트
        if (window.trainerDialog) {
            const currentTime = new Date().toLocaleTimeString();
            const dialogText = `🎯 트레이너: 의사결정 → ${targetAction} | 구역: ${currentZone} | 시간: ${currentTime}`;
            window.trainerDialog.setText(dialogText);
            
            // 화면 출력 내용을 로그에 저장
            if (window.logManager) {
                window.logManager.addLog(`📺 화면출력(트레이너대화창): ${dialogText}`);
            }
        }
        
        return targetAction;
    }

    // 카운트다운 처리
    handleCountdown(model, config) {
        const targetAction = '신호 대기';
        model.targetAction = targetAction;
        model.targetX = config.width / 2;
        model.targetY = config.height / 2;
        
        if (window.trainerVisualEffects) {
            window.trainerVisualEffects.changeTrainerColor(model, targetAction);
        }
        
        return targetAction;
    }

    // 신호 대기 상태 처리
    handleSignalWaiting(model, config) {
        const distanceToCenter = Math.sqrt((model.circle.x - (config.width / 2)) ** 2 + (model.circle.y - (config.height / 2)) ** 2);
        
        // 현재 위치와 신호 대기 센터까지의 거리 로그
        if (window.logManager) {
            const currentPos = `(${Math.round(model.circle.x)}, ${Math.round(model.circle.y)})`;
            const centerPos = `(${Math.round(config.width / 2)}, ${Math.round(config.height / 2)})`;
            window.logManager.addLog(`⏳ 신호 대기: 현재위치 ${currentPos} | 센터위치 ${centerPos} | 센터까지거리 ${Math.round(distanceToCenter)}px`);
        }
        
        if (distanceToCenter < 30) {
            // 신호 대기 센터에 도달했을 때
            if (!this.waitCheckTimer) {
                this.waitCheckTimer = 0;
                this.waitStartTime = Date.now();
            }
            this.waitCheckTimer++;
            this.countdownStarted = true;
            
            const elapsedSeconds = (Date.now() - this.waitStartTime) / 1000;
            
            // 5초 이상 대기하면 BTC 시장으로 이동
            if (elapsedSeconds >= 5) {
                this.btcExplorationMode = true;
                this.countdownStarted = false;
                
                if (window.trainerMovementController) {
                    window.trainerMovementController.moveToBTCMarket(model, config);
                }
                
                if (window.logManager) {
                    window.logManager.addLog(`🔵 트레이너: 신호 대기 센터에서 5초 이상 대기 → BTC 시장 탐색 구역으로 이동!`);
                }
            }
        } else if (distanceToCenter > 50 && !this.countdownStarted) {
            this.waitCheckTimer = 0;
        }
    }

    // BTC 시장 탐색 모드 처리
    handleBTCMarketExploration(model, config) {
        const distanceToBTCMarket = Math.sqrt((model.circle.x - (config.width - 100)) ** 2 + (model.circle.y - (config.height - 100)) ** 2);
        
        // 현재 위치와 목표 정보 로그
        if (window.logManager) {
            const currentPos = `(${Math.round(model.circle.x)}, ${Math.round(model.circle.y)})`;
            const targetPos = `(${Math.round(model.targetX)}, ${Math.round(model.targetY)})`;
            const distanceToTarget = Math.sqrt((model.targetX - model.circle.x) ** 2 + (model.targetY - model.circle.y) ** 2);
            window.logManager.addLog(`📍 트레이너 위치: ${currentPos} | 목표: ${targetPos} | 목표까지 거리: ${Math.round(distanceToTarget)}px | BTC시장까지 거리: ${Math.round(distanceToBTCMarket)}px`);
        }
        
        // BTC 시장 충돌 검사
        let isCollidingWithBTCMarket = false;
        if (window.btcMarketPolygon && model.circle) {
            const circleBounds = model.circle.getBounds();
            const polygonBounds = window.btcMarketPolygon.getBounds();
            isCollidingWithBTCMarket = Phaser.Geom.Rectangle.Overlaps(circleBounds, polygonBounds);
            
            if (isCollidingWithBTCMarket) {
                const centerDistance = Math.sqrt(
                    (model.circle.x - window.btcMarketPolygon.x) ** 2 + 
                    (model.circle.y - window.btcMarketPolygon.y) ** 2
                );
                if (centerDistance > 50) {
                    isCollidingWithBTCMarket = false;
                }
            }
        }
        
        // BTC 시장 근처에 있는지 로그 출력 (디버깅용)
        if (distanceToBTCMarket < 100 && window.logManager) {
            window.logManager.addLog(`🔍 BTC 시장 탐색 구역 근처: 거리 ${Math.round(distanceToBTCMarket)}px, 충돌: ${isCollidingWithBTCMarket}`);
        }
        
        // BTC 시장에 도달했는지 확인
        if (isCollidingWithBTCMarket || distanceToBTCMarket < 60) {
            // BTC 시장 탐색 모드가 아니어도 도달하면 수익률 계산 실행
            if (this.btcExplorationMode) {
                this.btcExplorationMode = false;
            }
            
            if (window.logManager) {
                window.logManager.addLog(`🎯 트레이너가 BTC 시장 탐색 구역에 도달! 매수 전 예상 수익률 계산 시작`);
            }
            
            // 매수/매도 전 예상 수익률 계산
            this.calculateBuyProfitRate(model, config);
            this.calculateSellProfitRate(model, config);
        }
    }
    
    // 매수 전 예상 수익률 계산
    calculateBuyProfitRate(model, config) {
        // 현재 위치 정보 로그
        if (window.logManager) {
            const currentPos = `(${Math.round(model.circle.x)}, ${Math.round(model.circle.y)})`;
            const btcMarketPos = `(${Math.round(config.width - 100)}, ${Math.round(config.height - 100)})`;
            const distanceToBTCMarket = Math.sqrt((model.circle.x - (config.width - 100)) ** 2 + (model.circle.y - (config.height - 100)) ** 2);
            window.logManager.addLog(`📊 수익률 계산 시작: 현재위치 ${currentPos} | BTC시장위치 ${btcMarketPos} | BTC시장까지거리 ${Math.round(distanceToBTCMarket)}px`);
        }
        
        // 실제 거래 데이터 가져오기
        const majorityElement = document.getElementById('majority-zone');
        const currentPriceElement = document.getElementById('right-trading-current-price');
        const priceChangeElement = document.getElementById('right-trading-price-change');
        const currentZoneElement = document.getElementById('right-trading-current-zone');
        const zoneStrengthElement = document.getElementById('right-trading-zone-strength');
        const btcBalanceElement = document.getElementById('btc-balance');
        const krwBalanceElement = document.getElementById('krw-balance');
        const avgPriceElement = document.getElementById('selected-coin-avg-price');
        const pnlElement = document.getElementById('selected-coin-pnl');
        
        if (!majorityElement || !currentPriceElement) {
            if (window.logManager) {
                window.logManager.addLog(`❌ BTC 시장 데이터를 가져올 수 없음`);
            }
            return;
        }
        
        // 실제 거래 데이터 파싱
        const currentMajority = majorityElement.textContent.trim();
        const currentPriceText = currentPriceElement.textContent;
        const priceChangeText = priceChangeElement ? priceChangeElement.textContent : '0%';
        const currentZone = currentZoneElement ? currentZoneElement.textContent : 'Unknown';
        const zoneStrength = zoneStrengthElement ? zoneStrengthElement.textContent.match(/\d+/)?.[0] || '0' : '0';
        const btcBalance = btcBalanceElement ? parseFloat(btcBalanceElement.textContent.match(/[\d.]+/)?.[0] || '0') : 0;
        const krwBalance = krwBalanceElement ? parseFloat(krwBalanceElement.textContent.match(/[\d,]+/)?.[0].replace(/,/g, '') || '0') : 0;
        const avgPriceText = avgPriceElement ? avgPriceElement.textContent : '';
        const pnlText = pnlElement ? pnlElement.textContent : '';
        
        // 현재 가격 파싱
        const currentPrice = parseFloat(currentPriceText.replace(/[₩,]/g, ''));
        
        // 평균 단가 파싱
        const avgPriceMatch = avgPriceText.match(/[\d,]+/);
        const avgPrice = avgPriceMatch ? parseFloat(avgPriceMatch[0].replace(/,/g, '')) : currentPrice;
        
        // N/B 코인 개수 가져오기
        const nbCoins = window.gameInitializer ? window.gameInitializer.gameData.nbCoins : 0;
        
        // 매수 전 예상 수익률 계산 로직 (실제 데이터 기반)
        let buyProfitRate = 0;
        
        // 1. 현재 수익률 기반 (실제 보유 자산 기준)
        if (btcBalance > 0 && avgPrice > 0) {
            const currentProfitRate = ((currentPrice - avgPrice) / avgPrice) * 100;
            buyProfitRate += currentProfitRate * 0.3; // 현재 수익률의 30% 반영
        }
        
        // 2. 시장 신호에 따른 기본 수익률
        if (currentMajority.includes('BLUE')) {
            buyProfitRate += 1.5 + Math.random() * 2; // 1.5% ~ 3.5%
        } else if (currentMajority.includes('ORANGE')) {
            buyProfitRate += 0.5 + Math.random() * 1.5; // 0.5% ~ 2%
        } else {
            buyProfitRate += -0.5 + Math.random() * 1; // -0.5% ~ 0.5%
        }
        
        // 3. 가격 변동률 반영
        const priceChangeMatch = priceChangeText.match(/-?[\d.]+/);
        if (priceChangeMatch) {
            const priceChange = parseFloat(priceChangeMatch[0]);
            buyProfitRate += priceChange * 0.5; // 가격 변동률의 50% 반영
        }
        
        // 4. 구역 강도 반영
        const strength = parseInt(zoneStrength);
        if (strength > 0) {
            buyProfitRate += (strength - 50) * 0.02; // 강도 50 기준으로 ±1% 보정
        }
        
        // 5. N/B 코인 개수에 따른 보정
        if (nbCoins > 0) {
            buyProfitRate += (nbCoins * 0.05); // 코인 1개당 0.05% 추가
        }
        
        // 6. 포트폴리오 비율 반영
        const totalValue = (btcBalance * currentPrice) + krwBalance;
        if (totalValue > 0) {
            const btcRatio = (btcBalance * currentPrice) / totalValue;
            if (btcRatio > 0.8) {
                buyProfitRate -= 0.5; // BTC 비중이 높으면 매수 신중
            } else if (btcRatio < 0.2) {
                buyProfitRate += 0.5; // BTC 비중이 낮으면 매수 적극
            }
        }
        
        // 수익률 범위 제한 (-10% ~ 15%)
        buyProfitRate = Math.max(-10, Math.min(15, buyProfitRate));
        
        // 비정상적인 수익률 값 검증
        if (buyProfitRate < -10 || buyProfitRate > 15) {
            console.warn(`⚠️ 비정상적인 매수 수익률 감지: ${buyProfitRate.toFixed(2)}%, 0으로 재설정`);
            buyProfitRate = 0;
        }
        
        // 계산된 수익률을 전역 변수에 저장
        if (window.gameInitializer && window.gameInitializer.gameData) {
            window.gameInitializer.gameData.buyProfitRate = buyProfitRate;
        }
        
        // UI 업데이트
        if (window.buyProfitRateDisplay) {
            const profitRateText = `매수 전 예상 수익률: ${buyProfitRate.toFixed(2)}%`;
            window.buyProfitRateDisplay.setText(profitRateText);
            
            // 화면 출력 내용을 로그에 저장
            if (window.logManager) {
                window.logManager.addLog(`📺 화면출력(매수수익률): ${profitRateText}`);
            }
        }
        
        // 상세 계산 로그
        if (window.logManager) {
            window.logManager.addLog(`📊 매수 전 예상 수익률 계산 상세:`);
            window.logManager.addLog(`  - 현재가: ₩${currentPrice.toLocaleString()}`);
            window.logManager.addLog(`  - 평균단가: ₩${avgPrice.toLocaleString()}`);
            window.logManager.addLog(`  - BTC 보유량: ${btcBalance} BTC`);
            window.logManager.addLog(`  - KRW 보유량: ₩${krwBalance.toLocaleString()}`);
            window.logManager.addLog(`  - 시장 신호: ${currentMajority}`);
            window.logManager.addLog(`  - 구역: ${currentZone} (강도: ${zoneStrength})`);
            window.logManager.addLog(`  - 가격변동: ${priceChangeText}`);
            window.logManager.addLog(`  - N/B 코인: ${nbCoins}개`);
            window.logManager.addLog(`  - 최종 예상 수익률: ${buyProfitRate.toFixed(2)}%`);
        }
        
        // 매수 수익률 계산 상세 로그 파일 작성
        const buyLogContent = `매수 수익률 계산 상세 분석:
1. 현재 수익률 기반: ${btcBalance > 0 && avgPrice > 0 ? ((currentPrice - avgPrice) / avgPrice * 100).toFixed(2) + '% (30% 반영)' : 'N/A'}
2. 시장 신호 기반: ${currentMajority} (${currentMajority.includes('BLUE') ? '1.5~3.5%' : currentMajority.includes('ORANGE') ? '0.5~2%' : '-0.5~0.5%'})
3. 가격 변동률 반영: ${priceChangeText} (50% 반영)
4. 구역 강도 반영: ${zoneStrength} (강도 50 기준 ±1% 보정)
5. N/B 코인 보정: ${nbCoins}개 (코인 1개당 +0.05%)
6. 포트폴리오 비율: BTC ${btcBalance > 0 ? ((btcBalance * currentPrice) / ((btcBalance * currentPrice) + krwBalance) * 100).toFixed(1) + '%' : '0%'}
7. 최종 예상 수익률: ${buyProfitRate.toFixed(2)}%

계산 근거:
- 현재가: ₩${currentPrice.toLocaleString()}
- 평균단가: ₩${avgPrice.toLocaleString()}
- BTC 보유량: ${btcBalance} BTC
- KRW 보유량: ₩${krwBalance.toLocaleString()}
- 시장 신호: ${currentMajority}
- 구역: ${currentZone} (강도: ${zoneStrength})
- 가격변동: ${priceChangeText}
- N/B 코인: ${nbCoins}개`;
        
        this.writeProfitRateLog(this.buyProfitLogFile, buyLogContent);
        
        // 트레이너 대화창 업데이트
        if (window.trainerDialog) {
            const currentTime = new Date().toLocaleTimeString();
            const dialogText = `📊 BTC 시장 탐색: 매수 전 예상 수익률 ${buyProfitRate.toFixed(2)}% | 현재가: ₩${currentPrice.toLocaleString()} | 시간: ${currentTime}`;
            window.trainerDialog.setText(dialogText);
            
            // 화면 출력 내용을 로그에 저장
            if (window.logManager) {
                window.logManager.addLog(`📺 화면출력(트레이너대화창): ${dialogText}`);
            }
        }
        
        // 계산 완료 후 신호 대기 센터로 이동
        if (window.trainerMovementController) {
            window.trainerMovementController.moveToSignalCenter(model, config);
            
            // 이동 목표 정보 로그
            if (window.logManager) {
                const currentPos = `(${Math.round(model.circle.x)}, ${Math.round(model.circle.y)})`;
                const signalCenterPos = `(${Math.round(config.width / 2)}, ${Math.round(config.height / 2)})`;
                const distanceToSignalCenter = Math.sqrt((model.circle.x - (config.width / 2)) ** 2 + (model.circle.y - (config.height / 2)) ** 2);
                window.logManager.addLog(`🔄 신호 대기 센터로 이동: 현재위치 ${currentPos} | 센터위치 ${signalCenterPos} | 센터까지거리 ${Math.round(distanceToSignalCenter)}px`);
            }
        }
        
        // 트레이너 역할 텍스트 업데이트
        model.targetAction = '매수 수익률 계산 완료';
        if (model.role) {
            model.role.setText(`트레이너 (매수 수익률 계산 완료)`);
        }
        
        // 새로운 의사결정 필요 플래그 설정
        model.needsNewDecision = true;
        model.arrivalLogged = false;
        
        if (window.logManager) {
            window.logManager.addLog(`🔄 수익률 계산 완료 - 새로운 의사결정 필요 플래그 설정`);
        }
    }
    
    // 매도 전 예상 수익률 계산
    calculateSellProfitRate(model, config) {
        // 실제 거래 데이터 가져오기
        const majorityElement = document.getElementById('majority-zone');
        const currentPriceElement = document.getElementById('right-trading-current-price');
        const priceChangeElement = document.getElementById('right-trading-price-change');
        const currentZoneElement = document.getElementById('right-trading-current-zone');
        const zoneStrengthElement = document.getElementById('right-trading-zone-strength');
        const btcBalanceElement = document.getElementById('btc-balance');
        const krwBalanceElement = document.getElementById('krw-balance');
        const avgPriceElement = document.getElementById('selected-coin-avg-price');
        const pnlElement = document.getElementById('selected-coin-pnl');
        
        if (!majorityElement || !currentPriceElement) {
            if (window.logManager) {
                window.logManager.addLog(`❌ BTC 시장 데이터를 가져올 수 없음`);
            }
            return;
        }
        
        // 실제 거래 데이터 파싱
        const currentMajority = majorityElement.textContent.trim();
        const currentPriceText = currentPriceElement.textContent;
        const priceChangeText = priceChangeElement ? priceChangeElement.textContent : '0%';
        const currentZone = currentZoneElement ? currentZoneElement.textContent : 'Unknown';
        const zoneStrength = zoneStrengthElement ? zoneStrengthElement.textContent.match(/\d+/)?.[0] || '0' : '0';
        const btcBalance = btcBalanceElement ? parseFloat(btcBalanceElement.textContent.match(/[\d.]+/)?.[0] || '0') : 0;
        const krwBalance = krwBalanceElement ? parseFloat(krwBalanceElement.textContent.match(/[\d,]+/)?.[0].replace(/,/g, '') || '0') : 0;
        const avgPriceText = avgPriceElement ? avgPriceElement.textContent : '';
        
        // 현재 가격 파싱
        const currentPrice = parseFloat(currentPriceText.replace(/[₩,]/g, ''));
        
        // 평균 단가 파싱
        const avgPriceMatch = avgPriceText.match(/[\d,]+/);
        const avgPrice = avgPriceMatch ? parseFloat(avgPriceMatch[0].replace(/,/g, '')) : currentPrice;
        
        // N/B 코인 개수 가져오기
        const nbCoins = window.gameInitializer ? window.gameInitializer.gameData.nbCoins : 0;
        
        // 매도 전 예상 수익률 계산 로직 (실제 데이터 기반)
        let sellProfitRate = 0;
        
        // 1. 현재 수익률 기반 (실제 보유 자산 기준)
        if (btcBalance > 0 && avgPrice > 0) {
            const currentProfitRate = ((currentPrice - avgPrice) / avgPrice) * 100;
            sellProfitRate += currentProfitRate * 0.5; // 현재 수익률의 50% 반영 (매도는 더 민감)
        }
        
        // 2. 시장 신호에 따른 기본 수익률 (매도는 반대)
        if (currentMajority.includes('BLUE')) {
            sellProfitRate += -1.0 + Math.random() * 1; // -1% ~ 0%
        } else if (currentMajority.includes('ORANGE')) {
            sellProfitRate += -0.5 + Math.random() * 0.5; // -0.5% ~ 0%
        } else {
            sellProfitRate += 0.5 + Math.random() * 1; // 0.5% ~ 1.5%
        }
        
        // 3. 가격 변동률 반영 (매도는 반대)
        const priceChangeMatch = priceChangeText.match(/-?[\d.]+/);
        if (priceChangeMatch) {
            const priceChange = parseFloat(priceChangeMatch[0]);
            sellProfitRate -= priceChange * 0.3; // 가격 상승 시 매도 유리
        }
        
        // 4. 구역 강도 반영 (매도는 반대)
        const strength = parseInt(zoneStrength);
        if (strength > 0) {
            sellProfitRate -= (strength - 50) * 0.01; // 강도 높을 때 매도 유리
        }
        
        // 5. N/B 코인 개수에 따른 보정
        if (nbCoins > 0) {
            sellProfitRate += (nbCoins * 0.03); // 코인 1개당 0.03% 추가
        }
        
        // 6. 포트폴리오 비율 반영
        const totalValue = (btcBalance * currentPrice) + krwBalance;
        if (totalValue > 0) {
            const btcRatio = (btcBalance * currentPrice) / totalValue;
            if (btcRatio > 0.8) {
                sellProfitRate += 0.3; // BTC 비중이 높으면 매도 유리
            } else if (btcRatio < 0.2) {
                sellProfitRate -= 0.3; // BTC 비중이 낮으면 매도 불리
            }
        }
        
        // 수익률 범위 제한 (-15% ~ 10%)
        sellProfitRate = Math.max(-15, Math.min(10, sellProfitRate));
        
        // 비정상적인 수익률 값 검증
        if (sellProfitRate < -15 || sellProfitRate > 10) {
            console.warn(`⚠️ 비정상적인 매도 수익률 감지: ${sellProfitRate.toFixed(2)}%, 0으로 재설정`);
            sellProfitRate = 0;
        }
        
        // 계산된 수익률을 전역 변수에 저장
        if (window.gameInitializer && window.gameInitializer.gameData) {
            window.gameInitializer.gameData.sellProfitRate = sellProfitRate;
        }
        
        // UI 업데이트
        if (window.sellProfitRateDisplay) {
            const profitRateText = `매도 전 예상 수익률: ${sellProfitRate.toFixed(2)}%`;
            window.sellProfitRateDisplay.setText(profitRateText);
            
            // 화면 출력 내용을 로그에 저장
            if (window.logManager) {
                window.logManager.addLog(`📺 화면출력(매도수익률): ${profitRateText}`);
            }
        }
        
        // 상세 계산 로그
        if (window.logManager) {
            window.logManager.addLog(`📊 매도 전 예상 수익률 계산 상세:`);
            window.logManager.addLog(`  - 현재가: ₩${currentPrice.toLocaleString()}`);
            window.logManager.addLog(`  - 평균단가: ₩${avgPrice.toLocaleString()}`);
            window.logManager.addLog(`  - BTC 보유량: ${btcBalance} BTC`);
            window.logManager.addLog(`  - KRW 보유량: ₩${krwBalance.toLocaleString()}`);
            window.logManager.addLog(`  - 시장 신호: ${currentMajority}`);
            window.logManager.addLog(`  - 구역: ${currentZone} (강도: ${zoneStrength})`);
            window.logManager.addLog(`  - 가격변동: ${priceChangeText}`);
            window.logManager.addLog(`  - N/B 코인: ${nbCoins}개`);
            window.logManager.addLog(`  - 최종 예상 수익률: ${sellProfitRate.toFixed(2)}%`);
        }
        
        // 매도 수익률 계산 상세 로그 파일 작성
        const sellLogContent = `매도 수익률 계산 상세 분석:
1. 현재 수익률 기반: ${btcBalance > 0 && avgPrice > 0 ? ((currentPrice - avgPrice) / avgPrice * 100).toFixed(2) + '% (50% 반영)' : 'N/A'}
2. 시장 신호 기반: ${currentMajority} (${currentMajority.includes('BLUE') ? '-1~0%' : currentMajority.includes('ORANGE') ? '-0.5~0%' : '0.5~1.5%'})
3. 가격 변동률 반영: ${priceChangeText} (반대 방향 30% 반영)
4. 구역 강도 반영: ${zoneStrength} (강도 높을 때 매도 유리)
5. N/B 코인 보정: ${nbCoins}개 (코인 1개당 +0.03%)
6. 포트폴리오 비율: BTC ${btcBalance > 0 ? ((btcBalance * currentPrice) / ((btcBalance * currentPrice) + krwBalance) * 100).toFixed(1) + '%' : '0%'}
7. 최종 예상 수익률: ${sellProfitRate.toFixed(2)}%

계산 근거:
- 현재가: ₩${currentPrice.toLocaleString()}
- 평균단가: ₩${avgPrice.toLocaleString()}
- BTC 보유량: ${btcBalance} BTC
- KRW 보유량: ₩${krwBalance.toLocaleString()}
- 시장 신호: ${currentMajority}
- 구역: ${currentZone} (강도: ${zoneStrength})
- 가격변동: ${priceChangeText}
- N/B 코인: ${nbCoins}개`;
        
        this.writeProfitRateLog(this.sellProfitLogFile, sellLogContent);
        
        // 트레이너 대화창 업데이트
        if (window.trainerDialog) {
            const currentTime = new Date().toLocaleTimeString();
            const dialogText = `📊 BTC 시장 탐색: 매도 전 예상 수익률 ${sellProfitRate.toFixed(2)}% | 현재가: ₩${currentPrice.toLocaleString()} | 시간: ${currentTime}`