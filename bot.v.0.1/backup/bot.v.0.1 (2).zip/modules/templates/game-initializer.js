// Game Initializer Module
// Phaser 게임 초기화 및 기본 화면 구현을 담당

class GameInitializer {
    constructor() {
        this.game = null;
        this.scene = null;
        this.aiModels = [];
        this.nbCoinItems = [];
        this.gameData = {
            nbCoins: 0,
            nbMinerals: 0.0,
            buyPrice: 0,
            buyProfitRate: 0,
            sellProfitRate: 0,
            lastBuyAction: false,
            lastSellAction: false
        };
        
        // 자동 저장 관련 변수 (game-state-manager.js에서 처리)
        this.autoSaveInterval = null;
        this.lastSaveTime = Date.now();
        this.saveIntervalMs = 30000; // 30초마다 자동 저장
    }

    // 게임 초기화
    initializeGame(container) {
        console.log('🎮 Game Initializer: 게임 초기화 시작');
        
        if (typeof Phaser === 'undefined') {
            console.error('❌ Phaser library not loaded');
            return;
        }

        // 기존 게임이 있으면 제거
        if (window.floatingBallGame) {
            console.log('🧹 기존 게임 인스턴스 정리 중...');
            window.floatingBallGame.destroy(true);
            window.floatingBallGame = null;
        }
        
        // 기존 AI 모델들도 정리
        if (this.aiModels && this.aiModels.length > 0) {
            console.log(`🧹 기존 AI 모델 ${this.aiModels.length}개 정리 중...`);
            this.aiModels.forEach(model => {
                if (model.circle) model.circle.destroy();
                if (model.name) model.name.destroy();
                if (model.role) model.role.destroy();
            });
            this.aiModels = [];
        }

        // 게임 씬 클래스 정의
        class GameScene extends Phaser.Scene {
            constructor() {
                super({ key: 'GameScene' });
            }

            create() {
                console.log('🎮 Scene created, initializing game scene...');
                this.gameInitializer.scene = this;
                this.gameInitializer.createGameScene();
            }

            update() {
                if (this.gameInitializer) {
                    this.gameInitializer.updateGame();
                }
            }
        }

        const config = {
            type: Phaser.AUTO,
            parent: 'floating-ball-game',
            width: container.offsetWidth || 1086,
            height: 500,
            backgroundColor: '#000011',
            disableContextMenu: true,
            input: {
                mouse: {
                    preventDefaultWheel: false
                }
            },
            physics: {
                default: 'arcade',
                arcade: {
                    gravity: { y: 0 },
                    debug: false
                }
            },
            scene: GameScene
        };

        // 씬에 게임 초기화자 참조 전달
        GameScene.prototype.gameInitializer = this;

        this.game = new Phaser.Game(config);
        window.floatingBallGame = this.game;
        
        console.log('🎮 Game Initializer: 게임 초기화 완료');
    }

    // 게임 씬 생성
    createGameScene() {
        console.log('🎮 Game Initializer: 게임 씬 생성 시작');
        
        if (!this.scene) {
            console.error('❌ Scene is not initialized');
            return;
        }
        
        try {
            // 2D 맵 그리드 생성
            this.createGrid();
            
            // 게임 영역 생성
            this.createGameAreas();
            
            // AI 모델들 생성
            this.createAIModels();
            
            // UI 요소들 생성
            this.createUIElements();
            
            // 이벤트 리스너 설정
            this.setupEventListeners();
            
            // 게임 루프 시작
            this.startGameLoop();
            
            // 트레이너 모듈 초기화
            if (typeof initializeTrainerModules === 'function') {
                initializeTrainerModules();
            }
            
            // 게임 상태 관리자 초기화
            if (window.gameStateManager) {
                window.gameStateManager.initializeGameState();
            }
            
            console.log('🎮 Game Initializer: 게임 씬 생성 완료');
        } catch (error) {
            console.error('❌ Error creating game scene:', error);
        }
    }

    // 2D 맵 그리드 생성
    createGrid() {
        if (!this.scene || !this.game) {
            console.error('❌ Scene or game not initialized for grid creation');
            return;
        }
        
        const gridSize = 20;
        const cols = Math.floor(this.game.config.width / gridSize);
        const rows = Math.floor(this.game.config.height / gridSize);
        
        try {
            const graphics = this.scene.add.graphics();
            graphics.lineStyle(1, 0x00ff00, 0.3);
            
            for (let i = 0; i <= cols; i++) {
                graphics.moveTo(i * gridSize, 0);
                graphics.lineTo(i * gridSize, this.game.config.height);
            }
            
            for (let i = 0; i <= rows; i++) {
                graphics.moveTo(0, i * gridSize);
                graphics.lineTo(this.game.config.width, i * gridSize);
            }
            
            console.log('✅ Grid created successfully');
        } catch (error) {
            console.error('❌ Error creating grid:', error);
        }
    }

    // 게임 영역 생성
    createGameAreas() {
        if (!this.scene || !this.game) {
            console.error('❌ Scene or game not initialized for game areas creation');
            return;
        }
        
        const config = this.game.config;
        
        // N/B 길드 다각형 (좌상단)
        const guildPolygon = this.scene.add.polygon(100, 100, [
            0, -30, 22, -15, 22, 15, 0, 30, -22, 15, -22, -15
        ], 0x00ff00);
        guildPolygon.setOrigin(0.5, 0.5);
        window.nbGuildPolygon = guildPolygon;
        
        // N/B 길드 내부 구역 표시 원
        const guildZoneIndicator = this.scene.add.circle(100, 100, 15, 0x00d1ff);
        guildZoneIndicator.setOrigin(0.5, 0.5);
        
        // N/B 길드 내부 구역 텍스트
        const guildZoneText = this.scene.add.text(100, 100, 'BLUE', {
            fontSize: '8px',
            fill: '#ffffff',
            fontStyle: 'bold'
        }).setOrigin(0.5);
        
        // BTC 시장 다각형 (우하단)
        const marketPolygon = this.scene.add.polygon(config.width - 100, config.height - 100, [
            0, -35, 25, -17, 25, 17, 0, 35, -25, 17, -25, -17
        ], 0x0088ff);
        marketPolygon.setOrigin(0.5, 0.5);
        window.btcMarketPolygon = marketPolygon;
        
        // 상단 매수/매도/대기 4각형들
        const spacing = 120;
        const startX = (config.width - (spacing * 2)) / 2;
        const topY = 60;
        
        const buyPolygon = this.scene.add.polygon(startX, topY, [
            -20, -18, 20, -18, 20, 18, -20, 18
        ], 0x00ff00);
        buyPolygon.setOrigin(0.5, 0.5);
        
        const sellPolygon = this.scene.add.polygon(startX + spacing, topY, [
            -20, -18, 20, -18, 20, 18, -20, 18
        ], 0xff0000);
        sellPolygon.setOrigin(0.5, 0.5);
        
        const waitPolygon = this.scene.add.polygon(startX + spacing * 2, topY, [
            -20, -18, 20, -18, 20, 18, -20, 18
        ], 0xffff00);
        waitPolygon.setOrigin(0.5, 0.5);
        
        // 신호 대기 센터 (화면 중앙)
        const centerX = config.width / 2;
        const centerY = config.height / 2;
        
        const signalWaitCenter = this.scene.add.circle(centerX, centerY, 40, 0x88ccff);
        signalWaitCenter.setStrokeStyle(3, 0xffffff);
        
        // 라벨들 추가
        this.scene.add.text(100, 140, 'N/B 길드', {
            fontSize: '12px',
            fill: '#00ff00'
        }).setOrigin(0.5);
        
        this.scene.add.text(config.width - 100, config.height - 140, 'BTC 시장 탐색 구역', {
            fontSize: '12px',
            fill: '#0088ff'
        }).setOrigin(0.5);
        
        this.scene.add.text(startX, topY + 30, '매수', {
            fontSize: '10px',
            fill: '#00ff00'
        }).setOrigin(0.5);
        
        this.scene.add.text(startX + spacing, topY + 30, '매도', {
            fontSize: '10px',
            fill: '#ff0000'
        }).setOrigin(0.5);
        
        this.scene.add.text(startX + spacing * 2, topY + 30, '대기', {
            fontSize: '10px',
            fill: '#ffff00'
        }).setOrigin(0.5);
        
        this.scene.add.text(centerX, centerY - 10, '신호 대기', {
            fontSize: '12px',
            fill: '#ffffff',
            fontStyle: 'bold'
        }).setOrigin(0.5);
        
        this.scene.add.text(centerX, centerY + 10, '센터', {
            fontSize: '12px',
            fill: '#ffffff',
            fontStyle: 'bold'
        }).setOrigin(0.5);
        
        // 애니메이션 추가
        this.scene.tweens.add({
            targets: guildPolygon,
            rotation: Math.PI * 2,
            duration: 8000,
            repeat: -1,
            ease: 'Linear'
        });
        
        this.scene.tweens.add({
            targets: marketPolygon,
            rotation: -Math.PI * 2,
            duration: 6000,
            repeat: -1,
            ease: 'Linear'
        });
        
        this.scene.tweens.add({
            targets: [buyPolygon, sellPolygon, waitPolygon],
            rotation: Math.PI * 2,
            duration: 10000,
            repeat: -1,
            ease: 'Linear'
        });
    }

    // AI 모델들 생성
    createAIModels() {
        if (!this.scene || !this.game) {
            console.error('❌ Scene or game not initialized for AI models creation');
            return;
        }
        
        // 기존 AI 모델들 정리 (중복 생성 방지)
        if (this.aiModels && this.aiModels.length > 0) {
            console.log(`🧹 기존 AI 모델 ${this.aiModels.length}개 정리 중...`);
            this.aiModels.forEach(model => {
                if (model.circle) model.circle.destroy();
                if (model.name) model.name.destroy();
                if (model.role) model.role.destroy();
            });
            this.aiModels = [];
        }
        
        // 저장된 상태에서 AI 모델 복원 시도
        if (window.gameStateManager && this.scene) {
            const savedState = window.gameStateManager.loadGameState();
            if (savedState && savedState.aiModels && savedState.aiModels.length > 0) {
                try {
                    this.aiModels = window.gameStateManager.convertAiModelsFromStorage(savedState.aiModels, this.scene);
                    
                    // 복원된 모델들에 애니메이션 추가
                    this.aiModels.forEach(model => {
                        this.scene.tweens.add({
                            targets: [model.circle, model.name, model.role],
                            scaleX: 1.1,
                            scaleY: 1.1,
                            duration: 2000 + Math.random() * 1000,
                            yoyo: true,
                            repeat: -1
                        });
                    });
                    
                    console.log(`🔄 AI 모델들 저장된 상태에서 복원됨 (총 ${this.aiModels.length}개)`);
                    return;
                } catch (error) {
                    console.error('❌ AI 모델 복원 중 오류:', error);
                    // 오류 발생 시 새로 생성하도록 계속 진행
                }
            }
        }
        
        // 저장된 상태가 없으면 새로 생성
        const config = this.game.config;
        const modelColors = [0xff8800, 0x00ff88, 0x8800ff, 0xff0088, 0xffff00];
        const modelNames = ['Explorer-1', 'Explorer-2', 'Explorer-3', 'Explorer-4', 'Trainer'];
        const modelRoles = ['탐색', '탐색', '탐색', '탐색', '트레이너'];
        
        const initialPositions = [
            { x: config.width / 2, y: config.height / 2 },
            { x: config.width / 4, y: config.height / 4 },
            { x: config.width * 3/4, y: config.height / 4 },
            { x: config.width / 4, y: config.height * 3/4 },
            { x: config.width * 3/4, y: config.height * 3/4 }
        ];
        
        for (let i = 0; i < 5; i++) {
            const circleRadius = i === 4 ? 20 : 10; // 트레이너는 20, 탐색자는 10
            const fontSize = i === 4 ? '8px' : '6px';
            const roleFontSize = i === 4 ? '6px' : '5px';
            
            const model = {
                circle: this.scene.add.circle(initialPositions[i].x, initialPositions[i].y, circleRadius, modelColors[i]),
                name: this.scene.add.text(initialPositions[i].x, initialPositions[i].y - (i === 4 ? 6 : 4), modelNames[i], {
                    fontSize: fontSize,
                    fill: '#ffffff',
                    fontStyle: 'bold'
                }).setOrigin(0.5),
                role: this.scene.add.text(initialPositions[i].x, initialPositions[i].y + (i === 4 ? 6 : 4), modelRoles[i], {
                    fontSize: roleFontSize,
                    fill: '#ffffff'
                }).setOrigin(0.5),
                targetX: initialPositions[i].x,
                targetY: initialPositions[i].y,
                targetAction: i === 4 ? '신호 대기' : '',
                isExplorer: i < 4,
                isTrainer: i === 4,
                discoveredCoords: [],
                memoryIndex: 0,
                explorationTimer: 0,
                needsNewDecision: i === 4 ? false : false,
                arrivalLogged: i === 4 ? false : false
            };
            
            model.circle.setOrigin(0.5, 0.5);
            this.aiModels.push(model);
            
            // 크기 변화 애니메이션
            this.scene.tweens.add({
                targets: [model.circle, model.name, model.role],
                scaleX: 1.1,
                scaleY: 1.1,
                duration: 2000 + Math.random() * 1000,
                yoyo: true,
                repeat: -1
            });
        }
        
        console.log(`🆕 AI 모델들 새로 생성됨 (탐색자 ${this.aiModels.filter(m => m.isExplorer).length}명, 트레이너 ${this.aiModels.filter(m => m.isTrainer).length}명, 총 ${this.aiModels.length}개)`);
    }

    // UI 요소들 생성
    createUIElements() {
        if (!this.scene || !this.game) {
            console.error('❌ Scene or game not initialized for UI elements creation');
            return;
        }
        
        const config = this.game.config;
        
        // 학습 상태 표시
        const learningStatus = this.scene.add.text(config.width / 2, config.height - 30, 'AI 모델 시스템 시작', {
            fontSize: '12px',
            fill: '#00ff00'
        }).setOrigin(0.5);
        
        // 트레이너 활동 대화창
        const trainerDialog = this.scene.add.text(10, config.height - 60, '🎯 트레이너: AI 시스템 시작 중...', {
            fontSize: '10px',
            fill: '#ffff00',
            backgroundColor: '#000000',
            padding: { x: 5, y: 2 }
        }).setOrigin(0, 0.5);
        
        // 트레이너 위치 정보 표시
        const trainerPositionInfo = this.scene.add.text(10, config.height - 80, '📍 위치: (0, 0) | 목표: (0, 0)', {
            fontSize: '10px',
            fill: '#00ffff',
            backgroundColor: '#000000',
            padding: { x: 5, y: 2 }
        }).setOrigin(0, 0.5);
        
        // N/B 코인 개수 표시
        const nbCoinDisplay = this.scene.add.text(config.width - 10, 10, 'N/B 코인: 0개', {
            fontSize: '12px',
            fill: '#ffaa00',
            backgroundColor: '#000000',
            padding: { x: 5, y: 2 }
        }).setOrigin(1, 0);
        
        // N/B 코인 미네랄 누적 수익률 표시
        const nbMineralDisplay = this.scene.add.text(config.width - 10, 30, 'N/B 미네랄: 0.00%', {
            fontSize: '12px',
            fill: '#00ffaa',
            backgroundColor: '#000000',
            padding: { x: 5, y: 2 }
        }).setOrigin(1, 0);
        
        // 매수 전 예상 수익률 표시
        const buyProfitRateDisplay = this.scene.add.text(10, 10, '매수 전 예상 수익률: 0.00%', {
            fontSize: '12px',
            fill: '#00ff88',
            backgroundColor: '#000000',
            padding: { x: 5, y: 2 }
        }).setOrigin(0, 0);
        
        // 매도 전 예상 수익률 표시
        const sellProfitRateDisplay = this.scene.add.text(10, 30, '매도 전 예상 수익률: 0.00%', {
            fontSize: '12px',
            fill: '#ff0088',
            backgroundColor: '#000000',
            padding: { x: 5, y: 2 }
        }).setOrigin(0, 0);
        
        // 연결선을 그리기 위한 그래픽 객체
        const connectionLines = this.scene.add.graphics();
        const guildTrainerConnection = this.scene.add.graphics();
        
        // 전역 변수로 저장
        window.learningStatus = learningStatus;
        window.trainerDialog = trainerDialog;
        window.trainerPositionInfo = trainerPositionInfo;
        window.nbCoinDisplay = nbCoinDisplay;
        window.nbMineralDisplay = nbMineralDisplay;
        window.buyProfitRateDisplay = buyProfitRateDisplay;
        window.sellProfitRateDisplay = sellProfitRateDisplay;
        window.connectionLines = connectionLines;
        window.guildTrainerConnection = guildTrainerConnection;
    }

    // 이벤트 리스너 설정
    setupEventListeners() {
        setTimeout(() => {
            // HTML 초기화 버튼 이벤트 리스너
            const resetButton = document.getElementById('game-reset-button');
            if (resetButton) {
                resetButton.addEventListener('click', () => this.resetGame());
            }
            
            // N/B 코인 +1 버튼 이벤트 리스너
            const nbCoinPlusButton = document.getElementById('nb-coin-plus-button');
            if (nbCoinPlusButton) {
                nbCoinPlusButton.addEventListener('click', () => this.addNBCoin());
            }
            
            // N/B 코인 -1 버튼 이벤트 리스너
            const nbCoinMinusButton = document.getElementById('nb-coin-minus-button');
            if (nbCoinMinusButton) {
                nbCoinMinusButton.addEventListener('click', () => this.removeNBCoin());
            }
        }, 1000);
    }

    // 게임 루프 시작
    startGameLoop() {
        if (!this.scene) {
            console.error('❌ Scene not initialized for game loop');
            return;
        }
        
        try {
            this.scene.time.addEvent({
                delay: 100,
                callback: () => this.aiSystemAlgorithm(),
                loop: true
            });
            
            // 자동 저장은 게임 상태 관리자가 담당
            console.log('💾 자동 저장: 게임 상태 관리자가 담당');
            
            console.log('✅ Game loop started successfully');
        } catch (error) {
            console.error('❌ Error starting game loop:', error);
        }
    }

    // AI 시스템 알고리즘
    aiSystemAlgorithm() {
        // 실제 트레이딩 데이터 가져오기
        const majorityElement = document.getElementById('majority-zone');
        const currentPriceElement = document.getElementById('trading-current-price');
        
        if (!majorityElement || !currentPriceElement) {
            if (window.learningStatus) {
                window.learningStatus.setText('데이터 로딩 중...');
            }
            return;
        }
        
        const currentMajority = majorityElement.textContent.trim();
        const currentPriceText = currentPriceElement.textContent;
        
        // AI 모델들의 독립적인 행동
        this.aiModels.forEach((model, modelIndex) => {
            if (model.isExplorer) {
                this.handleExplorer(model, modelIndex);
            } else if (model.isTrainer) {
                this.handleTrainer(model, currentMajority, currentPriceText);
            }
        });
        
        // 연결선 업데이트
        this.updateConnectionLines();
        
        // 전체 상태 업데이트
        const totalDiscovered = this.aiModels.reduce((sum, model) => sum + model.discoveredCoords.length, 0);
        if (window.learningStatus) {
            const learningText = `AI 시스템 작동 중 - 총 발견 좌표: ${totalDiscovered}`;
            window.learningStatus.setText(learningText);
            
            // 화면 출력 내용을 로그에 저장
            if (window.logManager) {
                window.logManager.addLog(`📺 화면출력(학습상태): ${learningText}`);
            }
        }
    }

    // 탐색자 처리
    handleExplorer(model, modelIndex) {
        const modelX = model.circle.x;
        const modelY = model.circle.y;
        const distanceToTarget = Math.sqrt((model.targetX - modelX) ** 2 + (model.targetY - modelY) ** 2);
        
        if (distanceToTarget < 25) {
            // 새로운 좌표 발견
            const currentCoord = { x: Math.round(modelX), y: Math.round(modelY) };
            
            // 중복 체크
            const isDuplicate = model.discoveredCoords.some(coord => 
                Math.abs(coord.x - currentCoord.x) < 15 && 
                Math.abs(coord.y - currentCoord.y) < 15
            );
            
            if (!isDuplicate) {
                model.discoveredCoords.push(currentCoord);
                
                if (model.discoveredCoords.length > 8) {
                    model.discoveredCoords.shift();
                }
            }
            
            // 새로운 목표 설정
            model.targetX = Math.random() * (this.game.config.width - 80) + 40;
            model.targetY = Math.random() * (this.game.config.height - 80) + 40;
            model.role.setText(`탐색 (${model.discoveredCoords.length}/8)`);
        }
        
        // 탐색자 이동
        const dx = model.targetX - modelX;
        const dy = model.targetY - modelY;
        
        if (Math.abs(dx) > 1) {
            model.circle.x += dx * 0.03;
            model.name.x = model.circle.x;
            model.role.x = model.circle.x;
        }
        
        if (Math.abs(dy) > 1) {
            model.circle.y += dy * 0.03;
            model.name.y = model.circle.y - 6;
            model.role.y = model.circle.y + 6;
        }
    }

    // 트레이너 처리
    handleTrainer(model, currentMajority, currentPriceText) {
        // 트레이너 의사결정 처리 (분리된 모듈 사용)
        if (window.trainerDecisionHandler) {
            const targetAction = window.trainerDecisionHandler.handleTrainerDecision(
                model, this.game.config, currentMajority, this.gameData.nbCoins, 
                this.gameData.buyProfitRate, this.gameData.sellProfitRate, 
                (this.game.config.width - 240) / 2, 60, 120
            );
            model.targetAction = targetAction;
        }
        
        // 트레이너 이동 (분리된 모듈 사용)
        if (window.trainerMovementController) {
            window.trainerMovementController.updateTrainerMovement(model, this.game.config);
        }
        
        // 트레이너 역할 텍스트 업데이트
        model.role.setText(`트레이너 (${model.targetAction})`);
        
        // 트레이너 대화창 업데이트
        if (window.trainerDialog) {
            const currentTime = new Date().toLocaleTimeString();
            const position = `(${Math.round(model.circle.x)}, ${Math.round(model.circle.y)})`;
            const dialogText = `🎯 트레이너: ${model.targetAction} | 위치: ${position} | 시간: ${currentTime}`;
            window.trainerDialog.setText(dialogText);
            
            // 화면 출력 내용을 로그에 저장
            if (window.logManager) {
                window.logManager.addLog(`📺 화면출력(트레이너대화창): ${dialogText}`);
            }
        }
        
        // 트레이너 위치 정보 업데이트
        if (window.trainerPositionInfo) {
            const currentPosition = `(${Math.round(model.circle.x)}, ${Math.round(model.circle.y)})`;
            const targetPosition = `(${Math.round(model.targetX)}, ${Math.round(model.targetY)})`;
            const distance = Math.sqrt((model.targetX - model.circle.x) ** 2 + (model.targetY - model.circle.y) ** 2);
            
            // 현재 위치의 장소 확인
            const currentZone = this.getCurrentZoneName(model.circle.x, model.circle.y);
            const targetZone = this.getCurrentZoneName(model.targetX, model.targetY);
            
            const positionText = `📍 위치: ${currentPosition} (${currentZone}) | 목표: ${targetPosition} (${targetZone}) | 거리: ${Math.round(distance)}px`;
            window.trainerPositionInfo.setText(positionText);
            
            // 화면 출력 내용을 로그에 저장
            if (window.logManager) {
                window.logManager.addLog(`📺 화면출력(트레이너위치정보): ${positionText}`);
            }
        }
        
        // 학습 상태 업데이트
        if (window.learningStatus) {
            const totalDiscovered = this.aiModels.reduce((sum, m) => sum + m.discoveredCoords.length, 0);
            const learningText = `AI 시스템 작동 중 - 트레이너: ${model.targetAction} | 발견 좌표: ${totalDiscovered}`;
            window.learningStatus.setText(learningText);
            
            // 화면 출력 내용을 로그에 저장
            if (window.logManager) {
                window.logManager.addLog(`📺 화면출력(학습상태): ${learningText}`);
            }
        }
    }

    // 연결선 업데이트
    updateConnectionLines() {
        const trainer = this.aiModels.find(model => model.isTrainer);
        if (!trainer) return;
        
        // 연결선 초기화
        window.connectionLines.clear();
        window.guildTrainerConnection.clear();
        
        // N/B 길드와 트레이너 연결선
        const connectionColor = this.gameData.nbCoins > 0 ? 0xffaa00 : 0x00ff00;
        const connectionAlpha = this.gameData.nbCoins > 0 ? 0.8 : 0.6;
        
        window.guildTrainerConnection.lineStyle(2, connectionColor, connectionAlpha);
        window.guildTrainerConnection.beginPath();
        window.guildTrainerConnection.moveTo(100, 100);
        window.guildTrainerConnection.lineTo(trainer.circle.x, trainer.circle.y);
        window.guildTrainerConnection.strokePath();
        
        // 각 탐색자와 트레이너를 연결
        this.aiModels.forEach((model) => {
            if (model.isExplorer) {
                window.connectionLines.lineStyle(1, 0x00ff88, 0.4);
                window.connectionLines.beginPath();
                window.connectionLines.moveTo(trainer.circle.x, trainer.circle.y);
                window.connectionLines.lineTo(model.circle.x, model.circle.y);
                window.connectionLines.strokePath();
            }
        });
    }

    // 게임 업데이트
    updateGame() {
        // 게임 상태 업데이트 로직
    }

    // 게임 리셋
    resetGame() {
        console.log('🔄 게임 리셋 시작');
        
        // 모든 변수 초기화
        this.gameData = {
            nbCoins: 0,
            nbMinerals: 0.0,
            buyPrice: 0,
            buyProfitRate: 0,
            sellProfitRate: 0,
            lastBuyAction: false,
            lastSellAction: false
        };
        
        // AI 모델들 초기 위치로 리셋
        const initialPositions = [
            { x: this.game.config.width / 2, y: this.game.config.height / 2 },
            { x: this.game.config.width / 4, y: this.game.config.height / 4 },
            { x: this.game.config.width * 3/4, y: this.game.config.height / 4 },
            { x: this.game.config.width / 4, y: this.game.config.height * 3/4 },
            { x: this.game.config.width * 3/4, y: this.game.config.height * 3/4 }
        ];
        
        this.aiModels.forEach((model, index) => {
            model.circle.x = initialPositions[index].x;
            model.circle.y = initialPositions[index].y;
            model.name.x = initialPositions[index].x;
            model.name.y = initialPositions[index].y - (index === 4 ? 6 : 4);
            model.role.x = initialPositions[index].x;
            model.role.y = initialPositions[index].y + (index === 4 ? 6 : 4);
            model.targetX = initialPositions[index].x;
            model.targetY = initialPositions[index].y;
            model.discoveredCoords = [];
            model.memoryIndex = 0;
            model.explorationTimer = 0;
            model.needsNewDecision = false;
            model.arrivalLogged = false;
            
            if (model.isTrainer) {
                model.circle.setFillStyle(0xffff00);
            }
        });
        
        // UI 업데이트
        if (window.nbCoinDisplay) {
            const coinText = `N/B 코인: ${this.gameData.nbCoins}개`;
            window.nbCoinDisplay.setText(coinText);
            if (window.logManager) {
                window.logManager.addLog(`📺 화면출력(N/B코인): ${coinText}`);
            }
        }
        if (window.nbMineralDisplay) {
            const mineralText = `N/B 미네랄: ${this.gameData.nbMinerals.toFixed(2)}%`;
            window.nbMineralDisplay.setText(mineralText);
            if (window.logManager) {
                window.logManager.addLog(`📺 화면출력(N/B미네랄): ${mineralText}`);
            }
        }
        if (window.buyProfitRateDisplay) {
            const buyProfitText = `매수 전 예상 수익률: 0.00%`;
            window.buyProfitRateDisplay.setText(buyProfitText);
            if (window.logManager) {
                window.logManager.addLog(`📺 화면출력(매수수익률): ${buyProfitText}`);
            }
        }
        if (window.sellProfitRateDisplay) {
            const sellProfitText = `매도 전 예상 수익률: 0.00%`;
            window.sellProfitRateDisplay.setText(sellProfitText);
            if (window.logManager) {
                window.logManager.addLog(`📺 화면출력(매도수익률): ${sellProfitText}`);
            }
        }
        
        console.log('✅ 게임 리셋 완료');
    }

            // N/B 코인 추가
        addNBCoin() {
            this.gameData.nbCoins++;
            if (window.nbCoinDisplay) {
                const coinText = `N/B 코인: ${this.gameData.nbCoins}개`;
                window.nbCoinDisplay.setText(coinText);
                
                // 화면 출력 내용을 로그에 저장
                if (window.logManager) {
                    window.logManager.addLog(`📺 화면출력(N/B코인): ${coinText}`);
                }
            }
            console.log(`➕ N/B 코인 +1 추가됨. 현재: ${this.gameData.nbCoins}개`);
        }

            // N/B 코인 제거
        removeNBCoin() {
            if (this.gameData.nbCoins > 0) {
                this.gameData.nbCoins--;
                if (window.nbCoinDisplay) {
                    const coinText = `N/B 코인: ${this.gameData.nbCoins}개`;
                    window.nbCoinDisplay.setText(coinText);
                    
                    // 화면 출력 내용을 로그에 저장
                    if (window.logManager) {
                        window.logManager.addLog(`📺 화면출력(N/B코인): ${coinText}`);
                    }
                }
                console.log(`➖ N/B 코인 -1 감소됨. 현재: ${this.gameData.nbCoins}개`);
            } else {
                console.log(`❌ N/B 코인이 0개라서 감소할 수 없음`);
            }
        }

    // 현재 위치의 장소 이름 반환
    getCurrentZoneName(x, y) {
        const config = this.game.config;
        const spacing = 120;
        const startX = (config.width - (spacing * 2)) / 2;
        const topY = 60;
        
        // 매수 영역
        if (Math.abs(x - startX) < 50 && Math.abs(y - topY) < 50) {
            return '매수영역';
        }
        // 매도 영역
        else if (Math.abs(x - (startX + spacing)) < 50 && Math.abs(y - topY) < 50) {
            return '매도영역';
        }
        // 대기 영역
        else if (Math.abs(x - (startX + spacing * 2)) < 50 && Math.abs(y - topY) < 50) {
            return '대기영역';
        }
        // N/B 길드
        else if (Math.abs(x - 100) < 60 && Math.abs(y - 100) < 60) {
            return 'N/B길드';
        }
        // BTC 시장 탐색 구역
        else if (Math.abs(x - (config.width - 100)) < 60 && Math.abs(y - (config.height - 100)) < 60) {
            return 'BTC시장탐색구역';
        }
        // 신호 대기 센터
        else if (Math.abs(x - config.width / 2) < 60 && Math.abs(y - config.height / 2) < 60) {
            return '신호대기센터';
        }
        
        return '기타영역';
    }

    // 게임 데이터 저장 (game-state-manager.js의 localStorage 사용)
    saveGameData() {
        try {
            // game-state-manager.js를 통해 localStorage에 저장
            if (window.gameStateManager) {
                const gameData = {
                    ...this.gameData,
                    aiModels: this.aiModels || []
                };
                window.gameStateManager.saveGameState(gameData);
                this.lastSaveTime = Date.now();
                
                console.log(`💾 N/B 코인/미네랄 localStorage 저장: N/B코인 ${this.gameData.nbCoins}개, N/B미네랄 ${this.gameData.nbMinerals.toFixed(2)}%`);
                
                if (window.logManager) {
                    window.logManager.addLog(`💾 N/B 코인/미네랄 localStorage 저장: N/B코인 ${this.gameData.nbCoins}개, N/B미네랄 ${this.gameData.nbMinerals.toFixed(2)}%`);
                }
            }
        } catch (error) {
            console.error(`❌ 게임 데이터 저장 중 오류: ${error.message}`);
        }
    }
}

// 전역 인스턴스 생성
window.gameInitializer = new GameInitializer();
