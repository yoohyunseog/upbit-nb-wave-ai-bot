// 트레이너 이동 컨트롤러 모듈
// 트레이너의 이동 로직, 목표 설정, 이동 속도 관리를 담당

class TrainerMovementController {
    constructor() {
        this.movementSpeed = 0.03; // 기본 이동 속도 (탐색자들과 동일하게 조정)
        this.arrivalThreshold = 2; // 도착 판정 거리
        this.minMovementDistance = 0.5; // 최소 이동 거리
    }

    // 트레이너 이동 처리
    updateTrainerMovement(model, config) {
        const modelX = model.circle.x;
        const modelY = model.circle.y;
        
        // 디버깅: 목표 위치 확인
        if (typeof model.targetX === 'undefined' || typeof model.targetY === 'undefined') {
            if (window.logManager) {
                window.logManager.addLog(`❌ 트레이너 이동 오류: 목표 위치가 설정되지 않음`);
            }
            return;
        }
        
        const dx = model.targetX - modelX;
        const dy = model.targetY - modelY;
        
        // 디버깅: 이동 정보 (5초마다)
        if (window.logManager && Math.floor(Date.now() / 1000) % 5 === 0) {
            window.logManager.addLog(`🔧 이동 처리: 현재(${Math.round(modelX)}, ${Math.round(modelY)}) → 목표(${Math.round(model.targetX)}, ${Math.round(model.targetY)}) | dx=${Math.round(dx)}, dy=${Math.round(dy)}`);
        }
        
        // 목표 위치에 충분히 가까우면 정확히 목표 위치로 이동
        if (Math.abs(dx) <= this.arrivalThreshold && Math.abs(dy) <= this.arrivalThreshold) {
            this.setExactPosition(model, model.targetX, model.targetY);
            if (window.logManager) {
                window.logManager.addLog(`🎯 트레이너 목표 도달: (${Math.round(model.targetX)}, ${Math.round(model.targetY)})`);
            }
            
            // 목표 도달 시 새로운 의사결정 트리거
            if (model.isTrainer && !model.arrivalLogged) {
                model.arrivalLogged = true;
                model.needsNewDecision = true; // 새로운 의사결정 필요 플래그
                if (window.logManager) {
                    window.logManager.addLog(`🔄 트레이너 목표 도달 - 새로운 의사결정 필요 플래그 설정`);
                }
                
                                            // 트레이너 대화창 업데이트
                            if (window.trainerDialog) {
                                const currentTime = new Date().toLocaleTimeString();
                                const dialogText = `🎯 트레이너: 목표 도달 → 새로운 의사결정 필요 | 시간: ${currentTime}`;
                                window.trainerDialog.setText(dialogText);
                                
                                // 화면 출력 내용을 로그에 저장
                                if (window.logManager) {
                                    window.logManager.addLog(`📺 화면출력(트레이너대화창): ${dialogText}`);
                                }
                            }
                
                // 트레이너 위치 정보 업데이트
                if (window.trainerPositionInfo) {
                    const currentPosition = `(${Math.round(model.circle.x)}, ${Math.round(model.circle.y)})`;
                    const targetPosition = `(${Math.round(model.targetX)}, ${Math.round(model.targetY)})`;
                    
                    // 현재 위치의 장소 확인
                    const currentZone = this.getCurrentZoneName(model.circle.x, model.circle.y);
                    const targetZone = this.getCurrentZoneName(model.targetX, model.targetY);
                    
                    const positionText = `📍 위치: ${currentPosition} (${currentZone}) | 목표: ${targetPosition} (${targetZone}) | 거리: 0px (도달!)`;
                    window.trainerPositionInfo.setText(positionText);
                    
                    // 화면 출력 내용을 로그에 저장
                    if (window.logManager) {
                        window.logManager.addLog(`📺 화면출력(트레이너위치정보): ${positionText}`);
                    }
                }
            }
        } else {
            // 일반적인 이동 로직
            this.moveTowardsTarget(model, dx, dy);
        }
    }

    // 정확한 위치 설정
    setExactPosition(model, x, y) {
        model.circle.x = x;
        model.circle.y = y;
        model.name.x = x;
        model.name.y = y - 6;
        model.role.x = x;
        model.role.y = y + 6;
    }

    // 목표를 향해 이동
    moveTowardsTarget(model, dx, dy) {
        let moved = false;
        
        if (Math.abs(dx) > this.minMovementDistance) {
            const oldX = model.circle.x;
            model.circle.x += dx * this.movementSpeed;
            model.name.x = model.circle.x;
            model.role.x = model.circle.x;
            moved = true;
            
            if (window.logManager) {
                window.logManager.addLog(`➡️ X축 이동: ${Math.round(oldX)} → ${Math.round(model.circle.x)} (dx=${Math.round(dx)}, 속도=${this.movementSpeed})`);
            }
        }
        
        if (Math.abs(dy) > this.minMovementDistance) {
            const oldY = model.circle.y;
            model.circle.y += dy * this.movementSpeed;
            model.name.y = model.circle.y - 6;
            model.role.y = model.circle.y + 6;
            moved = true;
            
            if (window.logManager) {
                window.logManager.addLog(`⬇️ Y축 이동: ${Math.round(oldY)} → ${Math.round(model.circle.y)} (dy=${Math.round(dy)}, 속도=${this.movementSpeed})`);
            }
        }
        
        if (!moved && window.logManager) {
            window.logManager.addLog(`⏸️ 이동 없음: dx=${Math.round(dx)}, dy=${Math.round(dy)}, 최소거리=${this.minMovementDistance}`);
        }
    }

    // 목표 위치 설정
    setTargetPosition(model, targetX, targetY, action) {
        model.targetX = targetX;
        model.targetY = targetY;
        model.targetAction = action;
    }

    // 신호 대기 센터로 이동
    moveToSignalCenter(model, config) {
        this.setTargetPosition(
            model, 
            config.width / 2, 
            config.height / 2, 
            '신호 대기'
        );
    }

    // BTC 시장 탐색 구역으로 이동
    moveToBTCMarket(model, config) {
        this.setTargetPosition(
            model, 
            config.width - 100, 
            config.height - 100, 
            'BTC 시장 탐색'
        );
    }

    // N/B 길드로 이동
    moveToNBGuild(model) {
        this.setTargetPosition(model, 100, 100, 'N/B 길드 방문');
    }

    // 매수 영역으로 이동
    moveToBuyArea(model, startX, topY) {
        this.setTargetPosition(model, startX, topY, '매수');
    }

    // 매도 영역으로 이동
    moveToSellArea(model, startX, topY, spacing) {
        this.setTargetPosition(model, startX + spacing, topY, '매도');
    }

    // 현재 위치에서 목표까지의 거리 계산
    calculateDistanceToTarget(model) {
        const dx = model.targetX - model.circle.x;
        const dy = model.targetY - model.circle.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    // 이동 속도 설정
    setMovementSpeed(speed) {
        this.movementSpeed = speed;
    }

    // 도착 판정 거리 설정
    setArrivalThreshold(threshold) {
        this.arrivalThreshold = threshold;
    }
    
    // 현재 위치의 장소 이름 반환
    getCurrentZoneName(x, y) {
        // 기본 설정값 (game-initializer와 동일하게)
        const config = { width: 1086, height: 500 };
        const spacing = 120;
        const startX = (config.width - (spacing * 2)) / 2;
        const topY = 60;
        
        // 매수 영역
        if (Math.abs(x - startX) < 50 && Math.abs(y - topY) < 50) {
            return '매수영역';
        }
        // 매도 영역
        else if (Math.abs(x - (startX + spacing)) < 50 && Math.abs(y - topY) < 50) {
            return '매도영역';
        }
        // 대기 영역
        else if (Math.abs(x - (startX + spacing * 2)) < 50 && Math.abs(y - topY) < 50) {
            return '대기영역';
        }
        // N/B 길드
        else if (Math.abs(x - 100) < 60 && Math.abs(y - 100) < 60) {
            return 'N/B길드';
        }
        // BTC 시장 탐색 구역
        else if (Math.abs(x - (config.width - 100)) < 60 && Math.abs(y - (config.height - 100)) < 60) {
            return 'BTC시장탐색구역';
        }
        // 신호 대기 센터
        else if (Math.abs(x - config.width / 2) < 60 && Math.abs(y - config.height / 2) < 60) {
            return '신호대기센터';
        }
        
        return '기타영역';
    }
}

// 전역 인스턴스 생성
window.trainerMovementController = new TrainerMovementController();
