(() => {
	const clamp01 = (v) => Math.min(1, Math.max(0, v));
  
	function getIntById(id) {
	  const el = document.getElementById(id);
	  const text = el?.textContent ?? '0';
	  const m = String(text).match(/-?\d+/);
	  const num = m ? parseInt(m[0], 10) : 0;
	  return Number.isNaN(num) ? 0 : num;
	}
  
	function setWidth(rect, width) {
	  if (!rect) return;
	  if ('displayWidth' in rect) {
		rect.displayWidth = width;
	  } else {
		rect.width = width;
	  }
	}
  
	function update(orangeProcessBar, blueProcessBar, opts = {}) {
	  try {
		const { orangeId = 'orange-sum', blueId = 'blue-sum' } = opts;
		const orangeVal = getIntById(orangeId);
		const blueVal = getIntById(blueId);
		const total = Math.max(1, orangeVal + blueVal);
  
		if (orangeProcessBar) {
		  const signed = orangeVal - blueVal;
		  const ratio = clamp01(Math.abs(signed) / total);
		  const targetW = orangeProcessBar.width * ratio;
		  const left = signed >= 0 ? targetW : 0;
		  const right = signed < 0 ? targetW : 0;
		  setWidth(orangeProcessBar.fillLeft, left);
		  setWidth(orangeProcessBar.fillRight, right);
		}
  
		if (blueProcessBar) {
		  const ratioBlue = clamp01(blueVal / total);
		  setWidth(blueProcessBar.fill, blueProcessBar.width * ratioBlue);
		}
	  } catch (err) {
		// no-op
	  }
	}
  
	window.dualProcessBarUpdater = { update };
  })();