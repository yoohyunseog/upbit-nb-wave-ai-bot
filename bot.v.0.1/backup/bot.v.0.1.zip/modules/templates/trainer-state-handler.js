// 트레이너 상태 처리 모듈
// 트레이너의 상태 관리와 액션 처리를 담당

class TrainerStateHandler {
    constructor() {
        this.movementSpeed = 0.3; // 이동 속도 조정 (부드러운 이동)
        this.arrivalThreshold = 30;
    }

    // 트레이너 상태 업데이트
    updateTrainerState(model, config, currentMajority, nbCoins, buyProfitRate, sellProfitRate, trainerDialog) {
        const modelX = model.circle.x;
        const modelY = model.circle.y;
        
        // targetAction이 undefined이면 기본값 설정
        if (typeof model.targetAction === 'undefined' || model.targetAction === '') {
            this.initializeTrainerState(model, config);
        }
        
        let targetAction = model.targetAction;
        
        // 트레이너 활동 로그
        this.logTrainerActivity(model, config, currentMajority, nbCoins, buyProfitRate, sellProfitRate);
        
        // BTC 시장에서 매수 전 예상 수익률 계산
        this.handleBTCMarketCalculation(model, config, currentMajority, buyProfitRate, trainerDialog);
        
        // 의사결정 시스템 처리
        targetAction = this.processDecisionSystem(model, config, currentMajority, nbCoins, buyProfitRate, sellProfitRate);
        
        // 신호 대기 상태 처리
        targetAction = this.handleSignalWaiting(model, config, currentMajority, nbCoins, buyProfitRate, sellProfitRate, trainerDialog);
        
        // BTC 시장 탐색 모드 처리
        targetAction = this.handleBTCExploration(model, config, currentMajority, buyProfitRate, trainerDialog);
        
        // 목표 도달 처리
        this.handleTargetArrival(model, config, targetAction, currentMajority, nbCoins, buyProfitRate, sellProfitRate, trainerDialog);
        
        return targetAction;
    }

    // 트레이너 상태 초기화
    initializeTrainerState(model, config) {
        model.targetAction = 'BTC 시장 탐색';
        // BTC 시장 탐색 구역에서 시작하도록 변경
        model.targetX = config.width - 100;
        model.targetY = config.height - 100;
        model.circle.setFillStyle(0x0088ff); // 파란색 (BTC 시장 탐색)
        // 서버 파일 로그 기록
        try { fetch('/api/trainer/decision-log', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ level:'info', action:'INIT', targetAction: model.targetAction, zone: 'INIT', ts: Date.now() }) }); } catch(_){ }
        
        if (window.logManager) {
            window.logManager.addLog(`🔵 트레이너: targetAction 초기화 → BTC 시장 탐색 구역에서 시작 (${Math.round(model.targetX)}, ${Math.round(model.targetY)})`);
        }
    }

    // 트레이너 활동 로그
    logTrainerActivity(model, config, currentMajority, nbCoins, buyProfitRate, sellProfitRate) {
        if (window.trainerActivityLogger && typeof window.trainerActivityLogger.logTrainerActivity === 'function') {
            window.trainerActivityLogger.logTrainerActivity(
                model, config, currentMajority, nbCoins, buyProfitRate, sellProfitRate
            );
        }
    }

    // BTC 시장 계산 처리
    handleBTCMarketCalculation(model, config, currentMajority, buyProfitRate, trainerDialog) {
        if (window.btcMarketCalculator && typeof window.btcMarketCalculator.calculateBuyProfitRateAtMarket === 'function') {
            const calculationResult = window.btcMarketCalculator.calculateBuyProfitRateAtMarket(
                model.circle.x, model.circle.y, config, currentMajority, null, trainerDialog
            );
            
            if (calculationResult && model.infoCollectionMode) {
                model.infoCollectionMode = false;
                setTimeout(() => {
                    model.targetAction = '정보 수집 완료';
                }, 2000);
            }
        }
    }

    // 의사결정 시스템 처리
    processDecisionSystem(model, config, currentMajority, nbCoins, buyProfitRate, sellProfitRate) {
        const startX = (config.width - (120 * 2)) / 2;
        const topY = 60;
        const spacing = 120;
        
        // 현재 구역에서 의사 결정 매칭 확인
        const currentZone = window.decisionSystem && typeof window.decisionSystem.getCurrentZone === 'function' 
            ? window.decisionSystem.getCurrentZone(model.circle.x, model.circle.y, startX, topY, spacing, config)
            : '기타영역';
            
        const zoneDecision = window.decisionSystem && typeof window.decisionSystem.getZoneDecision === 'function'
            ? window.decisionSystem.getZoneDecision(currentZone, currentMajority, nbCoins, buyProfitRate, sellProfitRate, startX, topY, spacing, config)
            : null;
        
        // BTC 시장 탐색 구역에 도달했을 때 수익률 계산 트리거
        if (currentZone === 'BTC시장탐색구역' && !model.btcMarketArrivalLogged) {
            model.btcMarketArrivalLogged = true;
            model.btcMarketWaitTimer = 0;
            
            if (window.logManager) {
                window.logManager.addLog(`🔵 BTC 시장 탐색 구역 도착 - 수익률 계산 트리거`);
            }
            
            // BTC 시장 수익률 계산기 호출
            if (window.btcMarketProfitCalculator) {
                const calculationResult = window.btcMarketProfitCalculator.calculateBuyProfitRateAtMarket(
                    currentMajority, 
                    null, // buyProfitRateDisplay
                    null, // trainerDialog
                    model, 
                    config, 
                    config.width - 100, 
                    config.height - 100
                );
                
                if (calculationResult) {
                    if (window.logManager) {
                        window.logManager.addLog(`✅ BTC 시장 수익률 계산 완료`);
                    }
                } else {
                    if (window.logManager) {
                        window.logManager.addLog(`⚠️ BTC 시장 수익률 계산 실패`);
                    }
                }
            }
            
            // 학습 모델 기반 수익률 계산도 시도
            if (window.btcMarketLearningHandler) {
                window.btcMarketLearningHandler.calculateProfitRateWithLearning(
                    model, config, null, currentMajority, null
                );
            }
        }
        
        // 현재 구역에서 해당하는 의사 결정이 없으면 신호 대기 상태로 전환
        if (!zoneDecision && !model.countdownStarted && !model.btcExplorationMode) {
            if (model.targetAction !== '신호 대기') {
                const previousAction = model.targetAction;
                model.targetAction = '신호 대기';
                model.targetX = config.width / 2;
                model.targetY = config.height / 2;
                model.circle.setFillStyle(0x88ccff);
                // 서버 파일 로그 기록
                try { fetch('/api/trainer/decision-log', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ level:'info', action:'STATE_CHANGE', from: previousAction, to: model.targetAction, zone: currentZone, majority: currentMajority, nbCoins: nbCoins, ts: Date.now() }) }); } catch(_){ }
                
                if (window.logManager) {
                    window.logManager.addLog(`🔵 트레이너: 현재 구역(${currentZone})에서 의사 결정 없음 → 신호 대기 센터로 이동 (이전 액션: ${previousAction})`);
                }
                
                if (window.trainerActivityLogger) {
                    window.trainerActivityLogger.logStateChange(previousAction, '신호 대기', `현재 구역(${currentZone})에서 의사 결정 없음`);
                }
            }
        } else if (zoneDecision && !model.countdownStarted) {
            model.targetAction = zoneDecision.action;
            model.targetX = zoneDecision.targetX;
            model.targetY = zoneDecision.targetY;
            // 서버 파일 로그 기록 (의사결정)
            try { fetch('/api/trainer/decision-log', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ level:'info', action:'DECISION', targetAction: model.targetAction, zone: currentZone, majority: currentMajority, nbCoins: nbCoins, buyProfitRate: buyProfitRate, sellProfitRate: sellProfitRate, ts: Date.now() }) }); } catch(_){ }
            
            if (window.trainerActivityLogger) {
                window.trainerActivityLogger.logDecision(model.targetAction, `구역: ${currentZone}, 신호: ${currentMajority}`);
            }
            
            this.updateTrainerColor(model, model.targetAction);
        } else if (model.countdownStarted) {
            model.targetAction = '신호 대기';
            model.targetX = config.width / 2;
            model.targetY = config.height / 2;
            model.circle.setFillStyle(0x88ccff);
        }
        
        return model.targetAction;
    }

    // 트레이너 색상 업데이트
    updateTrainerColor(model, targetAction) {
        let color = 0x88ccff; // 기본 색상
        
        switch (targetAction) {
            case '매도':
                color = 0xff8800;
                if (window.logManager && !model.sellColorLogged) {
                    window.logManager.addLog(`🟠 트레이너: 매도 의사결정! 주황색으로 변경`);
                    model.sellColorLogged = true;
                }
                break;
            case '매수':
                color = 0x0088ff;
                if (window.logManager && !model.buyColorLogged) {
                    window.logManager.addLog(`🔵 트레이너: 매수 의사결정! 파란색으로 변경`);
                    model.buyColorLogged = true;
                }
                break;
            case 'BTC 시장 방문':
                color = 0x0088ff;
                if (window.logManager) {
                    window.logManager.addLog(`🔵 트레이너: BTC 시장 방문! 파란색으로 변경`);
                }
                break;
            case 'N/B 길드 방문':
                color = 0xff8800;
                if (window.logManager && !model.nbGuildColorLogged) {
                    window.logManager.addLog(`🟠 트레이너: N/B 길드 방문! 주황색으로 변경`);
                    model.nbGuildColorLogged = true;
                }
                break;
            case '대기':
                color = 0xffff00;
                if (window.logManager) {
                    window.logManager.addLog(`🟡 트레이너: 대기 상태! 노란색으로 변경`);
                }
                break;
            case '신호 대기':
                color = 0x88ccff;
                if (window.logManager) {
                    window.logManager.addLog(`🔵 트레이너: 신호 대기 상태! 하늘색으로 변경`);
                }
                break;
        }
        
        model.circle.setFillStyle(color);
    }

    // 신호 대기 상태 처리
    handleSignalWaiting(model, config, currentMajority, nbCoins, buyProfitRate, sellProfitRate, trainerDialog) {
        if (model.targetAction === '신호 대기') {
            // 랜덤 움직임을 위한 타이머 초기화
            if (!model.randomMoveTimer) {
                model.randomMoveTimer = 0;
                model.randomMoveInterval = Math.floor(Math.random() * 3000) + 2000; // 2-5초마다 랜덤 이동
            }
            
            model.randomMoveTimer++;
            
            // 랜덤 이동 간격에 도달하면 새로운 랜덤 목표 설정
            if (model.randomMoveTimer >= model.randomMoveInterval) {
                this.setRandomTarget(model, config);
                model.randomMoveTimer = 0;
                model.randomMoveInterval = Math.floor(Math.random() * 3000) + 2000;
                
                if (window.logManager) {
                    window.logManager.addLog(`🎲 트레이너 랜덤 이동: 새로운 목표 설정 (${Math.round(model.targetX)}, ${Math.round(model.targetY)})`);
                }
            }
            
            // 현재 위치와 목표 위치 간의 거리 계산
            const distanceToTarget = Math.sqrt((model.circle.x - model.targetX) ** 2 + (model.circle.y - model.targetY) ** 2);
            
            // 목표에 도달했는지 확인
            if (distanceToTarget < 30) {
                if (!model.waitCheckTimer) {
                    model.waitCheckTimer = 0;
                    model.waitStartTime = Date.now();
                }
                model.waitCheckTimer++;
                model.countdownStarted = true;
                
                const elapsedSeconds = (Date.now() - model.waitStartTime) / 1000;
                
                if (elapsedSeconds >= 5) {
                    model.targetAction = 'BTC 시장 탐색';
                    model.targetX = config.width - 100;
                    model.targetY = config.height - 100;
                    model.circle.setFillStyle(0x0088ff);
                    model.btcExplorationMode = true;
                    model.countdownStarted = false;
                    model.randomMoveTimer = 0;
                    
                    if (window.logManager) {
                        window.logManager.addLog(`🔵 트레이너: 랜덤 탐색 완료 → BTC 시장 탐색으로 이동!`);
                    }
                    
                    const dialogMessage = `🔵 [랜덤 탐색 완료] BTC 시장 탐색으로 이동 중... 매수 전 예상 수익률 계산 예정`;
                    trainerDialog.setText(dialogMessage);
                    if (window.logManager) {
                        window.logManager.addLog(dialogMessage);
                    }
                } else {
                    const remainingSeconds = Math.ceil(5 - elapsedSeconds);
                    const dialogMessage = `🎲 [랜덤 탐색] 현재 위치에서 대기 중... (${remainingSeconds}초 후 BTC 시장 탐색) N/B 코인: ${nbCoins}개, 신호: ${currentMajority}`;
                    trainerDialog.setText(dialogMessage);
                    if (window.logManager) {
                        window.logManager.addLog(dialogMessage);
                    }
                }
            } else {
                if (distanceToTarget > 50 && !model.countdownStarted) {
                    model.waitCheckTimer = 0;
                }
                
                // 랜덤 이동 중 대화창 업데이트
                const dialogMessage = `🎲 [랜덤 탐색] 이동 중... (${Math.round(distanceToTarget)}px 남음) N/B 코인: ${nbCoins}개, 신호: ${currentMajority}`;
                trainerDialog.setText(dialogMessage);
            }
        }
        
        return model.targetAction;
    }
    
    // 랜덤 목표 위치 설정
    setRandomTarget(model, config) {
        // 화면 경계 내에서 랜덤한 위치 선택
        const margin = 100; // 화면 가장자리에서 100px 여백
        const minX = margin;
        const maxX = config.width - margin;
        const minY = margin;
        const maxY = config.height - margin;
        
        // 랜덤한 목표 위치 생성
        model.targetX = Math.floor(Math.random() * (maxX - minX + 1)) + minX;
        model.targetY = Math.floor(Math.random() * (maxY - minY + 1)) + minY;
        
        // 학습 시스템을 통해 랜덤 이동 학습
        if (window.learningSystem && typeof window.learningSystem.learnRandomMovement === 'function') {
            window.learningSystem.learnRandomMovement(model, model.targetX, model.targetY);
        }
    }

    // BTC 시장 탐색 모드 처리
    handleBTCExploration(model, config, currentMajority, buyProfitRate, trainerDialog) {
        if (model.targetAction === 'BTC 시장 탐색') {
            const distanceToBTCMarket = Math.sqrt((model.circle.x - (config.width - 100)) ** 2 + (model.circle.y - (config.height - 100)) ** 2);
            
            // BTC 시장 감지 검사 (충돌 → 감지)
            let isCollidingWithBTCMarket = false;
            if (window.btcMarketPolygon && model.circle) {
                const circleBounds = model.circle.getBounds();
                const polygonBounds = window.btcMarketPolygon.getBounds();
                isCollidingWithBTCMarket = Phaser.Geom.Rectangle.Overlaps(circleBounds, polygonBounds);
                
                if (isCollidingWithBTCMarket) {
                    const centerDistance = Math.sqrt(
                        (model.circle.x - window.btcMarketPolygon.x) ** 2 + 
                        (model.circle.y - window.btcMarketPolygon.y) ** 2
                    );
                    if (centerDistance > 50) {
                        isCollidingWithBTCMarket = false;
                    }
                }
            }
            
            if (isCollidingWithBTCMarket || distanceToBTCMarket < 60) {
                if (model.btcExplorationMode) {
                    model.btcExplorationMode = false;
                    if (window.logManager) {
                        window.logManager.addLog(`🔔 트레이너가 BTC 시장을 감지! 학습 모델 기반 처리 시작`);
                    }
                }
                
                if (window.btcMarketLearningHandler) {
                    window.btcMarketLearningHandler.handleBTCMarketArrival(model, config, trainerDialog, currentMajority, null);
                } else {
                    // 기본 처리: 즉시 신호 대기 센터로 복귀
                    model.targetAction = '신호 대기';
                    model.targetX = config.width / 2;
                    model.targetY = config.height / 2;
                    model.circle.setFillStyle(0x88ccff);
                }
            } else {
                const statusText = `🔵 [BTC 탐색] BTC 시장 탐색으로 이동 중... (${Math.round(distanceToBTCMarket)}px 남음)`;
                trainerDialog.setText(statusText);
                if (window.logManager && Math.floor(Date.now() / 1000) % 5 === 0) {
                    window.logManager.addLog(`🔵 BTC 시장 탐색 진행 중: 거리 ${Math.round(distanceToBTCMarket)}px, 현재 신호: ${currentMajority}`);
                }
            }
            
            // BTC 탐색 관리자 모듈이 없을 때의 기본 처리
            if (!window.btcExplorationManager) {
                if (model.btcExplorationMode && !model.btcExplorationCompleted) {
                    model.btcExplorationCompleted = true;
                    
                    if (window.logManager) {
                        window.logManager.addLog(`🔵 BTC 탐색 완료: 2초 후 신호 대기 센터로 복귀 (현재 신호: ${currentMajority})`);
                    }
                    
                    setTimeout(() => {
                        const previousAction = model.targetAction;
                        model.targetAction = '신호 대기';
                        model.targetX = config.width / 2;
                        model.targetY = config.height / 2;
                        model.circle.setFillStyle(0x88ccff);
                        model.waitCheckTimer = 0;
                        model.countdownStarted = false;
                        model.arrivalLogged = false;
                        model.btcExplorationMode = false;
                        model.btcExplorationCompleted = false;
                        
                        if (window.logManager) {
                            window.logManager.addLog(`🔵 BTC 탐색 완료: targetAction 변경 (${previousAction} → 신호 대기)`);
                        }
                        
                        const dialogMessage = `🔵 [탐색 완료] 신호 대기 센터로 복귀 중... 매수 전 예상 수익률: ${buyProfitRate.toFixed(2)}%`;
                        trainerDialog.setText(dialogMessage);
                        if (window.logManager) {
                            window.logManager.addLog(dialogMessage);
                        }
                    }, 2000);
                }
            }
        }
        
        return model.targetAction;
    }

    // 목표 도달 처리
    handleTargetArrival(model, config, targetAction, currentMajority, nbCoins, buyProfitRate, sellProfitRate, trainerDialog) {
        const distanceToTarget = Math.sqrt((model.targetX - model.circle.x) ** 2 + (model.targetY - model.circle.y) ** 2);
        
        if (distanceToTarget < 30) {
            if (!model.arrivalLogged) {
                let arrivalMessage = '';
                if (targetAction === 'BTC 시장 방문') {
                    arrivalMessage = `🎯 트레이너: BTC 시장에 도착! 매수 전 예상 수익률 계산 시작...`;
                } else if (targetAction === 'N/B 길드 방문') {
                    arrivalMessage = `🎯 트레이너: N/B 길드에 도착! 매도 전 예상 수익률 계산 시작...`;
                } else if (targetAction === '신호 대기') {
                    arrivalMessage = `🎯 트레이너: 신호 대기 센터에 도착! 신호 대기 시작...`;
                }
                
                if (arrivalMessage && window.logManager) {
                    window.logManager.addLog(arrivalMessage);
                }
                model.arrivalLogged = true;
            }
            
            model.role.setText(`트레이너 (${targetAction})`);
            
            // N/B 길드 도달 시 처리
            if (targetAction === 'N/B 길드 방문') {
                this.handleNBGuildArrival(model, config, currentMajority, buyProfitRate, sellProfitRate, trainerDialog);
            }

            // 매도영역 감지 시 즉시 매도 실행 (ORANGE일 때만, 코인 보유 시)
            const currentZoneAtArrival = window.gameInitializer?.getCurrentZoneName(model.circle.x, model.circle.y) || '기타영역';
            if (currentZoneAtArrival === '매도영역' && !window.lastSellAction) {
                const coins = (window.gameInitializer?.gameData?.nbCoins ?? window.nbCoins ?? 0);
                const majorityText = (document.getElementById('majority-zone')?.textContent || '').trim();
                if (coins > 0 && typeof majorityText === 'string' && majorityText.includes('ORANGE')) {
                    if (window.logManager) {
                        window.logManager.addLog(`📍 매도영역 감지됨 → 즉시 매도 실행`);
                    }
                    // 다이얼로그 객체 전달
                    const dialogRef = trainerDialog || window.trainerDialog || null;
                    // 현재 다수/수익률 값 확보
                    const buyRateVal = typeof window.buyProfitRate === 'number' ? window.buyProfitRate : (buyProfitRate || 0);
                    const sellRateVal = typeof window.sellProfitRate === 'number' ? window.sellProfitRate : (sellProfitRate || 0);
                    // 목표 액션 보정
                    model.targetAction = '매도';
                    this.handleSellAction(model, config, majorityText, coins, buyRateVal, sellRateVal, dialogRef);
                } else if (coins > 0 && window.logManager) {
                    window.logManager.addLog(`⚠️ 매도영역 감지되었지만 현재 신호가 ORANGE가 아님 → 매도 보류`);
                }
            }
        }
    }

    // N/B 길드 도달 처리
    handleNBGuildArrival(model, config, currentMajority, buyProfitRate, sellProfitRate, trainerDialog) {
        // 매도 전 예상 수익률 계산
        this.calculateSellProfitRate(model, config, trainerDialog);

                    // N/B 길드에 도달했고, ORANGE 신호일 때 코인이 1개 이상이면 즉시 매도
            const coins = (window.gameInitializer?.gameData?.nbCoins ?? window.nbCoins ?? 0);
            const majorityText = (document.getElementById('majority-zone')?.textContent || '').trim() || currentMajority;
            if (!window.lastSellAction && coins > 0 && majorityText.includes('ORANGE')) {
                model.targetAction = '매도';
                if (window.logManager) {
                    window.logManager.addLog(`🏛️ N/B 길드 도달: ORANGE 신호 + 코인 ${coins}개 보유 → 즉시 매도 실행`);
                }
                this.handleSellAction(model, config, majorityText, coins, buyProfitRate || 0, sellProfitRate || 0, trainerDialog);
                return;
            } else if (coins > 0 && !majorityText.includes('ORANGE')) {
                if (window.logManager) {
                    window.logManager.addLog(`⏸️ N/B 길드 도달: 코인 ${coins}개 보유하지만 ORANGE 신호가 아님 → 매도 대기`);
                }
            }
    }

    // 매도 전 예상 수익률 계산
    calculateSellProfitRate(model, config, trainerDialog) {
        if (window.currentPriceManager && window.currentPriceManager.isValidCurrentPrice()) {
            const sellProfitRate = window.currentPriceManager.calculateSellProfitRate(window.buyPrice);
            
            // 매도 전 예상 수익률 표시 업데이트
            const profitColor = sellProfitRate >= 0 ? '#00ff88' : '#ff0088';
            if (window.sellProfitRateDisplay) {
                window.sellProfitRateDisplay.setFill(profitColor);
                window.sellProfitRateDisplay.setText(`매도 전 예상 수익률: ${sellProfitRate.toFixed(2)}%`);
            }
            
            // 상태 즉시 저장
            if (window.saveGameState) {
                window.saveGameState();
            }
            
            // 트레이너 역할 텍스트 업데이트
            model.role.setText(`수익률: ${sellProfitRate.toFixed(2)}%`);
            
            const currentPriceLog = window.currentPriceManager.generateCurrentPriceLog();
            console.log(`📊 트레이너: N/B 길드에서 매도 전 예상 수익률 계산 완료: ${sellProfitRate.toFixed(2)}% (현재가: ₩${currentPriceLog.currentPrice.toLocaleString()})`);
            
            // 트레이너 대화창 업데이트
            const dialogMessage = `N/B 길드: 매도 전 예상 수익률 계산 완료! ${sellProfitRate.toFixed(2)}% (${currentPriceLog.currentPriceText})`;
            trainerDialog.setText(dialogMessage);
            if (window.logManager) {
                window.logManager.addLog(dialogMessage);
            }
        }
    }

    // 트레이너 이동 처리
    updateTrainerMovement(model, config) {
        // 디버그 로그 추가
        if (window.logManager && Math.floor(Date.now() / 1000) % 5 === 0) {
            window.logManager.addLog(`🔍 TrainerStateHandler.updateTrainerMovement 호출됨 - 현재위치: (${model.circle.x.toFixed(1)}, ${model.circle.y.toFixed(1)}), 목표위치: (${model.targetX}, ${model.targetY})`);
        }
        
        const modelX = model.circle.x;
        const modelY = model.circle.y;
        const dx = model.targetX - modelX;
        const dy = model.targetY - modelY;
        
        // 목표 위치가 설정되어 있고 유효한지 확인
        if (typeof model.targetX !== 'undefined' && typeof model.targetY !== 'undefined' && 
            !isNaN(model.targetX) && !isNaN(model.targetY) && 
            model.targetX >= 0 && model.targetY >= 0 && 
            model.targetX <= config.width && model.targetY <= config.height) {
            
            // 목표 위치에 충분히 가까우면 정확히 목표 위치로 이동
            if (Math.abs(dx) <= 2 && Math.abs(dy) <= 2) {
                model.circle.x = model.targetX;
                model.circle.y = model.targetY;
                model.name.x = model.circle.x;
                model.name.y = model.circle.y - 6;
                model.role.x = model.circle.x;
                model.role.y = model.circle.y + 6;
                
                // 도착 로그
                if (window.logManager) {
                    window.logManager.addLog(`✅ 트레이너 도착: (${model.circle.x.toFixed(1)}, ${model.circle.y.toFixed(1)}) | 액션: ${model.targetAction}`);
                }
            } else {
                // 거리 계산
                const distance = Math.sqrt(dx * dx + dy * dy);
                
                if (distance > 0.5) {
                    // 정규화된 방향 벡터 계산
                    const normalizedDx = dx / distance;
                    const normalizedDy = dy / distance;
                    
                    // 이동 속도 적용 (설정된 속도를 그대로 사용)
                    const moveX = normalizedDx * this.movementSpeed;
                    const moveY = normalizedDy * this.movementSpeed;
                    
                    // 위치 업데이트 (안전장치 추가)
                    const newX = model.circle.x + moveX;
                    const newY = model.circle.y + moveY;
                    
                    // 화면 경계 내에 있는지 확인
                    if (newX >= 0 && newX <= config.width && newY >= 0 && newY <= config.height) {
                        model.circle.x = newX;
                        model.circle.y = newY;
                        model.name.x = model.circle.x;
                        model.name.y = model.circle.y - 6;
                        model.role.x = model.circle.x;
                        model.role.y = model.circle.y + 6;
                        
                        // 이동 로그 추가 (거리가 클 때만 출력)
                        if (distance > 10) {
                            const currentPos = `(${model.circle.x.toFixed(1)}, ${model.circle.y.toFixed(1)})`;
                            const remainingDistance = Math.round(distance);
                            if (window.logManager) {
                                window.logManager.addLog(`🚶 트레이너 이동 중: ${currentPos} | 남은거리: ${remainingDistance}px | 속도: ${this.movementSpeed.toFixed(1)} | 액션: ${model.targetAction}`);
                            }
                        }
                    } else {
                        // 화면 경계를 벗어나면 로그 출력
                        if (window.logManager) {
                            window.logManager.addLog(`⚠️ 트레이너 이동 제한: 화면 경계를 벗어남 (${newX.toFixed(1)}, ${newY.toFixed(1)})`);
                        }
                    }
                }
            }
        } else {
            // 목표 위치가 유효하지 않으면 로그 출력
            if (window.logManager) {
                window.logManager.addLog(`⚠️ 트레이너 이동 중단: 유효하지 않은 목표 위치 (${model.targetX}, ${model.targetY})`);
            }
        }
        
        // 이동 후 실제 위치를 사용하여 거리 계산 및 UI 업데이트
        const actualDistanceToTarget = Math.sqrt((model.targetX - model.circle.x) ** 2 + (model.targetY - model.circle.y) ** 2);
        
        // 목표 지점에 도착했는지 확인
        const arrivalThreshold = 10;
        if (actualDistanceToTarget <= arrivalThreshold && !model.arrivalLogged) {
            model.arrivalLogged = true;
            // 작업 완료 기반 시스템으로 변경됨 - trainer-decision-handler에서 처리
            
            if (window.logManager) {
                window.logManager.addLog(`🎯 트레이너 목표 지점 도착! 구역 작업 시작...`);
            }
        }
        
        // 화면 위치 정보 업데이트
        if (window.trainerPositionInfo) {
            const currentPos = `(${model.circle.x.toFixed(1)}, ${model.circle.y.toFixed(1)})`;
            const targetPos = `(${model.targetX.toFixed(1)}, ${model.targetY.toFixed(1)})`;
            
            // 구역 정보 가져오기
            const currentZone = window.gameInitializer?.getCurrentZoneName(model.circle.x, model.circle.y) || '기타영역';
            const targetZone = window.gameInitializer?.getCurrentZoneName(model.targetX, model.targetY) || '기타영역';
            
            const positionText = `📍 위치: ${currentPos} (${currentZone}) | 목표: ${targetPos} (${targetZone}) | 거리: ${Math.round(actualDistanceToTarget)}px`;
            window.trainerPositionInfo.setText(positionText);
        }
        
        // 이동 중 대화창 업데이트
        if (actualDistanceToTarget > 30) {
            model.arrivalLogged = false;
            
            const currentZone = window.gameInitializer?.getCurrentZoneName(model.circle.x, model.circle.y) || '기타영역';
                
            const nextDecision = null;
            
            let movingMessage = '';
            {
                // 더 구체적인 메시지 생성
                if (model.targetAction === 'BTC 시장 탐색') {
                    movingMessage = `🔵 [BTC 시장 탐색] BTC 시장 탐색 구역으로 이동 중... (${Math.round(actualDistanceToTarget)}px 남음)`;
                } else if (model.targetAction === '매수') {
                    movingMessage = `💰 [매수 준비] 매수 영역으로 이동 중... (${Math.round(actualDistanceToTarget)}px 남음)`;
                } else if (model.targetAction === '매도') {
                    movingMessage = `📈 [매도 준비] 매도 영역으로 이동 중... (${Math.round(actualDistanceToTarget)}px 남음)`;
                } else {
                    movingMessage = `🎯 [의사결정: ${model.targetAction}] 이동 중... (${Math.round(actualDistanceToTarget)}px 남음)`;
                }
            }
            
            if (window.trainerDialog) {
                window.trainerDialog.setText(movingMessage);
            }
            if (window.logManager && typeof window.logManager.addLog === 'function') {
                window.logManager.addLog(movingMessage);
            }
        }
    }

    // 트레이너 액션 처리 (매수/매도/대기)
    handleTrainerActions(model, config, currentMajority, nbCoins, buyProfitRate, sellProfitRate, trainerDialog) {
        const startX = (config.width - (120 * 2)) / 2;
        const topY = 60;
        const spacing = 120;
        
        // 매수 액션 처리 (BLUE에서만 허용) + N/B 코인 0개 + 드랍 아이템 0개 + 수익률 조건
        if (model.targetAction === '매수' && !window.lastBuyAction) {
            if (currentMajority !== 'BLUE') {
                return;
            }
            
            // N/B 코인과 드랍 아이템 개수 확인
            const currentNbCoins = window.gameInitializer?.gameData?.nbCoins || 0;
            const dropItemsCount = window.gameInitializer?.gameData?.dropItemsCount || 0;
            
            // N/B 코인이 0개이고 드랍 아이템도 0개여야 매수 가능
            if (currentNbCoins > 0 || dropItemsCount > 0) {
                if (window.logManager) {
                    window.logManager.addLog(`⛔ 매수 보류: N/B 코인 ${currentNbCoins}개 또는 드랍 아이템 ${dropItemsCount}개 남음 → 매수 불가`);
                }
                return;
            }
            
            const dynamicThreshold = (window.gameInitializer && window.gameInitializer.gameData && typeof window.gameInitializer.gameData.buyThresholdPercent === 'number')
                ? window.gameInitializer.gameData.buyThresholdPercent
                : 0.5;
            if (typeof buyProfitRate !== 'number' || isNaN(buyProfitRate) || buyProfitRate < dynamicThreshold) {
                if (window.logManager) {
                    window.logManager.addLog(`⛔ 매수 보류: 매수 전 예상 수익률이 임계치 미만 (${(buyProfitRate||0).toFixed(2)}% < ${dynamicThreshold.toFixed(2)}%)`);
                }
                return;
            }
            this.handleBuyAction(model, config, currentMajority, nbCoins, buyProfitRate, sellProfitRate, trainerDialog);
        }
        // 매도 액션 처리 (ORANGE에서만 허용) + 계산 결과 없으면 금지
        else if (model.targetAction === '매도' && !window.lastSellAction && nbCoins > 0) {
            if (currentMajority !== 'ORANGE') {
                return;
            }
            if (typeof sellProfitRate !== 'number' || isNaN(sellProfitRate)) {
                if (window.logManager) {
                    window.logManager.addLog(`⛔ 매도 보류: 매도 전 예상 수익률 미계산`);
                }
                return;
            }
            this.handleSellAction(model, config, currentMajority, nbCoins, buyProfitRate, sellProfitRate, trainerDialog);
        }
        // 대기 상태
        else if (model.targetAction === '대기') {
            this.handleWaitAction(model, config, currentMajority, nbCoins, buyProfitRate, sellProfitRate, trainerDialog);
        }
        // 정보 수집 후 신호 대기 센터로 복귀
        else if (model.targetAction === '정보 수집 완료') {
            this.handleInfoCollectionComplete(model, config, currentMajority, buyProfitRate, trainerDialog);
        }
    }

    // 매수 액션 처리
    handleBuyAction(model, config, currentMajority, nbCoins, buyProfitRate, sellProfitRate, trainerDialog) {
        // 매수 구역이 숨김 상태이면 작동 금지
        if (window.buyPolygon && window.buyPolygon.visible === false) {
            if (window.logManager) {
                window.logManager.addLog(`⛔ 매수 구역 비활성화(숨김) 상태 → 매수 동작 취소`);
            }
            return;
        }
        window.lastBuyAction = true;
        window.lastSellAction = false;
        // 서버 파일 로그 기록 (매수 실행)
        try { fetch('/api/trainer/decision-log', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ level:'info', action:'BUY_EXECUTE', majority: currentMajority, nbCoinsBefore: nbCoins, buyProfitRate: buyProfitRate, zone: window.gameInitializer?.getCurrentZoneName(model.circle.x, model.circle.y) || '기타영역', ts: Date.now() }) }); } catch(_){ }
        
        // 플래그 리셋
        model.postBuyDecisionMade = false;
        model.postSellDecisionMade = false;
        model.buyColorLogged = false;
        model.sellColorLogged = false;
        model.nbGuildColorLogged = false;
        
        // 매수가격 저장
        if (window.currentPriceManager && window.currentPriceManager.isValidCurrentPrice()) {
            window.buyPrice = window.currentPriceManager.parseCurrentPrice();
            console.log(`💰 매수가격 저장: ₩${window.buyPrice.toLocaleString()}`);
        }
        
        // 매수 완료 후 매수 전 예상 수익률 리셋
        window.buyProfitRate = 0;
        if (window.buyProfitRateDisplay) {
            window.buyProfitRateDisplay.setFill('#00ff88');
            window.buyProfitRateDisplay.setText(`매수 전 예상 수익률: 0.00%`);
        }
        
        // N/B 코인 아이템 생성
        if (window.createNBCoinItem) {
            const createdItem = window.createNBCoinItem();
            if (createdItem) {
                if (window.logManager) {
                    window.logManager.addLog(`🪙 매수 완료: N/B 코인 드랍 아이템 생성 → 위치 (${Math.round(createdItem.position.x)}, ${Math.round(createdItem.position.y)})`);
                }
            } else {
                if (window.logManager) {
                    window.logManager.addLog(`⚠️ 매수 완료: N/B 코인 드랍 아이템 생성 실패 (쿨다운 또는 최대 개수 제한)`);
                }
            }
        }
        
        // UI 업데이트는 NB Coin Drop System에 위임 (충돌 방지)
        if (window.nbCoinDropSystem && window.nbCoinDropSystem.updateNBCoinDisplay) {
            window.nbCoinDropSystem.updateNBCoinDisplay();
        }
        
        // 대화창 업데이트
        let dialogMessage = '';
        if (window.decisionSystem && typeof window.decisionSystem.generateDecisionLogMessage === 'function') {
            dialogMessage = window.decisionSystem.generateDecisionLogMessage('매수 완료', currentMajority, nbCoins, window.nbMinerals, window.nbCoinItems, window.currentPriceText, buyProfitRate, sellProfitRate);
        } else {
            dialogMessage = `💰 [매수 완료] N/B 코인: ${nbCoins}개, 미네랄: ${window.nbMinerals ? window.nbMinerals.toFixed(2) : '0.00'}%, 예상 수익률: ${buyProfitRate.toFixed(2)}%`;
        }
        if (trainerDialog && typeof trainerDialog.setText === 'function') {
            trainerDialog.setText(dialogMessage);
        }
        
        if (window.logManager) {
            window.logManager.addLog(dialogMessage);
        }
        
        console.log(`💰 매수 완료! N/B 코인 드랍 아이템 생성, 매수가: ${window.currentPriceText}`);
        
        // 매수 완료 후 N/B 길드로 이동 (드랍 아이템 수집을 위해)
        if (!model.postBuyDecisionMade) {
            model.postBuyDecisionMade = true;
            
            // N/B 길드로 이동
            model.targetAction = 'N/B 길드 방문';
            model.targetX = 100; // N/B 길드 위치
            model.targetY = 100;
            model.circle.setFillStyle(0xff8800); // 주황색 (N/B 길드)
            
            if (window.logManager) {
                window.logManager.addLog(`🔄 매수 완료 후 N/B 길드로 이동 → 드랍 아이템 수집 대기`);
            }
        }
        
        // 상태 즉시 저장
        if (window.gameInitializer && window.gameInitializer.saveGameData) {
            window.gameInitializer.saveGameData();
        }
        // 서버 파일 로그 기록 (매수 완료)
        try { fetch('/api/trainer/decision-log', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ level:'info', action:'BUY_DONE', majority: currentMajority, nbCoinsAfter: (window.gameInitializer?.gameData?.nbCoins || 0), ts: Date.now() }) }); } catch(_){ }
    }

    // 매도 액션 처리
    handleSellAction(model, config, currentMajority, nbCoins, buyProfitRate, sellProfitRate, trainerDialog) {
        // 매도 구역이 숨김 상태이면 작동 금지
        if (window.sellPolygon && window.sellPolygon.visible === false) {
            if (window.logManager) {
                window.logManager.addLog(`⛔ 매도 구역 비활성화(숨김) 상태 → 매도 동작 취소`);
            }
            return;
        }
        window.lastSellAction = true;
        window.lastBuyAction = false;
        // 서버 파일 로그 기록 (매도 실행)
        try { fetch('/api/trainer/decision-log', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ level:'info', action:'SELL_EXECUTE', majority: currentMajority, nbCoinsBefore: nbCoins, sellProfitRate: sellProfitRate, zone: window.gameInitializer?.getCurrentZoneName(model.circle.x, model.circle.y) || '기타영역', ts: Date.now() }) }); } catch(_){ }
        
        // 플래그 리셋
        model.postBuyDecisionMade = false;
        model.postSellDecisionMade = false;
        model.buyColorLogged = false;
        model.sellColorLogged = false;
        model.nbGuildColorLogged = false;
        
        // 1. 좌측 패널의 N/B COIN 확인
        const leftPanelNbCoins = this.getLeftPanelNbCoins();
        
        // 2. 게임 속 트레이너의 N/B COIN 확인
        const gameNbCoins = window.gameInitializer?.gameData?.nbCoins || 0;
        
        // 3. 둘 다 1개 이상 있을 때만 매도 실행
        if (leftPanelNbCoins <= 0 || gameNbCoins <= 0) {
            if (window.logManager) {
                window.logManager.addLog(`⚠️ 매도 조건 불만족: 좌측패널 N/B 코인 ${leftPanelNbCoins}개, 게임 N/B 코인 ${gameNbCoins}개`);
            }
            return;
        }
        
        // 4. 좌측 패널 N/B COIN -1
        this.decreaseLeftPanelNbCoins();
        
        // 5. 게임 속 N/B COIN -1
        if (window.gameInitializer && window.gameInitializer.gameData) {
            window.gameInitializer.gameData.nbCoins = gameNbCoins - 1;
            
            if (window.logManager) {
                window.logManager.addLog(`💰 매도 실행: 좌측패널 N/B 코인 ${leftPanelNbCoins}개 → ${leftPanelNbCoins - 1}개, 게임 N/B 코인 ${gameNbCoins}개 → ${gameNbCoins - 1}개`);
            }
        }
        
        // UI 갱신: N/B 코인 표시 업데이트
        if (window.nbCoinDropSystem && typeof window.nbCoinDropSystem.updateNBCoinDisplay === 'function') {
            window.nbCoinDropSystem.updateNBCoinDisplay();
        }
        
        // 매도 완료 시 현재 수익률을 N/B 미네랄에 누적
        let currentPnl = 0;
        if (window.learningSystem && typeof window.learningSystem.getCurrentProfitRate === 'function') {
            currentPnl = window.learningSystem.getCurrentProfitRate();
        } else {
            const pnlElement = document.getElementById('selected-coin-pnl');
            if (pnlElement) {
                const pnlMatch = pnlElement.textContent.match(/수익율:\s*([+-]?\d+\.?\d*)%/);
                if (pnlMatch) {
                    currentPnl = parseFloat(pnlMatch[1]);
                }
            }
        }
        
        // 수익률 검증 및 평균 갱신 (중앙 gameData 기반)
        if (!isNaN(currentPnl)) {
            if (window.gameInitializer && window.gameInitializer.gameData) {
                const sumPrev = window.gameInitializer.gameData.nbMineralsSum || 0;
                const cntPrev = window.gameInitializer.gameData.nbMineralsCount || 0;
                const sumNew = sumPrev + currentPnl;
                const cntNew = cntPrev + 1;
                window.gameInitializer.gameData.nbMineralsSum = sumNew;
                window.gameInitializer.gameData.nbMineralsCount = cntNew;
                window.gameInitializer.gameData.nbMinerals = sumNew / cntNew;

                if (window.nbMineralDisplay && typeof window.nbMineralDisplay.setText === 'function') {
                    window.nbMineralDisplay.setText(`N/B 미네랄(평균): ${window.gameInitializer.gameData.nbMinerals.toFixed(2)}%`);
                }

                if (window.logManager) {
                    window.logManager.addLog(`💰 매도 완료: N/B 미네랄 평균 갱신 +${currentPnl.toFixed(2)}% → 평균 ${window.gameInitializer.gameData.nbMinerals.toFixed(2)}% (n=${cntNew})`);
                }
            }
        } else {
            if (window.logManager) {
                window.logManager.addLog(`⚠️ 매도 완료: 수익률 추출 실패 - N/B 미네랄 누적 안됨`);
            }
        }
        
        // 수익률 평균 집계 및 표시 업데이트
        if (!window.pnlStats) {
            window.pnlStats = { sum: 0, count: 0, avg: 0 };
        }
        if (!isNaN(currentPnl)) {
            window.pnlStats.sum += currentPnl;
            window.pnlStats.count += 1;
            window.pnlStats.avg = window.pnlStats.sum / window.pnlStats.count;
        }
        const pnlAvgElement = document.getElementById('selected-coin-pnl');
        if (pnlAvgElement) {
            const avgText = `수익율 평균: ${isFinite(window.pnlStats.avg) ? window.pnlStats.avg.toFixed(2) : '0.00'}%`;
            pnlAvgElement.textContent = avgText;
            pnlAvgElement.style.color = (window.pnlStats.avg >= 0) ? 'lime' : 'red';
        }
        if (window.logManager) {
            window.logManager.addLog(`📈 수익률 평균 업데이트: ${isFinite(window.pnlStats.avg) ? window.pnlStats.avg.toFixed(2) : '0.00'}% (거래 수: ${window.pnlStats.count})`);
        }

        // N/B 미네랄 변경됨 (game-state-manager.js에서 자동 저장됨)
        
        // 매도 시 수익률 리셋
        window.buyPrice = 0;
        window.buyProfitRate = 0;
        window.sellProfitRate = 0;
        
        if (window.buyProfitRateDisplay && typeof window.buyProfitRateDisplay.setText === 'function') {
            window.buyProfitRateDisplay.setFill('#00ff88');
            window.buyProfitRateDisplay.setText(`매수 전 예상 수익률: 0.00%`);
        }
        if (window.sellProfitRateDisplay && typeof window.sellProfitRateDisplay.setText === 'function') {
            window.sellProfitRateDisplay.setFill('#ff0088');
            window.sellProfitRateDisplay.setText(`매도 전 예상 수익률: 0.00%`);
        }
        
        // UI 업데이트는 NB Coin Drop System에 위임 (충돌 방지)
        if (window.nbCoinDropSystem && window.nbCoinDropSystem.updateNBCoinDisplay) {
            window.nbCoinDropSystem.updateNBCoinDisplay();
        }
        if (window.nbMineralDisplay && typeof window.nbMineralDisplay.setText === 'function') {
            window.nbMineralDisplay.setText(`N/B 미네랄: ${window.nbMinerals.toFixed(2)}%`);
        }
        
        // 대화창 업데이트
        let dialogMessage = '';
        const currentNbCoins = window.gameInitializer?.gameData?.nbCoins || 0;
        if (window.decisionSystem && typeof window.decisionSystem.generateDecisionLogMessage === 'function') {
            dialogMessage = window.decisionSystem.generateDecisionLogMessage('매도 완료', currentMajority, currentNbCoins, window.nbMinerals, window.nbCoinItems, window.currentPriceText, buyProfitRate, sellProfitRate);
        } else {
            dialogMessage = `💸 [매도 완료] N/B 코인: ${currentNbCoins}개, 미네랄: ${window.nbMinerals.toFixed(2)}%, 예상 수익률: ${sellProfitRate.toFixed(2)}%`;
        }
        if (trainerDialog && typeof trainerDialog.setText === 'function') {
            trainerDialog.setText(dialogMessage);
        }
        
        if (window.logManager) {
            window.logManager.addLog(dialogMessage);
        }
        
        console.log(`💸 매도 완료! N/B 코인: ${window.nbCoins}개, N/B 미네랄 누적: ${window.nbMinerals.toFixed(2)}%, 수익률 리셋`);
        
        // 매도 완료 후 상태 요약 로그
        if (window.logManager) {
            const summaryLog = `📊 매도 완료 후 상태 요약: N/B 코인 ${window.nbCoins}개, N/B 미네랄 ${window.nbMinerals.toFixed(2)}%, 드랍 아이템 ${window.nbCoinItems ? window.nbCoinItems.length : 0}개`;
            window.logManager.addLog(summaryLog);
        }
        
        // 매도 완료 후 다음 의사결정 실행
        if (!model.postSellDecisionMade) {
            model.postSellDecisionMade = true;
            const nextDecision = window.decisionSystem && typeof window.decisionSystem.getNextDecision === 'function'
                ? window.decisionSystem.getNextDecision(currentMajority, window.nbCoins, buyProfitRate, sellProfitRate, (config.width - (120 * 2)) / 2, 60, 120, config)
                : null;
                
            if (nextDecision) {
                model.targetAction = nextDecision.action;
                model.targetX = nextDecision.targetX;
                model.targetY = nextDecision.targetY;
                
                let actionColor = 0x88ccff;
                if (window.decisionSystem && typeof window.decisionSystem.getActionColor === 'function') {
                    actionColor = window.decisionSystem.getActionColor(model.targetAction);
                } else {
                    switch (model.targetAction) {
                        case '매수': actionColor = 0x0088ff; break;
                        case '매도': actionColor = 0xff8800; break;
                        case '신호 대기': actionColor = 0x88ccff; break;
                        case 'BTC 시장 탐색': actionColor = 0x88ff88; break;
                        default: actionColor = 0x88ccff;
                    }
                }
                model.circle.setFillStyle(actionColor);
                
                if (window.logManager) {
                    window.logManager.addLog(`🔄 매도 완료 후 다음 의사결정: ${model.targetAction}`);
                }
            }
        }
        
        // 상태 즉시 저장
        if (window.gameInitializer && window.gameInitializer.saveGameData) {
            window.gameInitializer.saveGameData();
        }
        // 서버 파일 로그 기록 (매도 완료)
        try { fetch('/api/trainer/decision-log', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ level:'info', action:'SELL_DONE', majority: currentMajority, nbCoinsAfter: (window.gameInitializer?.gameData?.nbCoins || 0), ts: Date.now() }) }); } catch(_){ }
    }

    // 대기 액션 처리
    handleWaitAction(model, config, currentMajority, nbCoins, buyProfitRate, sellProfitRate, trainerDialog) {
        window.lastBuyAction = false;
        window.lastSellAction = false;
        
        let dialogMessage = '';
        if (window.decisionSystem && typeof window.decisionSystem.generateDecisionLogMessage === 'function') {
            dialogMessage = window.decisionSystem.generateDecisionLogMessage('대기', currentMajority, nbCoins, window.nbMinerals, window.nbCoinItems, window.currentPriceText, buyProfitRate, sellProfitRate);
        } else {
            dialogMessage = `⏳ [대기] N/B 코인: ${nbCoins}개, 미네랄: ${window.nbMinerals ? window.nbMinerals.toFixed(2) : '0.00'}%, 현재 구역: ${currentMajority}`;
        }
        if (trainerDialog && typeof trainerDialog.setText === 'function') {
            trainerDialog.setText(dialogMessage);
        }
        
        if (window.logManager) {
            window.logManager.addLog(dialogMessage);
        }
    }

    // 정보 수집 완료 처리
    handleInfoCollectionComplete(model, config, currentMajority, buyProfitRate, trainerDialog) {
        // 예상 수익률이 계산되었고 BLUE 신호라면 즉시 매수
        if (currentMajority === 'BLUE' && buyProfitRate !== 0) {
            model.targetAction = '매수';
            model.targetX = (config.width - (120 * 2)) / 2;
            model.targetY = 60;
            model.circle.setFillStyle(0x0088ff);
            
            console.log(`📈 트레이너: 정보 수집 완료 후 즉시 매수! 예상 수익률: ${buyProfitRate.toFixed(2)}%`);
            const dialogMessage = `📈 [정보 수집 완료] 예상 수익률 계산됨(${buyProfitRate.toFixed(2)}%) → 즉시 매수!`;
            if (trainerDialog && typeof trainerDialog.setText === 'function') {
                trainerDialog.setText(dialogMessage);
            }
            
            if (window.logManager) {
                window.logManager.addLog(dialogMessage);
            }
        } else {
            // 예상 수익률이 계산되지 않았거나 BLUE 신호가 아니면 신호 대기 센터로 복귀
            model.targetAction = '신호 대기';
            model.targetX = config.width / 2;
            model.targetY = config.height / 2;
            model.circle.setFillStyle(0x88ccff);
            model.waitCheckTimer = 0;
            model.countdownStarted = false;
            
            console.log(`🔵 트레이너: 정보 수집 완료, 신호 대기 센터로 복귀!`);
            const dialogMessage = `🔵 [정보 수집 완료] 신호 대기 센터로 복귀 중...`;
            if (trainerDialog && typeof trainerDialog.setText === 'function') {
                trainerDialog.setText(dialogMessage);
            }
            
            if (window.logManager) {
                window.logManager.addLog(dialogMessage);
            }
        }
    }
    
    // 좌측 패널의 N/B COIN 개수 가져오기
    getLeftPanelNbCoins() {
        try {
            // 좌측 패널에서 N/B 코인 개수 확인
            const nbCoinElement = document.getElementById('nb-coin-count') || document.getElementById('nb-coin-display');
            if (nbCoinElement) {
                const text = nbCoinElement.textContent || '';
                const match = text.match(/(\d+)/);
                return match ? parseInt(match[1]) : 0;
            }
            
            // 대안: N/B 코인 드롭 시스템에서 확인
            if (window.gameInitializer?.gameData?.nbCoins !== undefined) {
                return window.gameInitializer.gameData.nbCoins;
            }
            
            return 0;
        } catch (e) {
            return 0;
        }
    }
    
    // 좌측 패널 N/B COIN 감소
    decreaseLeftPanelNbCoins() {
        try {
            const nbCoinElement = document.getElementById('nb-coin-count') || document.getElementById('nb-coin-display');
            if (nbCoinElement) {
                const currentText = nbCoinElement.textContent || '';
                const match = currentText.match(/(\d+)/);
                if (match) {
                    const currentCount = parseInt(match[1]);
                    const newCount = Math.max(0, currentCount - 1);
                    const newText = currentText.replace(/\d+/, newCount.toString());
                    nbCoinElement.textContent = newText;
                }
            }
        } catch (e) {
            // 좌측 패널 업데이트 실패 시 무시
        }
    }
}

// 전역 인스턴스 생성
window.trainerStateHandler = new TrainerStateHandler();
