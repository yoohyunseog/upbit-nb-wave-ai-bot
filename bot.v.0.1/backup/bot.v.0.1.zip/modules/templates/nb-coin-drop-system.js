// N/B 코인 드랍 시스템 모듈
// 매수 구역에서 N/B 코인을 랜덤 위치로 드랍하는 기능을 담당

class NBCoinDropSystem {
    constructor() {
        this.nbCoinItems = [];
        this.dropCount = 0;
        this.maxDrops = 10; // 최대 드랍 개수 제한
        this.dropCooldown = 5000; // 드랍 쿨다운 (5초)
        this.lastDropTime = 0;
        this.isInitialized = false;
    }

    // 시스템 초기화
    initialize(scene, config) {
        if (this.isInitialized) {
            console.log('⚠️ N/B 코인 드랍 시스템이 이미 초기화되었습니다.');
            return;
        }

        this.scene = scene;
        this.config = config;
        this.isInitialized = true;

        // 전역 함수로 등록
        window.createNBCoinItem = () => this.createNBCoinItem();
        window.dropNBCoin = (x, y) => this.dropNBCoin(x, y);
        window.removeNBCoinItem = (item) => this.removeNBCoinItem(item);
        window.getNBCoinItems = () => this.nbCoinItems;
        window.clearNBCoinItems = () => this.clearNBCoinItems();

        console.log('✅ N/B 코인 드랍 시스템 초기화 완료');
    }

    // N/B 코인 드랍 (외부에서 호출하는 메서드)
    dropNBCoin(x, y) {
        if (!this.isInitialized) {
            console.error('❌ N/B 코인 드랍 시스템이 초기화되지 않았습니다.');
            return null;
        }

        // 씬 준비 보장
        if (!this.scene && window.gameInitializer?.scene) {
            this.scene = window.gameInitializer.scene;
        }
        if (!this.scene || !this.scene.add) {
            console.error('❌ Scene not ready: dropNBCoin 호출 시 this.scene이 유효하지 않습니다.');
            return null;
        }

        // 드랍 개수 제한 확인
        if (this.nbCoinItems.length >= this.maxDrops) {
            console.log(`⚠️ 최대 드랍 개수(${this.maxDrops}개)에 도달했습니다.`);
            return null;
        }

        // 쿨다운 확인
        const currentTime = Date.now();
        if (currentTime - this.lastDropTime < this.dropCooldown) {
            console.log(`⏳ 드랍 쿨다운 중... (${Math.ceil((this.dropCooldown - (currentTime - this.lastDropTime)) / 1000)}초 남음)`);
            return null;
        }

        // 지정된 위치 근처에 랜덤 위치 생성
        const margin = 50;
        const randomOffset = 30; // 지정된 위치에서 ±30px 범위
        const dropX = x + (Math.random() - 0.5) * randomOffset * 2;
        const dropY = y + (Math.random() - 0.5) * randomOffset * 2;

        // 화면 경계 내로 제한
        const finalX = Math.max(margin, Math.min(this.config.width - margin, dropX));
        const finalY = Math.max(margin, Math.min(this.config.height - margin, dropY));

        // N/B 코인 아이템 생성
        const item = {
            id: `nb-coin-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
            polygon: this.scene.add.polygon(finalX, finalY, [
                0, -8, 6, -4, 6, 4, 0, 8, -6, 4, -6, -4
            ], 0xffaa00),
            collected: false,
            connectionLines: [],
            dropTime: currentTime,
            position: { x: finalX, y: finalY }
        };

        item.polygon.setOrigin(0.5, 0.5);
        item.polygon.setInteractive();

        // 회전 애니메이션 (tweens가 준비된 경우에만)
        if (this.scene.tweens) {
            this.scene.tweens.add({
                targets: item.polygon,
                rotation: Math.PI * 2,
                duration: 3000,
                repeat: -1,
                ease: 'Linear'
            });
        }

        // 클릭 이벤트 추가
        item.polygon.on('pointerdown', () => {
            this.collectNBCoinItem(item);
        });

        // 호버 효과
        item.polygon.on('pointerover', () => {
            item.polygon.setScale(1.2);
        });

        item.polygon.on('pointerout', () => {
            item.polygon.setScale(1.0);
        });

        this.nbCoinItems.push(item);
        this.dropCount++;
        this.lastDropTime = currentTime;

        // 드랍 아이템 카운터 증가
        if (window.gameInitializer && window.gameInitializer.gameData) {
            window.gameInitializer.gameData.dropItemsCount = (window.gameInitializer.gameData.dropItemsCount || 0) + 1;
            
            if (window.logManager) {
                window.logManager.addLog(`🪙 드랍 아이템 생성: 위치 (${Math.round(finalX)}, ${Math.round(finalY)}) → 드랍 아이템 ${window.gameInitializer.gameData.dropItemsCount}개`);
            }
        }

        console.log(`✅ N/B 코인 드랍 완료 - 위치: (${Math.round(finalX)}, ${Math.round(finalY)})`);
        return item;
    }

    // N/B 코인 아이템 생성 (매수 구역에서 호출)
    createNBCoinItem() {
        if (!this.isInitialized) {
            console.error('❌ N/B 코인 드랍 시스템이 초기화되지 않았습니다.');
            return null;
        }

        // 씬 준비 보장
        if (!this.scene && window.gameInitializer?.scene) {
            this.scene = window.gameInitializer.scene;
        }
        if (!this.scene || !this.scene.add) {
            console.error('❌ Scene not ready: createNBCoinItem 호출 시 this.scene이 유효하지 않습니다.');
            return null;
        }

        // 드랍 개수 제한 확인
        if (this.nbCoinItems.length >= this.maxDrops) {
            console.log(`⚠️ 최대 드랍 개수(${this.maxDrops}개)에 도달했습니다.`);
            return null;
        }

        // 쿨다운 확인
        const currentTime = Date.now();
        if (currentTime - this.lastDropTime < this.dropCooldown) {
            console.log(`⏳ 드랍 쿨다운 중... (${Math.ceil((this.dropCooldown - (currentTime - this.lastDropTime)) / 1000)}초 남음)`);
            return null;
        }

        // 랜덤 위치 생성 (화면 경계에서 50px 안쪽)
        const margin = 50;
        const x = Math.random() * (this.config.width - 2 * margin) + margin;
        const y = Math.random() * (this.config.height - 2 * margin) + margin;

        // N/B 코인 아이템 생성
        const item = {
            id: `nb-coin-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
            polygon: this.scene.add.polygon(x, y, [
                0, -8, 6, -4, 6, 4, 0, 8, -6, 4, -6, -4
            ], 0xffaa00),
            collected: false,
            connectionLines: [],
            dropTime: currentTime,
            position: { x, y }
        };

        item.polygon.setOrigin(0.5, 0.5);
        item.polygon.setInteractive();

        // 회전 애니메이션 (tweens가 준비된 경우에만)
        if (this.scene.tweens) {
            this.scene.tweens.add({
                targets: item.polygon,
                rotation: Math.PI * 2,
                duration: 3000,
                repeat: -1,
                ease: 'Linear'
            });
        }

        // 클릭 이벤트 추가
        item.polygon.on('pointerdown', () => {
            this.collectNBCoinItem(item);
        });

        // 호버 효과
        item.polygon.on('pointerover', () => {
            item.polygon.setScale(1.2);
        });

        item.polygon.on('pointerout', () => {
            item.polygon.setScale(1.0);
        });

        this.nbCoinItems.push(item);
        this.dropCount++;
        this.lastDropTime = currentTime;

        // 드랍 아이템 카운터 증가
        if (window.gameInitializer && window.gameInitializer.gameData) {
            window.gameInitializer.gameData.dropItemsCount = (window.gameInitializer.gameData.dropItemsCount || 0) + 1;
        }

        // 로그 기록
        if (window.logManager) {
            const dropItemsCount = window.gameInitializer?.gameData?.dropItemsCount || 0;
            window.logManager.addLog(`🪙 N/B 코인 드랍: 위치 (${Math.round(x)}, ${Math.round(y)}) → 드랍 아이템 ${dropItemsCount}개`);
        }

        console.log(`🪙 N/B 코인 아이템 생성: 위치 (${Math.round(x)}, ${Math.round(y)}) | 총 ${this.nbCoinItems.length}개`);

        // UI 업데이트
        this.updateNBCoinDisplay();

        return item;
    }

    // N/B 코인 아이템 수집
    collectNBCoinItem(item) {
        if (item.collected) {
            return;
        }

        item.collected = true;

        // 수집 애니메이션
        this.scene.tweens.add({
            targets: item.polygon,
            scaleX: 0,
            scaleY: 0,
            alpha: 0,
            duration: 500,
            ease: 'Power2',
            onComplete: () => {
                this.removeNBCoinItem(item);
            }
        });

        // 수집 효과음 (옵션)
        if (window.soundManager) {
            window.soundManager.playCollectSound();
        }

        // N/B 코인 개수 증가 및 드랍 아이템 카운터 감소
        if (window.gameInitializer && window.gameInitializer.gameData) {
            const previousCoins = window.gameInitializer.gameData.nbCoins || 0;
            const previousDropItems = window.gameInitializer.gameData.dropItemsCount || 0;
            
            // N/B 코인 증가
            window.gameInitializer.gameData.nbCoins = previousCoins + 1;
            
            // 드랍 아이템 카운터 감소 (수집되었으므로)
            window.gameInitializer.gameData.dropItemsCount = Math.max(0, previousDropItems - 1);
            
            // 수집된 아이템 누적 카운터 (통계용)
            window.gameInitializer.gameData.dropItemsCollected = (window.gameInitializer.gameData.dropItemsCollected || 0) + 1;
            
            // 로그 기록
            if (window.logManager) {
                window.logManager.addLog(`💰 N/B 코인 수집 완료: 위치 (${Math.round(item.position.x)}, ${Math.round(item.position.y)}) → N/B 코인 ${window.gameInitializer.gameData.nbCoins}개 (+1), 드랍 아이템 ${window.gameInitializer.gameData.dropItemsCount}개 (-1), 누적 수집: ${window.gameInitializer.gameData.dropItemsCollected}개`);
            }
            
            console.log(`💰 N/B 코인 수집 완료: 위치 (${Math.round(item.position.x)}, ${Math.round(item.position.y)}) → N/B 코인 ${window.gameInitializer.gameData.nbCoins}개, 드랍 아이템 ${window.gameInitializer.gameData.dropItemsCount}개`);
            
            // 자동 저장 호출
            if (window.gameInitializer.saveGameData) {
                window.gameInitializer.saveGameData();
            }
        } else {
            if (window.logManager) {
                window.logManager.addLog(`⚠️ N/B 코인 수집 실패: gameData 초기화되지 않음`);
            }
        }

        // UI 업데이트
        this.updateNBCoinDisplay();
    }

    // N/B 코인 아이템 제거
    removeNBCoinItem(item) {
        const index = this.nbCoinItems.indexOf(item);
        if (index > -1) {
            this.nbCoinItems.splice(index, 1);
        }

        // 연결선들 제거
        item.connectionLines.forEach(line => {
            if (line && line.destroy) {
                line.destroy();
            }
        });

        // 폴리곤 제거
        if (item.polygon && item.polygon.destroy) {
            item.polygon.destroy();
        }

        // UI 업데이트
        this.updateNBCoinDisplay();
    }

    // 모든 N/B 코인 아이템 제거
    clearNBCoinItems() {
        this.nbCoinItems.forEach(item => {
            this.removeNBCoinItem(item);
        });
        this.nbCoinItems = [];
        this.dropCount = 0;
        this.lastDropTime = 0;

        console.log('🗑️ 모든 N/B 코인 아이템 제거 완료');
    }

    // N/B 코인 디스플레이 업데이트
    updateNBCoinDisplay() {
        if (window.nbCoinDisplay && typeof window.nbCoinDisplay.setText === 'function') {
            const nbCoins = window.gameInitializer?.gameData?.nbCoins || 0;
            const dropItemsCount = window.gameInitializer?.gameData?.dropItemsCount || 0;
            const collected = window.gameInitializer?.gameData?.dropItemsCollected || 0;
            window.nbCoinDisplay.setText(`N/B 코인: ${nbCoins}개 (드랍 아이템: ${dropItemsCount}개, 누적 수집: ${collected}개)`);
        }
    }

    // 매수 구역 도착 시 자동 드랍
    handleBuyAreaArrival() {
        if (!this.isInitialized) {
            return;
        }

        // 자동 드랍 실행
        const droppedItem = this.createNBCoinItem();
        
        if (droppedItem) {
            // 트레이너 대화창 업데이트
            if (window.trainerDialog) {
                const currentTime = new Date().toLocaleTimeString();
                const dialogText = `🪙 매수 구역 도착 → N/B 코인 드랍 완료 | 위치: (${Math.round(droppedItem.position.x)}, ${Math.round(droppedItem.position.y)}) | 시간: ${currentTime}`;
                if (window.trainerDialog && typeof window.trainerDialog.setText === 'function') {
                    window.trainerDialog.setText(dialogText);
                }
                
                if (window.logManager) {
                    window.logManager.addLog(`📺 화면출력(트레이너대화창): ${dialogText}`);
                }
            }
        }
    }

    // 시스템 상태 확인
    getSystemStatus() {
        return {
            isInitialized: this.isInitialized,
            totalItems: this.nbCoinItems.length,
            dropCount: this.dropCount,
            maxDrops: this.maxDrops,
            cooldownRemaining: Math.max(0, this.dropCooldown - (Date.now() - this.lastDropTime))
        };
    }

    // 설정 업데이트
    updateSettings(settings) {
        if (settings.maxDrops !== undefined) {
            this.maxDrops = settings.maxDrops;
        }
        if (settings.dropCooldown !== undefined) {
            this.dropCooldown = settings.dropCooldown;
        }
        
        console.log('⚙️ N/B 코인 드랍 시스템 설정 업데이트:', settings);
    }

    // 디버그 정보 출력
    debugInfo() {
        console.log('🔍 N/B 코인 드랍 시스템 디버그 정보:');
        console.log('- 초기화 상태:', this.isInitialized);
        console.log('- 총 아이템 수:', this.nbCoinItems.length);
        console.log('- 드랍 횟수:', this.dropCount);
        console.log('- 최대 드랍 개수:', this.maxDrops);
        console.log('- 쿨다운 남은 시간:', Math.max(0, this.dropCooldown - (Date.now() - this.lastDropTime)), 'ms');
        
        this.nbCoinItems.forEach((item, index) => {
            console.log(`- 아이템 ${index + 1}: ID=${item.id}, 위치=(${Math.round(item.position.x)}, ${Math.round(item.position.y)}), 수집됨=${item.collected}`);
        });
    }
}

// 전역 인스턴스 생성
window.nbCoinDropSystem = new NBCoinDropSystem();

// 전역 함수들
window.createNBCoinItem = () => window.nbCoinDropSystem.createNBCoinItem();
window.dropNBCoin = (x, y) => window.nbCoinDropSystem.dropNBCoin(x, y);
window.removeNBCoinItem = (item) => window.nbCoinDropSystem.removeNBCoinItem(item);
window.getNBCoinItems = () => window.nbCoinDropSystem.nbCoinItems;
window.clearNBCoinItems = () => window.nbCoinDropSystem.clearNBCoinItems();
window.handleBuyAreaArrival = () => window.nbCoinDropSystem.handleBuyAreaArrival();

// 전역 디버깅 함수들
window.debugNBCoinSystem = () => {
    if (window.nbCoinDropSystem) {
        window.nbCoinDropSystem.debugInfo();
        return window.nbCoinDropSystem.getSystemStatus();
    } else {
        console.log('❌ N/B 코인 드랍 시스템이 초기화되지 않았습니다.');
        return null;
    }
};

window.getNBCoinSystemStatus = () => {
    if (window.nbCoinDropSystem) {
        return window.nbCoinDropSystem.getSystemStatus();
    } else {
        console.log('❌ N/B 코인 드랍 시스템이 초기화되지 않았습니다.');
        return null;
    }
};

window.forceDropNBCoin = (x, y) => {
    if (window.nbCoinDropSystem) {
        return window.nbCoinDropSystem.dropNBCoin(x, y);
    } else {
        console.log('❌ N/B 코인 드랍 시스템이 초기화되지 않았습니다.');
        return null;
    }
};
