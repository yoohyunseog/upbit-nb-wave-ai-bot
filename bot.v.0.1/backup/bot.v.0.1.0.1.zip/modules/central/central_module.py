# ===== Central Module - Python Backend =====

import json
import threading
import time
from datetime import datetime
from flask import jsonify, Response

class CentralModule:
    """Central Nervous System 모듈"""
    
    def __init__(self):
        self.is_running = False
        self.modules = {}
        self.event_listeners = {}
        self.data_cache = {}
        self.event_history = []
        self.start_time = datetime.now()
        self.monitor_thread = None
        
    def start_system(self):
        """중추 시스템 시작"""
        if self.is_running:
            return {'status': 'error', 'message': 'System already running'}
        
        self.is_running = True
        self.start_time = datetime.now()
        
        # 모니터링 스레드 시작
        self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitor_thread.start()
        
        self._add_event('system:start', {'timestamp': datetime.now().isoformat()})
        
        return {'status': 'success', 'message': 'Central system started'}
    
    def stop_system(self):
        """중추 시스템 중지"""
        if not self.is_running:
            return {'status': 'error', 'message': 'System not running'}
        
        self.is_running = False
        
        if self.monitor_thread:
            self.monitor_thread.join(timeout=5)
        
        self._add_event('system:stop', {'timestamp': datetime.now().isoformat()})
        
        return {'status': 'success', 'message': 'Central system stopped'}
    
    def _monitor_loop(self):
        """메인 모니터링 루프"""
        while self.is_running:
            try:
                # 시스템 상태 확인
                self._check_system_health()
                
                # 데이터 동기화
                self._sync_data()
                
                # 이벤트 처리
                self._process_events()
                
                # 5초 대기
                time.sleep(5)
                
            except Exception as e:
                self._add_event('system:error', {'error': str(e)})
                time.sleep(10)
    
    def _check_system_health(self):
        """시스템 상태 확인"""
        health_status = {
            'uptime': (datetime.now() - self.start_time).total_seconds(),
            'active_modules': len(self.modules),
            'cache_entries': len(self.data_cache),
            'event_count': len(self.event_history),
            'timestamp': datetime.now().isoformat()
        }
        
        self.data_cache['system_health'] = health_status
        self._add_event('system:health', health_status)
    
    def _sync_data(self):
        """데이터 동기화"""
        # 각 모듈의 데이터를 중추 시스템으로 동기화
        sync_data = {
            'trading': self._get_module_data('trading'),
            'wallet': self._get_module_data('wallet'),
            'settings': self._get_module_data('settings'),
            'timestamp': datetime.now().isoformat()
        }
        
        self.data_cache['sync_data'] = sync_data
        self._add_event('data:sync', sync_data)
    
    def _get_module_data(self, module_name):
        """모듈 데이터 조회"""
        try:
            # 실제 구현에서는 각 모듈의 데이터를 가져옴
            if module_name == 'trading':
                return {'status': 'active', 'last_update': datetime.now().isoformat()}
            elif module_name == 'wallet':
                return {'status': 'active', 'last_update': datetime.now().isoformat()}
            elif module_name == 'settings':
                return {'status': 'active', 'last_update': datetime.now().isoformat()}
            else:
                return {'status': 'unknown', 'last_update': datetime.now().isoformat()}
        except Exception as e:
            return {'status': 'error', 'error': str(e)}
    
    def _process_events(self):
        """이벤트 처리"""
        # 최근 이벤트들을 처리
        recent_events = self.event_history[-10:]  # 최근 10개 이벤트
        
        for event in recent_events:
            if event['type'] not in self.event_listeners:
                continue
            
            for listener in self.event_listeners[event['type']]:
                try:
                    listener(event)
                except Exception as e:
                    self._add_event('system:error', {'error': f'Event listener error: {str(e)}'})
    
    def _add_event(self, event_type, data):
        """이벤트 추가"""
        event = {
            'type': event_type,
            'data': data,
            'timestamp': datetime.now().isoformat()
        }
        
        self.event_history.append(event)
        
        # 이벤트 히스토리 크기 제한 (최근 100개)
        if len(self.event_history) > 100:
            self.event_history = self.event_history[-100:]
    
    def register_module(self, module_name, module_data):
        """모듈 등록"""
        self.modules[module_name] = {
            'data': module_data,
            'registered_at': datetime.now().isoformat(),
            'last_update': datetime.now().isoformat()
        }
        
        self._add_event('module:register', {
            'module': module_name,
            'data': module_data
        })
        
        return {'status': 'success', 'message': f'Module {module_name} registered'}
    
    def update_module(self, module_name, module_data):
        """모듈 업데이트"""
        if module_name not in self.modules:
            return self.register_module(module_name, module_data)
        
        self.modules[module_name]['data'] = module_data
        self.modules[module_name]['last_update'] = datetime.now().isoformat()
        
        self._add_event('module:update', {
            'module': module_name,
            'data': module_data
        })
        
        return {'status': 'success', 'message': f'Module {module_name} updated'}
    
    def unregister_module(self, module_name):
        """모듈 등록 해제"""
        if module_name in self.modules:
            del self.modules[module_name]
            
            self._add_event('module:unregister', {
                'module': module_name
            })
            
            return {'status': 'success', 'message': f'Module {module_name} unregistered'}
        
        return {'status': 'error', 'message': f'Module {module_name} not found'}
    
    def add_event_listener(self, event_type, callback):
        """이벤트 리스너 추가"""
        if event_type not in self.event_listeners:
            self.event_listeners[event_type] = []
        
        self.event_listeners[event_type].append(callback)
        
        return {'status': 'success', 'message': f'Event listener added for {event_type}'}
    
    def remove_event_listener(self, event_type, callback):
        """이벤트 리스너 제거"""
        if event_type in self.event_listeners:
            if callback in self.event_listeners[event_type]:
                self.event_listeners[event_type].remove(callback)
                return {'status': 'success', 'message': f'Event listener removed for {event_type}'}
        
        return {'status': 'error', 'message': f'Event listener not found for {event_type}'}
    
    def get_system_status(self):
        """시스템 상태 조회"""
        return {
            'is_running': self.is_running,
            'uptime': (datetime.now() - self.start_time).total_seconds(),
            'active_modules': list(self.modules.keys()),
            'module_count': len(self.modules),
            'event_count': len(self.event_history),
            'cache_entries': len(self.data_cache),
            'start_time': self.start_time.isoformat(),
            'last_update': datetime.now().isoformat()
        }
    
    def get_module_status(self, module_name=None):
        """모듈 상태 조회"""
        if module_name:
            return self.modules.get(module_name, {'status': 'not_found'})
        
        return self.modules
    
    def get_event_history(self, limit=20):
        """이벤트 히스토리 조회"""
        return self.event_history[-limit:] if limit else self.event_history
    
    def get_cached_data(self, data_type=None):
        """캐시된 데이터 조회"""
        if data_type:
            return self.data_cache.get(data_type, {})
        
        return self.data_cache
    
    def clear_cache(self, data_type=None):
        """캐시 클리어"""
        if data_type:
            if data_type in self.data_cache:
                del self.data_cache[data_type]
                return {'status': 'success', 'message': f'Cache cleared for {data_type}'}
            else:
                return {'status': 'error', 'message': f'Cache type {data_type} not found'}
        else:
            self.data_cache.clear()
            return {'status': 'success', 'message': 'All cache cleared'}
    
    def get_system_stats(self):
        """시스템 통계 조회"""
        return {
            'uptime_seconds': (datetime.now() - self.start_time).total_seconds(),
            'total_events': len(self.event_history),
            'active_modules': len(self.modules),
            'cache_entries': len(self.data_cache),
            'event_listeners': sum(len(listeners) for listeners in self.event_listeners.values()),
            'system_health': self.data_cache.get('system_health', {}),
            'timestamp': datetime.now().isoformat()
        }
    
    def reset_system(self):
        """시스템 리셋"""
        self.stop_system()
        
        # 데이터 초기화
        self.modules.clear()
        self.data_cache.clear()
        self.event_history.clear()
        self.event_listeners.clear()
        
        # 시스템 재시작
        return self.start_system()

# 전역 인스턴스
central_module = CentralModule()
