// ===== Central Module - JavaScript Frontend =====

class CentralFrontend {
    constructor() {
        this.isInitialized = false;
        this.systemStatus = null;
        this.modules = {};
        this.events = [];
        this.eventSource = null;
        this.refreshInterval = null;
    }
    
    async initialize() {
        if (this.isInitialized) return;
        
        console.log('🧠 Initializing Central Frontend...');
        
        // 중추 시스템 시작
        await this.startCentralSystem();
        
        // 초기 데이터 로드
        await this.loadSystemData();
        
        // 이벤트 리스너 등록
        this.registerEventListeners();
        
        // 실시간 이벤트 스트림 시작
        this.startEventStream();
        
        // 자동 새로고침 시작
        this.startAutoRefresh();
        
        this.isInitialized = true;
        console.log('✅ Central Frontend initialized');
    }
    
    registerEventListeners() {
        // 시스템 시작/중지 버튼
        const startBtn = document.getElementById('central-start-btn');
        const stopBtn = document.getElementById('central-stop-btn');
        
        if (startBtn) {
            startBtn.addEventListener('click', () => {
                this.startCentralSystem();
            });
        }
        
        if (stopBtn) {
            stopBtn.addEventListener('click', () => {
                this.stopCentralSystem();
            });
        }
        
        // 새로고침 버튼
        const refreshBtn = document.getElementById('central-refresh-btn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => {
                this.loadSystemData();
            });
        }
        
        // 시스템 리셋 버튼
        const resetBtn = document.getElementById('central-reset-btn');
        if (resetBtn) {
            resetBtn.addEventListener('click', () => {
                this.resetCentralSystem();
            });
        }
        
        // 통계 보기 버튼
        const statsBtn = document.getElementById('central-stats-btn');
        if (statsBtn) {
            statsBtn.addEventListener('click', () => {
                this.showSystemStats();
            });
        }
    }
    
    async startCentralSystem() {
        try {
            const response = await fetch('/api/central/start', {
                method: 'POST'
            });
            
            const result = await response.json();
            
            if (result.status === 'success') {
                console.log('Central system started');
                this.updateSystemStatus();
            } else {
                console.error('Failed to start central system:', result.message);
            }
            
        } catch (error) {
            console.error('Error starting central system:', error);
        }
    }
    
    async stopCentralSystem() {
        try {
            const response = await fetch('/api/central/stop', {
                method: 'POST'
            });
            
            const result = await response.json();
            
            if (result.status === 'success') {
                console.log('Central system stopped');
                this.updateSystemStatus();
            } else {
                console.error('Failed to stop central system:', result.message);
            }
            
        } catch (error) {
            console.error('Error stopping central system:', error);
        }
    }
    
    async loadSystemData() {
        try {
            // 시스템 상태 로드
            const statusResponse = await fetch('/api/central/status');
            const statusResult = await statusResponse.json();
            
            if (statusResult.status === 'success') {
                this.systemStatus = statusResult.data;
            }
            
            // 모듈 상태 로드
            const modulesResponse = await fetch('/api/central/modules');
            const modulesResult = await modulesResponse.json();
            
            if (modulesResult.status === 'success') {
                this.modules = modulesResult.data;
            }
            
            // 이벤트 히스토리 로드
            const eventsResponse = await fetch('/api/central/events?limit=20');
            const eventsResult = await eventsResponse.json();
            
            if (eventsResult.status === 'success') {
                this.events = eventsResult.data;
            }
            
            // UI 업데이트
            this.updateSystemDisplay();
            
        } catch (error) {
            console.error('Error loading system data:', error);
        }
    }
    
    updateSystemDisplay() {
        // 시스템 상태 표시
        this.updateStatusDisplay();
        
        // 모듈 상태 표시
        this.updateModulesDisplay();
        
        // 이벤트 히스토리 표시
        this.updateEventsDisplay();
    }
    
    updateStatusDisplay() {
        const statusContainer = document.getElementById('central-status');
        if (!statusContainer || !this.systemStatus) return;
        
        const status = this.systemStatus;
        
        statusContainer.innerHTML = `
            <div class="status-grid">
                <div class="status-item">
                    <span class="status-label">System Status:</span>
                    <span class="status-value ${status.is_running ? 'running' : 'stopped'}">
                        ${status.is_running ? 'Running' : 'Stopped'}
                    </span>
                </div>
                <div class="status-item">
                    <span class="status-label">Uptime:</span>
                    <span class="status-value">${this.formatUptime(status.uptime)}</span>
                </div>
                <div class="status-item">
                    <span class="status-label">Active Modules:</span>
                    <span class="status-value">${status.module_count || 0}</span>
                </div>
                <div class="status-item">
                    <span class="status-label">Total Events:</span>
                    <span class="status-value">${status.event_count || 0}</span>
                </div>
                <div class="status-item">
                    <span class="status-label">Cache Entries:</span>
                    <span class="status-value">${status.cache_entries || 0}</span>
                </div>
                <div class="status-item">
                    <span class="status-label">Last Update:</span>
                    <span class="status-value">${new Date(status.last_update).toLocaleString()}</span>
                </div>
            </div>
        `;
    }
    
    updateModulesDisplay() {
        const modulesContainer = document.getElementById('central-modules');
        if (!modulesContainer) return;
        
        const moduleList = Object.entries(this.modules).map(([name, data]) => `
            <div class="module-item">
                <div class="module-header">
                    <span class="module-name">${name}</span>
                    <span class="module-status ${data.status || 'unknown'}">${data.status || 'unknown'}</span>
                </div>
                <div class="module-details">
                    <div class="detail-item">
                        <span class="label">Registered:</span>
                        <span class="value">${new Date(data.registered_at).toLocaleString()}</span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Last Update:</span>
                        <span class="value">${new Date(data.last_update).toLocaleString()}</span>
                    </div>
                </div>
            </div>
        `).join('');
        
        modulesContainer.innerHTML = `
            <div class="modules-header">
                <h4>Active Modules (${Object.keys(this.modules).length})</h4>
            </div>
            <div class="modules-list">
                ${moduleList.length > 0 ? moduleList : '<div class="no-modules">No active modules</div>'}
            </div>
        `;
    }
    
    updateEventsDisplay() {
        const eventsContainer = document.getElementById('central-events');
        if (!eventsContainer) return;
        
        const eventList = this.events.map(event => `
            <div class="event-item">
                <div class="event-header">
                    <span class="event-type">${event.type}</span>
                    <span class="event-time">${new Date(event.timestamp).toLocaleTimeString()}</span>
                </div>
                <div class="event-data">
                    <pre>${JSON.stringify(event.data, null, 2)}</pre>
                </div>
            </div>
        `).join('');
        
        eventsContainer.innerHTML = `
            <div class="events-header">
                <h4>Recent Events (${this.events.length})</h4>
            </div>
            <div class="events-list">
                ${eventList.length > 0 ? eventList : '<div class="no-events">No events recorded</div>'}
            </div>
        `;
    }
    
    startEventStream() {
        try {
            this.eventSource = new EventSource('/api/background/events');
            
            this.eventSource.onmessage = (event) => {
                const data = JSON.parse(event.data);
                this.handleRealTimeEvent(data);
            };
            
            this.eventSource.onerror = (error) => {
                console.error('Event stream error:', error);
                // 재연결 시도
                setTimeout(() => {
                    this.startEventStream();
                }, 5000);
            };
            
        } catch (error) {
            console.error('Error starting event stream:', error);
        }
    }
    
    handleRealTimeEvent(data) {
        // 실시간 이벤트 처리
        console.log('Real-time event received:', data);
        
        // 이벤트를 리스트에 추가
        this.events.unshift({
            type: 'realtime:update',
            data: data,
            timestamp: new Date().toISOString()
        });
        
        // 이벤트 리스트 크기 제한
        if (this.events.length > 50) {
            this.events = this.events.slice(0, 50);
        }
        
        // UI 업데이트
        this.updateEventsDisplay();
    }
    
    startAutoRefresh() {
        // 10초마다 자동 새로고침
        this.refreshInterval = setInterval(() => {
            this.loadSystemData();
        }, 10000);
    }
    
    stopAutoRefresh() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
            this.refreshInterval = null;
        }
    }
    
    async resetCentralSystem() {
        if (!confirm('Are you sure you want to reset the central system? This will restart all modules.')) {
            return;
        }
        
        try {
            const response = await fetch('/api/central/reset', {
                method: 'POST'
            });
            
            const result = await response.json();
            
            if (result.status === 'success') {
                console.log('Central system reset successfully');
                this.showSuccess('Central system reset successfully');
                await this.loadSystemData();
            } else {
                this.showError(result.message);
            }
            
        } catch (error) {
            console.error('Error resetting central system:', error);
            this.showError('Failed to reset central system');
        }
    }
    
    async showSystemStats() {
        try {
            const response = await fetch('/api/central/stats');
            const result = await response.json();
            
            if (result.status === 'success') {
                const stats = result.data;
                
                const statsText = `
System Statistics:

Uptime: ${this.formatUptime(stats.uptime_seconds)}
Total Events: ${stats.total_events}
Active Modules: ${stats.active_modules}
Cache Entries: ${stats.cache_entries}
Event Listeners: ${stats.event_listeners}

System Health:
${JSON.stringify(stats.system_health, null, 2)}
                `;
                
                alert(statsText);
            } else {
                this.showError(result.message);
            }
            
        } catch (error) {
            console.error('Error loading system stats:', error);
            this.showError('Failed to load system statistics');
        }
    }
    
    formatUptime(seconds) {
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = Math.floor(seconds % 60);
        
        return `${hours}h ${minutes}m ${secs}s`;
    }
    
    showSuccess(message) {
        const notification = document.createElement('div');
        notification.className = 'notification success';
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 3000);
    }
    
    showError(message) {
        const notification = document.createElement('div');
        notification.className = 'notification error';
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 5000);
    }
    
    destroy() {
        this.stopAutoRefresh();
        
        if (this.eventSource) {
            this.eventSource.close();
            this.eventSource = null;
        }
        
        this.isInitialized = false;
    }
}

// 전역 인스턴스
window.centralFrontend = new CentralFrontend();
