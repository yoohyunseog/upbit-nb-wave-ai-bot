// ===== Wallet Module - JavaScript Frontend =====

class WalletFrontend {
    constructor() {
        this.isInitialized = false;
        this.balanceData = null;
        this.transactionData = null;
        this.refreshInterval = null;
    }
    
    async initialize() {
        if (this.isInitialized) return;
        
        console.log('💰 Initializing Wallet Frontend...');
        
        // 초기 데이터 로드
        await this.loadWalletData();
        
        // 이벤트 리스너 등록
        this.registerEventListeners();
        
        // 자동 새로고침 시작
        this.startAutoRefresh();
        
        this.isInitialized = true;
        console.log('✅ Wallet Frontend initialized');
    }
    
    registerEventListeners() {
        // 새로고침 버튼
        const refreshBtn = document.getElementById('wallet-refresh-btn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => {
                this.loadWalletData();
            });
        }
        
        // API 키 설정 버튼
        const apiKeyBtn = document.getElementById('wallet-api-key-btn');
        if (apiKeyBtn) {
            apiKeyBtn.addEventListener('click', () => {
                this.showApiKeyModal();
            });
        }
    }
    
    async loadWalletData() {
        try {
            // 잔고 데이터 로드
            const balanceResponse = await fetch('/api/wallet/balance');
            const balanceResult = await balanceResponse.json();
            
            if (balanceResult.status === 'success') {
                this.balanceData = balanceResult.data;
                this.updateBalanceDisplay();
            } else {
                console.error('Failed to load balance:', balanceResult.message);
                this.showError('Failed to load balance data');
            }
            
            // 거래 내역 로드
            const transactionResponse = await fetch('/api/wallet/transactions?limit=10');
            const transactionResult = await transactionResponse.json();
            
            if (transactionResult.status === 'success') {
                this.transactionData = transactionResult.data;
                this.updateTransactionDisplay();
            } else {
                console.error('Failed to load transactions:', transactionResult.message);
            }
            
        } catch (error) {
            console.error('Error loading wallet data:', error);
            this.showError('Network error while loading wallet data');
        }
    }
    
    updateBalanceDisplay() {
        const balanceContainer = document.getElementById('wallet-balance');
        if (!balanceContainer || !this.balanceData) return;
        
        const summary = this.balanceData.summary;
        const balances = this.balanceData.balances;
        
        // 요약 정보 업데이트
        balanceContainer.innerHTML = `
            <div class="balance-summary">
                <div class="total-balance">
                    <h3>Total Balance</h3>
                    <div class="balance-amount">₩${summary.total_value?.toLocaleString() || '0'}</div>
                </div>
                <div class="balance-breakdown">
                    <div class="balance-item">
                        <span class="label">KRW:</span>
                        <span class="value">₩${summary.total_krw?.toLocaleString() || '0'}</span>
                    </div>
                    <div class="balance-item">
                        <span class="label">BTC:</span>
                        <span class="value">${summary.total_btc?.toFixed(8) || '0.00000000'}</span>
                    </div>
                    <div class="balance-item">
                        <span class="label">Assets:</span>
                        <span class="value">${summary.total_assets || 0}</span>
                    </div>
                </div>
            </div>
            
            <div class="balance-details">
                <h4>Balance Details</h4>
                <div class="table-container">
                    <table class="balance-table">
                        <thead>
                            <tr>
                                <th>Currency</th>
                                <th>Balance</th>
                                <th>Locked</th>
                                <th>Avg Buy Price</th>
                                <th>Value (KRW)</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${balances.map(balance => `
                                <tr>
                                    <td>${balance.currency}</td>
                                    <td>${balance.balance?.toFixed(8) || '0.00000000'}</td>
                                    <td>${balance.locked?.toFixed(8) || '0.00000000'}</td>
                                    <td>₩${balance.avg_buy_price?.toLocaleString() || '0'}</td>
                                    <td>₩${balance.value_krw?.toLocaleString() || '0'}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="last-update">
                Last updated: ${new Date(this.balanceData.last_update).toLocaleString()}
            </div>
        `;
    }
    
    updateTransactionDisplay() {
        const transactionContainer = document.getElementById('wallet-transactions');
        if (!transactionContainer || !this.transactionData) return;
        
        const transactions = this.transactionData.transactions;
        
        transactionContainer.innerHTML = `
            <div class="transaction-header">
                <h4>Recent Transactions</h4>
                <span class="transaction-count">${transactions.length} transactions</span>
            </div>
            
            <div class="table-container">
                <table class="transaction-table">
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Currency</th>
                            <th>Amount</th>
                            <th>Price</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${transactions.map(tx => `
                            <tr class="transaction-row ${tx.type}">
                                <td>
                                    <span class="transaction-type ${tx.type}">
                                        ${tx.type.toUpperCase()}
                                    </span>
                                </td>
                                <td>${tx.currency}</td>
                                <td>${tx.amount?.toFixed(8) || '0.00000000'}</td>
                                <td>₩${tx.price?.toLocaleString() || '0'}</td>
                                <td>₩${tx.total?.toLocaleString() || '0'}</td>
                                <td>
                                    <span class="status ${tx.status}">
                                        ${tx.status}
                                    </span>
                                </td>
                                <td>${new Date(tx.timestamp).toLocaleString()}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
            
            <div class="last-update">
                Last updated: ${new Date(this.transactionData.last_update).toLocaleString()}
            </div>
        `;
    }
    
    showApiKeyModal() {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Set Upbit API Keys</h3>
                    <span class="close">&times;</span>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="api-key">API Key:</label>
                        <input type="text" id="api-key" placeholder="Enter your Upbit API key">
                    </div>
                    <div class="form-group">
                        <label for="secret-key">Secret Key:</label>
                        <input type="password" id="secret-key" placeholder="Enter your Upbit secret key">
                    </div>
                    <div class="form-actions">
                        <button id="test-connection-btn" class="btn btn-secondary">Test Connection</button>
                        <button id="save-keys-btn" class="btn btn-primary">Save Keys</button>
                        <button id="cancel-btn" class="btn btn-cancel">Cancel</button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // 이벤트 리스너
        const closeBtn = modal.querySelector('.close');
        const cancelBtn = modal.querySelector('#cancel-btn');
        const testBtn = modal.querySelector('#test-connection-btn');
        const saveBtn = modal.querySelector('#save-keys-btn');
        
        const closeModal = () => {
            document.body.removeChild(modal);
        };
        
        closeBtn.addEventListener('click', closeModal);
        cancelBtn.addEventListener('click', closeModal);
        
        testBtn.addEventListener('click', async () => {
            const apiKey = document.getElementById('api-key').value;
            const secretKey = document.getElementById('secret-key').value;
            
            if (!apiKey || !secretKey) {
                this.showError('Please enter both API key and secret key');
                return;
            }
            
            try {
                const response = await fetch('/api/wallet/test-connection', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ api_key: apiKey, secret_key: secretKey })
                });
                
                const result = await response.json();
                
                if (result.status === 'success') {
                    this.showSuccess('API connection successful!');
                } else {
                    this.showError(result.message);
                }
            } catch (error) {
                this.showError('Failed to test connection');
            }
        });
        
        saveBtn.addEventListener('click', async () => {
            const apiKey = document.getElementById('api-key').value;
            const secretKey = document.getElementById('secret-key').value;
            
            if (!apiKey || !secretKey) {
                this.showError('Please enter both API key and secret key');
                return;
            }
            
            try {
                // 설정에 저장
                const response = await fetch('/api/settings/update', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        section: 'upbit',
                        key: 'api_key',
                        value: apiKey
                    })
                });
                
                await fetch('/api/settings/update', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        section: 'upbit',
                        key: 'secret_key',
                        value: secretKey
                    })
                });
                
                this.showSuccess('API keys saved successfully!');
                closeModal();
                
                // 데이터 새로고침
                await this.loadWalletData();
                
            } catch (error) {
                this.showError('Failed to save API keys');
            }
        });
    }
    
    startAutoRefresh() {
        // 30초마다 자동 새로고침
        this.refreshInterval = setInterval(() => {
            this.loadWalletData();
        }, 30000);
    }
    
    stopAutoRefresh() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
            this.refreshInterval = null;
        }
    }
    
    showSuccess(message) {
        // 성공 메시지 표시
        const notification = document.createElement('div');
        notification.className = 'notification success';
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 3000);
    }
    
    showError(message) {
        // 에러 메시지 표시
        const notification = document.createElement('div');
        notification.className = 'notification error';
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 5000);
    }
    
    destroy() {
        this.stopAutoRefresh();
        this.isInitialized = false;
    }
}

// 전역 인스턴스
window.walletFrontend = new WalletFrontend();
