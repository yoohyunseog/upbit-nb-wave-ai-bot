# ===== Wallet Module - Python Backend =====

import pyupbit
import json
from datetime import datetime, timedelta
from flask import jsonify

class WalletModule:
    """Wallet 모듈"""
    
    def __init__(self):
        self.api_key = None
        self.secret_key = None
        self.is_connected = False
        self.last_update = datetime.now()
        self.cached_balance = {}
        self.cached_transactions = []
        
    def set_api_keys(self, api_key: str, secret_key: str):
        """API 키 설정"""
        self.api_key = api_key
        self.secret_key = secret_key
        self.is_connected = True
        print(f"💰 Wallet API keys set")
        
    def test_connection(self) -> dict:
        """API 연결 테스트"""
        try:
            if not self.api_key or not self.secret_key:
                return {
                    'status': 'error',
                    'message': 'API keys not configured'
                }
            
            # 잔고 조회로 연결 테스트
            balance = pyupbit.get_balance("KRW", api_key=self.api_key, secret=self.secret_key)
            
            if balance is not None:
                return {
                    'status': 'success',
                    'message': 'API connection successful',
                    'balance': float(balance) if balance else 0
                }
            else:
                return {
                    'status': 'error',
                    'message': 'Failed to fetch balance'
                }
                
        except Exception as e:
            return {
                'status': 'error',
                'message': f'Connection failed: {str(e)}'
            }
    
    def get_balance(self) -> dict:
        """잔고 조회"""
        try:
            if not self.is_connected:
                return {
                    'status': 'error',
                    'message': 'Not connected to Upbit API'
                }
            
            # 캐시된 데이터가 있고 최근이면 반환
            if self.cached_balance and (datetime.now() - self.last_update).seconds < 30:
                return {
                    'status': 'success',
                    'data': self.cached_balance,
                    'cached': True
                }
            
            # 전체 잔고 조회
            balances = pyupbit.get_balances(api_key=self.api_key, secret=self.secret_key)
            
            if not balances:
                return {
                    'status': 'error',
                    'message': 'No balance data available'
                }
            
            # 데이터 정리
            balance_data = []
            total_krw = 0
            total_btc = 0
            
            for balance in balances:
                currency = balance['currency']
                balance_amount = float(balance['balance'])
                locked = float(balance['locked'])
                avg_buy_price = float(balance['avg_buy_price'])
                
                if balance_amount > 0:
                    if currency == 'KRW':
                        total_krw = balance_amount
                        balance_data.append({
                            'currency': currency,
                            'balance': balance_amount,
                            'locked': locked,
                            'avg_buy_price': avg_buy_price,
                            'value_krw': balance_amount
                        })
                    elif currency == 'BTC':
                        total_btc = balance_amount
                        current_price = self._get_btc_price()
                        value_krw = balance_amount * current_price
                        balance_data.append({
                            'currency': currency,
                            'balance': balance_amount,
                            'locked': locked,
                            'avg_buy_price': avg_buy_price,
                            'value_krw': value_krw,
                            'current_price': current_price
                        })
                    else:
                        # 다른 코인들
                        current_price = self._get_coin_price(currency)
                        value_krw = balance_amount * current_price
                        balance_data.append({
                            'currency': currency,
                            'balance': balance_amount,
                            'locked': locked,
                            'avg_buy_price': avg_buy_price,
                            'value_krw': value_krw,
                            'current_price': current_price
                        })
            
            # 총 자산 계산
            total_value = total_krw + sum(item['value_krw'] for item in balance_data if item['currency'] != 'KRW')
            
            result = {
                'balances': balance_data,
                'summary': {
                    'total_krw': total_krw,
                    'total_btc': total_btc,
                    'total_value': total_value,
                    'total_assets': len(balance_data)
                },
                'last_update': datetime.now().isoformat()
            }
            
            # 캐시 업데이트
            self.cached_balance = result
            self.last_update = datetime.now()
            
            return {
                'status': 'success',
                'data': result
            }
            
        except Exception as e:
            print(f"Error fetching balance: {e}")
            return {
                'status': 'error',
                'message': str(e)
            }
    
    def get_transactions(self, limit: int = 20) -> dict:
        """거래 내역 조회"""
        try:
            if not self.is_connected:
                return {
                    'status': 'error',
                    'message': 'Not connected to Upbit API'
                }
            
            # 실제 구현에서는 Upbit API로 거래 내역 조회
            # 현재는 더미 데이터 반환
            dummy_transactions = [
                {
                    'id': '1',
                    'type': 'buy',
                    'currency': 'BTC',
                    'amount': 0.001,
                    'price': 50000000,
                    'total': 50000,
                    'timestamp': (datetime.now() - timedelta(hours=1)).isoformat(),
                    'status': 'completed'
                },
                {
                    'id': '2',
                    'type': 'sell',
                    'currency': 'BTC',
                    'amount': 0.0005,
                    'price': 51000000,
                    'total': 25500,
                    'timestamp': (datetime.now() - timedelta(hours=2)).isoformat(),
                    'status': 'completed'
                }
            ]
            
            return {
                'status': 'success',
                'data': {
                    'transactions': dummy_transactions,
                    'total': len(dummy_transactions),
                    'last_update': datetime.now().isoformat()
                }
            }
            
        except Exception as e:
            print(f"Error fetching transactions: {e}")
            return {
                'status': 'error',
                'message': str(e)
            }
    
    def _get_btc_price(self) -> float:
        """BTC 현재 가격 조회"""
        try:
            ticker = pyupbit.get_current_price("KRW-BTC")
            return float(ticker) if ticker else 50000000
        except:
            return 50000000
    
    def _get_coin_price(self, currency: str) -> float:
        """코인 현재 가격 조회"""
        try:
            if currency == 'BTC':
                return self._get_btc_price()
            
            ticker = pyupbit.get_current_price(f"KRW-{currency}")
            return float(ticker) if ticker else 0
        except:
            return 0
    
    def get_status(self) -> dict:
        """모듈 상태 조회"""
        return {
            'is_connected': self.is_connected,
            'has_api_keys': bool(self.api_key and self.secret_key),
            'last_update': self.last_update.isoformat(),
            'cached_balance': bool(self.cached_balance)
        }

# 전역 인스턴스
wallet_module = WalletModule()
