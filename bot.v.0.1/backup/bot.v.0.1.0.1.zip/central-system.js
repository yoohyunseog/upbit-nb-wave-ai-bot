// ===== 중추 시스템 (Central Nervous System) =====

// 중추 시스템 전역 변수
let centralSystem = {
    // 상태 관리
    state: {
        currentModule: null,
        activeModules: [],
        systemStatus: {
            server: 'offline',
            api: 'disconnected',
            database: 'error'
        },
        userSettings: {},
        realTimeData: {}
    },
    
    // 이벤트 시스템
    events: {
        listeners: {},
        history: []
    },
    
    // 데이터 캐시
    cache: {
        trading: {},
        wallet: {},
        settings: {}
    }
};

// 중추 시스템 초기화
function initializeCentralSystem() {
    console.log('🧠 Initializing Central Nervous System...');
    
    // 기본 상태 설정
    centralSystem.state.currentModule = 'welcome';
    centralSystem.state.activeModules = [];
    
    // 이벤트 리스너 등록
    registerEventListeners();
    
    // 시스템 상태 확인
    checkSystemStatus();
    
    // 사용자 설정 로드
    loadUserSettings();
    
    console.log('✅ Central Nervous System initialized successfully');
}

// 이벤트 리스너 등록
function registerEventListeners() {
    // 모듈 전환 이벤트
    centralSystem.events.listeners['module:switch'] = [];
    centralSystem.events.listeners['module:load'] = [];
    centralSystem.events.listeners['module:unload'] = [];
    
    // 데이터 업데이트 이벤트
    centralSystem.events.listeners['data:update'] = [];
    centralSystem.events.listeners['data:refresh'] = [];
    
    // 시스템 상태 이벤트
    centralSystem.events.listeners['system:status'] = [];
    centralSystem.events.listeners['system:error'] = [];
    
    // 사용자 액션 이벤트
    centralSystem.events.listeners['user:action'] = [];
    centralSystem.events.listeners['user:setting'] = [];
}

// 시스템 상태 확인
async function checkSystemStatus() {
    try {
        const response = await fetch('/api/status');
        const data = await response.json();
        
        centralSystem.state.systemStatus = {
            server: 'online',
            api: 'connected',
            database: 'ready'
        };
        
        // 상태 업데이트 이벤트 발생
        emitEvent('system:status', centralSystem.state.systemStatus);
        
    } catch (error) {
        centralSystem.state.systemStatus = {
            server: 'offline',
            api: 'disconnected',
            database: 'error'
        };
        
        // 에러 이벤트 발생
        emitEvent('system:error', error.message);
    }
}

// 사용자 설정 로드
function loadUserSettings() {
    try {
        const savedSettings = localStorage.getItem('userSettings');
        if (savedSettings) {
            centralSystem.state.userSettings = JSON.parse(savedSettings);
        } else {
            // 기본 설정
            centralSystem.state.userSettings = {
                theme: 'starcraft',
                soundEnabled: true,
                autoRefresh: false,
                defaultTimeframe: 'minute1',
                language: 'ko'
            };
        }
        
        // 설정 로드 이벤트 발생
        emitEvent('user:setting', centralSystem.state.userSettings);
        
    } catch (error) {
        console.error('Failed to load user settings:', error);
    }
}

// 이벤트 발생
function emitEvent(eventName, data) {
    if (centralSystem.events.listeners[eventName]) {
        centralSystem.events.listeners[eventName].forEach(callback => {
            try {
                callback(data);
            } catch (error) {
                console.error(`Error in event listener for ${eventName}:`, error);
            }
        });
    }
    
    // 이벤트 히스토리에 기록
    centralSystem.events.history.push({
        timestamp: new Date(),
        event: eventName,
        data: data
    });
    
    // 히스토리 크기 제한 (최근 100개)
    if (centralSystem.events.history.length > 100) {
        centralSystem.events.history.shift();
    }
}

// 이벤트 리스너 등록
function addEventListener(eventName, callback) {
    if (!centralSystem.events.listeners[eventName]) {
        centralSystem.events.listeners[eventName] = [];
    }
    centralSystem.events.listeners[eventName].push(callback);
}

// 이벤트 리스너 제거
function removeEventListener(eventName, callback) {
    if (centralSystem.events.listeners[eventName]) {
        const index = centralSystem.events.listeners[eventName].indexOf(callback);
        if (index > -1) {
            centralSystem.events.listeners[eventName].splice(index, 1);
        }
    }
}

// 모듈 상태 관리
function setCurrentModule(moduleName) {
    const previousModule = centralSystem.state.currentModule;
    centralSystem.state.currentModule = moduleName;
    
    // 모듈 전환 이벤트 발생
    emitEvent('module:switch', {
        from: previousModule,
        to: moduleName,
        timestamp: new Date()
    });
}

// 활성 모듈 관리
function addActiveModule(moduleName) {
    if (!centralSystem.state.activeModules.includes(moduleName)) {
        centralSystem.state.activeModules.push(moduleName);
        emitEvent('module:load', moduleName);
    }
}

function removeActiveModule(moduleName) {
    const index = centralSystem.state.activeModules.indexOf(moduleName);
    if (index > -1) {
        centralSystem.state.activeModules.splice(index, 1);
        emitEvent('module:unload', moduleName);
    }
}

// 데이터 캐시 관리
function setCacheData(module, key, data) {
    if (!centralSystem.cache[module]) {
        centralSystem.cache[module] = {};
    }
    centralSystem.cache[module][key] = {
        data: data,
        timestamp: new Date()
    };
}

function getCacheData(module, key) {
    if (centralSystem.cache[module] && centralSystem.cache[module][key]) {
        return centralSystem.cache[module][key].data;
    }
    return null;
}

// 중추 시스템 상태 가져오기
function getCentralSystemState() {
    return {
        ...centralSystem.state,
        events: {
            history: centralSystem.events.history.slice(-10) // 최근 10개 이벤트만
        },
        cache: Object.keys(centralSystem.cache).reduce((acc, module) => {
            acc[module] = Object.keys(centralSystem.cache[module]).length;
            return acc;
        }, {})
    };
}

// 중추 시스템 통계
function getCentralSystemStats() {
    return {
        totalEvents: centralSystem.events.history.length,
        activeModules: centralSystem.state.activeModules.length,
        cacheEntries: Object.values(centralSystem.cache).reduce((sum, moduleCache) => {
            return sum + Object.keys(moduleCache).length;
        }, 0),
        systemUptime: new Date() - (centralSystem.startTime || new Date())
    };
}

// 중추 시스템 리셋
function resetCentralSystem() {
    centralSystem = {
        state: {
            currentModule: null,
            activeModules: [],
            systemStatus: {
                server: 'offline',
                api: 'disconnected',
                database: 'error'
            },
            userSettings: {},
            realTimeData: {}
        },
        events: {
            listeners: {},
            history: []
        },
        cache: {
            trading: {},
            wallet: {},
            settings: {}
        }
    };
    
    // 초기화 재실행
    initializeCentralSystem();
}

// 페이지 로드 시 중추 시스템 초기화
document.addEventListener('DOMContentLoaded', function() {
    centralSystem.startTime = new Date();
    initializeCentralSystem();
});

// 전역으로 중추 시스템 노출
window.centralSystem = centralSystem;
window.emitEvent = emitEvent;
window.addEventListener = addEventListener;
window.removeEventListener = removeEventListener;
window.getCentralSystemState = getCentralSystemState;
window.getCentralSystemStats = getCentralSystemStats;
window.resetCentralSystem = resetCentralSystem;
