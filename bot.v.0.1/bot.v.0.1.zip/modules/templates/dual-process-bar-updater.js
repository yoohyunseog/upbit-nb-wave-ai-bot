(() => {
	const clamp01 = (v) => Math.min(1, Math.max(0, v));
  
	function getIntById(id) {
	  const el = document.getElementById(id);
	  const text = el?.textContent ?? '0';
	  const m = String(text).match(/-?\d+/);
	  const num = m ? parseInt(m[0], 10) : 0;
	  return Number.isNaN(num) ? 0 : num;
	}
  
	function setWidth(rect, width) {
	  if (!rect) return;
	  // Phaser Rectangle 객체는 width 속성을 직접 사용
	  rect.width = width;
	}

	function setColor(rect, color) {
		if (!rect) return;
		if (typeof rect.setFillStyle === 'function') {
			rect.setFillStyle(color);
		} else if ('fillColor' in rect) {
			rect.fillColor = color;
		}
	}
  
	function update(orangeProcessBar, blueProcessBar, opts = {}) {
	  try {
		// 프로세스바 객체 확인
		if (!orangeProcessBar || !blueProcessBar) {
			return;
		}

		const { orangeId = 'orange-sum', blueId = 'blue-sum' } = opts;
		const orangeVal = getIntById(orangeId);
		const blueVal = getIntById(blueId);
		const total = Math.max(1, orangeVal + blueVal);

		// 디버깅: 프로세스바 너비 확인
		console.log('📏 프로세스바 너비 확인:', {
			orangeVal, blueVal, total,
			orangeLeftWidth: orangeProcessBar.fillLeft?.width || 0,
			orangeRightWidth: orangeProcessBar.fillRight?.width || 0,
			blueWidth: blueProcessBar.fill?.width || 0
		});

		// 트레이너 학습 모델 컨트롤 상태 확인
		const signalCenterProcess = window.signalCenterProcess;
		const isTrainerControlled = signalCenterProcess?.takeover && signalCenterProcess?.followProfitRate;
		const trainerMode = signalCenterProcess?.mode || 'none';
		const trainerProgress = signalCenterProcess?.progress || 0;
		const trainerEnabled = signalCenterProcess?.enabled || false;

		// 트레이너 컨트롤 상태에 따른 색상 설정
		const normalOrangeColor = 0xff8800;
		const normalBlueColor = 0x0088ff;
		const trainerActiveColor = 0x00ff00; // 녹색으로 트레이너 활성화 표시
		const trainerInactiveColor = 0x666666; // 회색으로 비활성화 표시

		if (orangeProcessBar) {
		  const signed = orangeVal - blueVal;
		  const ratio = clamp01(Math.abs(signed) / total);
		  const targetW = orangeProcessBar.width * ratio;
		  const left = signed >= 0 ? targetW : 0;
		  const right = signed < 0 ? targetW : 0;
		  
		  console.log('🟠 ORANGE 계산:', { signed, ratio, targetW, left, right });
		  
		  setWidth(orangeProcessBar.fillLeft, left);
		  setWidth(orangeProcessBar.fillRight, right);

		  // 트레이너 컨트롤 상태에 따른 색상 변경
		  if (isTrainerControlled && trainerEnabled) {
		  	setColor(orangeProcessBar.fillLeft, trainerActiveColor);
		  	setColor(orangeProcessBar.fillRight, trainerActiveColor);
		  } else if (isTrainerControlled && !trainerEnabled) {
		  	setColor(orangeProcessBar.fillLeft, trainerInactiveColor);
		  	setColor(orangeProcessBar.fillRight, trainerInactiveColor);
		  } else {
		  	setColor(orangeProcessBar.fillLeft, normalOrangeColor);
		  	setColor(orangeProcessBar.fillRight, normalOrangeColor);
		  }

		  // 라벨에 트레이너 상태 표시
		  if (orangeProcessBar.label) {
		  	let labelText = 'ORANGE TOTAL →';
		  	if (isTrainerControlled) {
		  		labelText += ` [${trainerMode.toUpperCase()}:${Math.round(trainerProgress * 100)}%]`;
		  	}
		  	orangeProcessBar.label.setText(labelText);
		  }
		}
  
		if (blueProcessBar) {
		  const ratioBlue = clamp01(blueVal / total);
		  const targetWBlue = blueProcessBar.width * ratioBlue;
		  
		  console.log('🔵 BLUE 계산:', { ratioBlue, targetWBlue });
		  
		  setWidth(blueProcessBar.fill, targetWBlue);

		  // 트레이너 컨트롤 상태에 따른 색상 변경
		  if (isTrainerControlled && trainerEnabled) {
		  	setColor(blueProcessBar.fill, trainerActiveColor);
		  } else if (isTrainerControlled && !trainerEnabled) {
		  	setColor(blueProcessBar.fill, trainerInactiveColor);
		  } else {
		  	setColor(blueProcessBar.fill, normalBlueColor);
		  }

		  // 라벨에 트레이너 상태 표시
		  if (blueProcessBar.label) {
		  	let labelText = '← BLUE TOTAL';
		  	if (isTrainerControlled) {
		  		labelText = `[${trainerMode.toUpperCase()}:${Math.round(trainerProgress * 100)}%] ← ${labelText}`;
		  	}
		  	blueProcessBar.label.setText(labelText);
		  }
		}

		// 중앙 라벨에 트레이너 컨트롤 상태 표시
		if (window.dualProcessCenterLabel) {
			let centerText = '<-> PROCESS <->';
			if (isTrainerControlled) {
				centerText = `🤖 TRAINER: ${trainerMode.toUpperCase()} ${Math.round(trainerProgress * 100)}%`;
			}
			window.dualProcessCenterLabel.setText(centerText);
		}
	  } catch (err) {
		console.error('❌ 프로세스바 업데이트 오류:', err);
	  }
	}
  
	window.dualProcessBarUpdater = { update };
  })();